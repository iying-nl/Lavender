package alert

import (
    "context"
    "encoding/json"
    "net/http"
    "regexp"
    "strconv"
    "strings"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)


// Statistics 定义统计数据的结构
type Statistics struct {
    RiskLevel struct {
        Critical map[string]int `json:"严重风险"`
        High     map[string]int `json:"高风险"`
        Summary  struct {
            Critical int `json:"严重风险"`
            High     int `json:"高风险"`
        } `json:"汇总"`
    } `json:"RiskLevel"`
    SigmaLevel struct {
        High     map[string]int `json:"高"`
        Critical map[string]int `json:"严重"`
        Summary  struct {
            High     int `json:"高"`
            Critical int `json:"严重"`
        } `json:"汇总"`
    } `json:"SigmaLevel"`
}

var esClient *elasticsearch.Client

func init() {
    var err error
    esClient, err = elasticsearch.NewClient(elasticsearch.Config{
        Addresses: []string{esURL},
    })
    if err != nil {
        panic(err)
    }
}

func main() {
    r := gin.Default()
    events := r.Group("/api")
    events.GET("/eventsrisk", HandleEventQueryAlert)
    r.Run(":1100")
}

// HandleEventQueryAlert 处理事件查询告警的函数
func HandleEventQueryAlert(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")

    query := map[string]interface{}{
        "size": 0,
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": startTime,
                                "lte": endTime,
                            },
                        },
                    },
                },
            },
        },
        "aggs": map[string]interface{}{
            "ip_stats": map[string]interface{}{
                "terms": map[string]interface{}{
                    "field": "host.ip",
                    "size":  1000,
                },
                "aggs": map[string]interface{}{
                    "rule_names": map[string]interface{}{
                        "terms": map[string]interface{}{
                            "field": "winlog.event_data.RuleName",
                            "size":  1000,
                        },
                    },
                },
            },
        },
    }

    res, err := esClient.Search(
        esClient.Search.WithContext(context.Background()),
        esClient.Search.WithIndex(indexPattern),
        esClient.Search.WithBody(strings.NewReader(mustToJSON(query))),
        esClient.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    defer res.Body.Close()

    var result map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    stats := Statistics{}
    stats.RiskLevel.Critical = make(map[string]int)
    stats.RiskLevel.High = make(map[string]int)
    stats.SigmaLevel.High = make(map[string]int)
    stats.SigmaLevel.Critical = make(map[string]int)

    if aggs, ok := result["aggregations"].(map[string]interface{}); ok {
        if ipStats, ok := aggs["ip_stats"].(map[string]interface{}); ok {
            if buckets, ok := ipStats["buckets"].([]interface{}); ok {
                for _, bucket := range buckets {
                    ipBucket := bucket.(map[string]interface{})
                    ip := ipBucket["key"].(string)

                    if ruleNames, ok := ipBucket["rule_names"].(map[string]interface{}); ok {
                        if ruleBuckets, ok := ruleNames["buckets"].([]interface{}); ok {
                            for _, ruleBucket := range ruleBuckets {
                                rule := ruleBucket.(map[string]interface{})
                                ruleName := rule["key"].(string)
                                count := int(rule["doc_count"].(float64))

                                // 解析Risk值
                                riskRegex := regexp.MustCompile(`Risk=(\d+)`)
                                if matches := riskRegex.FindStringSubmatch(ruleName); len(matches) > 1 {
                                    risk, _ := strconv.Atoi(matches[1])
                                    if risk >= 90 {
                                        stats.RiskLevel.Critical[ip] += count
                                        stats.RiskLevel.Summary.Critical += count
                                    } else if risk >= 70 && risk <= 89 {
                                        stats.RiskLevel.High[ip] += count
                                        stats.RiskLevel.Summary.High += count
                                    }
                                }

                                // 解析Level值
                                levelRegex := regexp.MustCompile(`Level=(\d+)`)
                                if matches := levelRegex.FindStringSubmatch(ruleName); len(matches) > 1 {
                                    level, _ := strconv.Atoi(matches[1])
                                    if level == 3 {
                                        stats.SigmaLevel.High[ip] += count
                                        stats.SigmaLevel.Summary.High += count
                                    } else if level == 4 {
                                        stats.SigmaLevel.Critical[ip] += count
                                        stats.SigmaLevel.Summary.Critical += count
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    c.JSON(http.StatusOK, stats)
}

// mustToJSON 将接口转换为JSON字符串
func mustToJSON(v interface{}) string {
    b, err := json.Marshal(v)
    if err != nil {
        panic(err)
    }
    return string(b)
}
