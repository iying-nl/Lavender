
package alert

const (
    pageSize     = 100
    esURL        = "http://elastic:T3oB04dTcLql7jGsHzLp@192.168.1.10:9200"
    indexPattern = ".ds-winlogbeat-8.12.2*"
)
