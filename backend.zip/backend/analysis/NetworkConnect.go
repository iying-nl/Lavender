package analysis

import (

    "context"
    "encoding/json"
    "fmt"
    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
    "log"
    "net/http"
    "time"
    "bytes"
)

const (
    pageSize = 10000
)

// NetworkConnection 定义网络连接信息
type NetworkConnection struct {
    SourceIP        string   `json:"source_ip"`
    UniqueDestCount int      `json:"unique_dest_count"`
    DestinationIPs  []string `json:"destination_ips"`
}

var es *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{EsURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建 ES 客户端失败: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTC(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 查询网络连接数据
func queryNetworkConnections(startTime, endTime, hostIP string) ([]NetworkConnection, error) {
    utcStartTime, err := convertToUTC(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTC(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                    {
                        "term": map[string]interface{}{
                            "host.ip": hostIP,
                        },
                    },
                },
            },
        },
        "size": pageSize,
        "_source": []string{
            "winlog.event_data.SourceIp",
            "winlog.event_data.DestinationIp",
        },
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(IndexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("ES 查询错误: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    // 使用 map 来统计每个源 IP 的目标 IP
    connectionMap := make(map[string]map[string]bool)

    for _, doc := range documents {
        source := doc.(map[string]interface{})["_source"].(map[string]interface{})
        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if eventData, ok := winlog["event_data"].(map[string]interface{}); ok {
                sourceIP, sourceOK := eventData["SourceIp"].(string)
                destIP, destOK := eventData["DestinationIp"].(string)

                if sourceOK && destOK && sourceIP != "" && destIP != "" {
                    if _, exists := connectionMap[sourceIP]; !exists {
                        connectionMap[sourceIP] = make(map[string]bool)
                    }
                    connectionMap[sourceIP][destIP] = true
                }
            }
        }
    }

    // 转换为最终的输出格式
    var results []NetworkConnection
    for sourceIP, destIPs := range connectionMap {
        destIPList := make([]string, 0, len(destIPs))
        for destIP := range destIPs {
            destIPList = append(destIPList, destIP)
        }
        results = append(results, NetworkConnection{
            SourceIP:        sourceIP,
            UniqueDestCount: len(destIPs),
            DestinationIPs:  destIPList,
        })
    }

    return results, nil
}

func HandleEventQueryNetworkConnect(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")

    if startTime == "" || endTime == "" || hostIP == "" {
        c.JSON(http.StatusBadRequest, gin.H{
            "error": "缺少必要的查询参数",
        })
        return
    }

    connections, err := queryNetworkConnections(startTime, endTime, hostIP)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{
            "error": err.Error(),
        })
        return
    }

    c.JSON(http.StatusOK, connections)
}
