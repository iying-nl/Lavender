
package analysis


const (
    EsURL        = "http://elastic:T3oB04dTcLql7jGsHzLp@192.168.1.10:9200" // 请根据实际情况修改
    IndexPattern = ".ds-winlogbeat-8.12.2*"
)
