package analysis

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "path/filepath"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)

// ProcessInfo 结构体用于存储进程信息
type ProcessInfo struct {
    ProcessID       string         `json:"process_id"`
    ParentProcessID string         `json:"parent_process_id"`
    Image           string         `json:"image"`
    ParentImage     string         `json:"parent_image"`
    UtcTime         time.Time      `json:"utc_time"`
    Children        []*ProcessInfo `json:"children"`
}

// ProcessNode 用于表示进程树中的一个节点
type ProcessNode struct {
    ProcessID       string        `json:"process_id"`
    ParentProcessID string        `json:"parent_process_id"`
    Image           string        `json:"image"`
    ParentImage     string        `json:"parent_image"`
    UTCTime         time.Time     `json:"utc_time"`
    Children        []ProcessNode `json:"children"`
}

// ChildProcess 用于输出的子进程结构
type ChildProcess struct {
    ProcessName string                 `json:"process_name"`
    Children    map[string]ChildProcess `json:"children,omitempty"`
}

// ParentSummary 用于输出的父进程摘要
type ParentSummary struct {
    ProcessName   string                 `json:"process_name"`
    ChildrenCount int                    `json:"子进程数量"`
    Children      map[string]ChildProcess `json:"子进程"`
}

// Summary 用于输出的总结结构
type Summary struct {
    Summary struct {
        Parents map[string]ParentSummary `json:"父进程"`
    } `json:"总结"`
}

// ProcessTreeHandler 处理进程树请求
func ProcessTreeHandler(c *gin.Context) {
    // Elasticsearch 配置
    esURL := "http://elastic:T3oB04dTcLql7jGsHzLp@192.168.1.10:9200" // 请根据实际情况修改
    indexPattern := ".ds-winlogbeat-8.12.2*"

    // 创建 Elasticsearch 客户端
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    es, err := elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("Error creating the client: %s", err)
    }

    // 获取查询参数
    startTimeStr := c.Query("start_time")
    endTimeStr := c.Query("end_time")
    ip := c.Query("ip")

    // 解析时间参数
    startTime, err := time.Parse(time.RFC3339, startTimeStr)
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid start_time format"})
        return
    }
    endTime, err := time.Parse(time.RFC3339, endTimeStr)
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid end_time format"})
        return
    }

    // 构建 Elasticsearch 查询
    query := buildQuery(startTime, endTime, ip)

    // 执行查询
    processTree, err := getProcessTree(es, indexPattern, query)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Error querying Elasticsearch"})
        return
    }

    // 构建输出结构
    summary := buildSummary(processTree)

    // 返回结果
    c.JSON(http.StatusOK, summary)
}

// 其他辅助函数保持不变
// ...


// buildQuery 构建 Elasticsearch 查询语句
func buildQuery(startTime, endTime time.Time, ip string) map[string]interface{} {
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "match": map[string]interface{}{
                            "winlog.event_id": "1",
                        },
                    },
                    {
                        "range": map[string]interface{}{
                            "winlog.event_data.UtcTime": map[string]interface{}{
                                "gte": startTime.Format(time.RFC3339),
                                "lte": endTime.Format(time.RFC3339),
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {
                "@timestamp": map[string]interface{}{
                    "order": "asc",
                },
            },
        },
        "_source": []string{
            "winlog.event_data.ProcessId",
            "winlog.event_data.ParentProcessId",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.UtcTime",
            "host.ip",
        },
        "size": 10000, // 假设最大返回 10000 条记录,可以根据实际情况调整
    }

    // 添加 IP 筛选条件
    if ip != "" {
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": ip,
                },
            },
        )
    }

    return query
}


// getProcessTree 执行查询并构建进程树
func getProcessTree(es *elasticsearch.Client, indexPattern string, query map[string]interface{}) ([]*ProcessInfo, error) {
    // 将查询转换为 JSON 格式
    var buf bytes.Buffer
    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, fmt.Errorf("error encoding query: %s", err)
    }

    // 执行查询
    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
        es.Search.WithPretty(),
    )
    if err != nil {
        return nil, fmt.Errorf("error getting response: %s", err)
    }
    defer res.Body.Close()

    if res.IsError() {
        var e map[string]interface{}
        if err := json.NewDecoder(res.Body).Decode(&e); err != nil {
            return nil, fmt.Errorf("error parsing the response body: %s", err)
        }
        return nil, fmt.Errorf("[%s] %s: %s",
            res.Status(),
            e["error"].(map[string]interface{})["type"],
            e["error"].(map[string]interface{})["reason"],
        )
    }

    // 解析查询结果
    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, fmt.Errorf("error parsing the response body: %s", err)
    }

    // 提取进程信息
    processes := make(map[string]*ProcessInfo)
    relationshipSet := make(map[string]bool) // 用于跟踪父子关系
    for _, hit := range r["hits"].(map[string]interface{})["hits"].([]interface{}) {
        source := hit.(map[string]interface{})["_source"].(map[string]interface{})
        winlogData := source["winlog"].(map[string]interface{})["event_data"].(map[string]interface{})

        // 提取 UtcTime 字段
        utcTimeStr, ok := winlogData["UtcTime"].(string)
        if !ok {
            log.Printf("Error: UtcTime is not a string: %v", winlogData["UtcTime"])
            continue
        }

        utcTime, err := time.Parse("2006-01-02 15:04:05.999", utcTimeStr)
        if err != nil {
            log.Printf("Error parsing UtcTime: %s", err)
            continue
        }

        processID := winlogData["ProcessId"].(string)
        parentProcessID := winlogData["ParentProcessId"].(string)
        image := winlogData["Image"].(string)
        parentImage := winlogData["ParentImage"].(string)

        // 构建关系键
        relationKey := parentImage + "->" + image
        if relationshipSet[relationKey] {
            // 如果已经存在此关系，跳过
            continue
        }

        // 更新为直接从map中获取string值
        process := &ProcessInfo{
            ProcessID:       processID,
            ParentProcessID: parentProcessID,
            Image:           image,
            ParentImage:     parentImage,
            UtcTime:         utcTime,
            Children:        []*ProcessInfo{},
        }
        processes[process.ProcessID] = process

        // 记录此父子关系
        relationshipSet[relationKey] = true
    }

    // 构建进程树
    var rootProcesses []*ProcessInfo
    for _, process := range processes {
        if parent, ok := processes[process.ParentProcessID]; ok {
            parent.Children = append(parent.Children, process)
        } else {
            rootProcesses = append(rootProcesses, process)
        }
    }

    return rootProcesses, nil
}

// buildSummary 构建输出的总结结构
func buildSummary(processTree []*ProcessInfo) Summary {
    // 创建父进程映射
    parentMap := make(map[string][]ProcessNode)
    buildParentMap(processTree, parentMap)

    // 创建输出结构
    output := Summary{}
    output.Summary.Parents = make(map[string]ParentSummary)

    // 处理每个父进程
    for parentID, children := range parentMap {
        if len(children) == 0 {
            continue
        }

        // 获取父进程名称
        parentName := "unknown"
        for _, child := range children {
            if getProcessNameFromPath(child.ParentImage) != "" {
                parentName = getProcessNameFromPath(child.ParentImage)
                break
            }
        }

        // 创建父进程摘要
        summary := ParentSummary{
            ProcessName:   parentName,
            ChildrenCount: len(children),
            Children:      buildChildProcesses(children),
        }

        output.Summary.Parents[parentID] = summary
    }

    return output
}

// buildParentMap 创建父进程映射
func buildParentMap(nodes []*ProcessInfo, parentMap map[string][]ProcessNode) {
    for _, node := range nodes {
        processNode := ProcessNode{
            ProcessID:       node.ProcessID,
            ParentProcessID: node.ParentProcessID,
            Image:           node.Image,
            ParentImage:     node.ParentImage,
            UTCTime:         node.UtcTime,
            Children:        []ProcessNode{},
        }
        parentMap[node.ParentProcessID] = append(parentMap[node.ParentProcessID], processNode)

        var childNodes []*ProcessInfo
        for _, child := range node.Children {
            childNodes = append(childNodes, child)
        }
        buildParentMap(childNodes, parentMap)
    }
}

// buildChildProcesses 创建子进程结构
func buildChildProcesses(children []ProcessNode) map[string]ChildProcess {
    childMap := make(map[string]ChildProcess)
    for _, child := range children {
        childName := getProcessNameFromPath(child.Image)
        childMap[child.ProcessID] = ChildProcess{
            ProcessName: childName,
            Children:    buildChildProcesses(child.Children),
        }
    }
    return childMap
}

// getProcessNameFromPath 从路径中获取进程名称
func getProcessNameFromPath(path string) string {
    return filepath.Base(path)
}

// corsMiddleware 处理跨域资源共享
func corsMiddleware() gin.HandlerFunc {
    return func(c *gin.Context) {
        c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
        c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")

        if c.Request.Method == "OPTIONS" {
            c.AbortWithStatus(http.StatusNoContent)
            return
        }

        c.Next()
    }
}


