package brief

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "os"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)

const (
    idJsonPath   = "brief/dictionary/id.json" //  修改这里
    dictionaryDir = "brief/dictionary" //  修改这里
)

type EventData struct {
    ID           string      `json:"_id"`
    Timestamp    string      `json:"winlog.event_data.UtcTime"`
    ComputerName string      `json:"winlog.computer_name"`
    EventID      string      `json:"winlog.event_id"`
    RuleName     string      `json:"winlog.event_data.RuleName"`
    HostIP       string      `json:"host.ip"`
    User         interface{} `json:"winlog.event_data.User"`
    Attack       string      `json:"Attack"`
    Sort         []interface{} `json:"sort"`
}

type EventQuery struct {
    TotalHits   int64       `json:"totalHits"`
    TotalPages  int         `json:"totalPages"`
    Documents   []EventData `json:"documents"`
    NextPageKey []interface{} `json:"nextPageKey,omitempty"`
}

var (
    es *elasticsearch.Client
    eventIDMap map[string]string
    translations map[string]map[string]string
)

func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("Error creating the client: %s", err)
    }

    // Load event ID translations
    eventIDMap, err = loadEventIDTranslations(idJsonPath)
    if err != nil {
        log.Fatalf("Error loading event ID translations: %s", err)
    }

    // Load other translations
    translations, err = loadTranslations(dictionaryDir)
    if err != nil {
        log.Fatalf("Error loading translations: %s", err)
    }
}

func loadEventIDTranslations(filePath string) (map[string]string, error) {
    file, err := os.Open(filePath)
    if err != nil {
        return nil, err
    }
    defer file.Close()

    var data map[string]interface{}
    if err := json.NewDecoder(file).Decode(&data); err != nil {
        return nil, err
    }

    events := data["SysmonEvents"].([]interface{})
    eventIDMap := make(map[string]string)
    for _, event := range events {
        eventMap := event.(map[string]interface{})
        eventIDMap[eventMap["ID"].(string)] = eventMap["Name"].(string)
    }

    return eventIDMap, nil
}

func loadTranslations(dirPath string) (map[string]map[string]string, error) {
    files := []string{"Alert.json", "common.json", "Desc.json", "DS.json", "Forensic.json", "Tactic.json", "Technique.json"}
    translations := make(map[string]map[string]string)

    for _, file := range files {
        filePath := fmt.Sprintf("%s/%s", dirPath, file)
        data, err := os.ReadFile(filePath)
        if err != nil {
            return nil, fmt.Errorf("error reading file %s: %v", file, err)
        }

        var fileTranslations map[string]string
        if err := json.Unmarshal(data, &fileTranslations); err != nil {
            return nil, fmt.Errorf("error unmarshaling file %s: %v", file, err)
        }

        category := strings.TrimSuffix(file, ".json")
        translations[category] = fileTranslations
    }

    return translations, nil
}

func translateRuleName(ruleName string) string {
    parts := strings.Split(ruleName, ",")
    translatedParts := make([]string, len(parts))

    for i, part := range parts {
        kv := strings.SplitN(part, "=", 2)
        if len(kv) != 2 {
            translatedParts[i] = part
            continue
        }

        key := strings.TrimSpace(kv[0])
        value := strings.TrimSpace(kv[1])

        switch key {
        case "Attack", "Technique", "Tactic", "DS", "Desc":
            if translated, ok := translations[key][value]; ok {
                value = translated
            }
        }

        translatedParts[i] = fmt.Sprintf("%s=%s", key, value)
    }

    return strings.Join(translatedParts, ",")
}

func convertToUTC(timeStr string) (string, error) {
    t, err := time.Parse(time.RFC3339, timeStr)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(time.RFC3339), nil
}

func convertToLocal(timeStr string) (string, error) {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, timeStr)
    if err != nil {
        return "", err
    }
    loc, _ := time.LoadLocation("Local")
    return t.In(loc).Format(layout), nil
}

func queryEventByID(eventID string) (map[string]string, error) {
    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "term": map[string]interface{}{
                "_id": eventID,
            },
        },
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("error response: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    if len(hits["hits"].([]interface{})) == 0 {
        return nil, fmt.Errorf("no event found with ID: %s", eventID)
    }

    doc := hits["hits"].([]interface{})[0].(map[string]interface{})
    source := doc["_source"].(map[string]interface{})

    eventData := EventData{
        ID: doc["_id"].(string),
    }

    if winlog, ok := source["winlog"].(map[string]interface{}); ok {
        if computerName, ok := winlog["computer_name"].(string); ok {
            eventData.ComputerName = computerName
        }

        if eventID, ok := winlog["event_id"].(string); ok {
            if translatedEventID, exists := eventIDMap[eventID]; exists {
                eventData.EventID = translatedEventID
            } else {
                eventData.EventID = eventID
            }
        }

        if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
            if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                eventData.RuleName = translateRuleName(ruleName)
                if strings.Contains(eventData.RuleName, "Attack=") {
                    attackPart := strings.Split(eventData.RuleName, ",")[0]
                    eventData.Attack = strings.Split(attackPart, "=")[1]
                }
            }

            if user, ok := eventDataMap["User"]; ok {
                eventData.User = user
            }

            if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                localTime, err := convertToLocal(utcTime)
                if err == nil {
                    eventData.Timestamp = localTime
                } else {
                    log.Printf("Error converting time: %v", err)
                    eventData.Timestamp = utcTime
                }
            }
        }
    }

    if host, ok := source["host"].(map[string]interface{}); ok {
        if ip, ok := host["ip"].(string); ok {
            eventData.HostIP = ip
        }
    }

    return map[string]string{
        "ID":                   eventData.ID,
        "Winlog事件数据UTC时间": eventData.Timestamp,
        "Winlog计算机名称":      eventData.ComputerName,
        "Winlog事件ID":         eventData.EventID,
        "Winlog事件数据规则名称": eventData.RuleName,
        "主机IP":               eventData.HostIP,
        "Winlog事件数据用户":    fmt.Sprintf("%v", eventData.User),
        "攻击":                 eventData.Attack,
    }, nil
}

func queryEvents(startTime, endTime, hostIP string, searchAfter []interface{}) (*EventQuery, error) {
    var buf bytes.Buffer

    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "winlog.event_data.UtcTime": map[string]interface{}{
                                "gte": startTime,
                                "lte": endTime,
                            },
                        },
                    },
                },
                "filter": []map[string]interface{}{},
            },
        },
        "sort": []map[string]interface{}{
            {
                "winlog.event_data.UtcTime": map[string]interface{}{
                    "order": "asc",
                },
            },
        },
        "size": pageSize,
    }

    if hostIP != "" {
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "match": map[string]interface{}{
                    "host.ip": hostIP,
                },
            })
    }

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("error response: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    totalHits := int64(hits["total"].(map[string]interface{})["value"].(float64))
    totalPages := int((totalHits + pageSize - 1) / pageSize)

    documents := make([]EventData, 0)
    for _, hit := range hits["hits"].([]interface{}) {
        doc := hit.(map[string]interface{})
        source := doc["_source"].(map[string]interface{})

        eventData := EventData{
            ID: doc["_id"].(string),
        }
        if sort, ok := doc["sort"].([]interface{}); ok {
            eventData.Sort = sort
        }
        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventData.ComputerName = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                if translatedEventID, exists := eventIDMap[eventID]; exists {
                    eventData.EventID = translatedEventID
                } else {
                    eventData.EventID = eventID
                }
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventData.RuleName = translateRuleName(ruleName)
                    if strings.Contains(eventData.RuleName, "Attack=") {
                        attackPart := strings.Split(eventData.RuleName, ",")[0]
                        eventData.Attack = strings.Split(attackPart, "=")[1]
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventData.User = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime, err := convertToLocal(utcTime)
                    if err == nil {
                        eventData.Timestamp = localTime
                    } else {
                        log.Printf("Error converting time: %v", err)
                        eventData.Timestamp = utcTime
                    }
                }
            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventData.HostIP = ip
            }
        }

        documents = append(documents, eventData)
    }

    var nextPageKey []interface{}
    if len(documents) > 0 {
        nextPageKey = documents[len(documents)-1].Sort
    }

    return &EventQuery{
        TotalHits:   totalHits,
        TotalPages:  totalPages,
        Documents:   documents,
        NextPageKey: nextPageKey,
    }, nil
}

func handleEventQuery(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")
    searchAfterStr := c.Query("searchAfter")

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Missing startTime or endTime"})
        return
    }

    var searchAfter []interface{}
    if searchAfterStr != "" {
        err := json.Unmarshal([]byte(searchAfterStr), &searchAfter)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid searchAfter parameter"})
            return
        }
    }

    eventQuery, err := queryEvents(startTime, endTime, hostIP, searchAfter)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQuery)
}

func HandleEventDetail(c *gin.Context) {
    eventID := c.Query("_id")
    if eventID == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Missing event ID"})
        return
    }

    eventDetail, err := queryEventByID(eventID)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventDetail)
}
