package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



// EventDataDnsQuery_Network 结构体定义了事件数据的字段
type EventDataDnsQuery_Network struct {
    IDDnsQuery_Network               string      `json:"_id"`
    TimestampDnsQuery_Network        string      `json:"winlog.event_data.UtcTime"`
    ComputerNameDnsQuery_Network     string      `json:"winlog.computer_name"`
    EventIDDnsQuery_Network          string      `json:"winlog.event_id"`
    RuleNameDnsQuery_Network         string      `json:"winlog.event_data.RuleName"`
    HostIPDnsQuery_Network           string      `json:"host.ip"`
    UserDnsQuery_Network             interface{} `json:"winlog.event_data.User"`
    SortDnsQuery_Network             []interface{} `json:"sort"`
    AttackDnsQuery_Network           string      `json:"attack"`
    TechniqueDnsQuery_Network        string      `json:"technique"`
    TacticDnsQuery_Network          string      `json:"tactic"`
    DSDnsQuery_Network               string      `json:"ds"`
    AlertDnsQuery_Network            string      `json:"alert"`
    DescDnsQuery_Network             string      `json:"desc"`
    ForensicDnsQuery_Network         string      `json:"forensic"`
    LevelDnsQuery_Network            string      `json:"level"`
    RiskDnsQuery_Network             string      `json:"risk"`
    TargetFilenameDnsQuery_Network   string      `json:"winlog.event_data.TargetFilename"`
    ImageDnsQuery_Network            string      `json:"winlog.event_data.Image"`
    ParentImageDnsQuery_Network      string      `json:"winlog.event_data.ParentImage"`
    CommandLineDnsQuery_Network      string      `json:"winlog.event_data.CommandLine"`
    ParentCommandLineDnsQuery_Network string      `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedDnsQuery_Network      string      `json:"winlog.event_data.ImageLoaded"`
    QueryNameDnsQuery_Network        string      `json:"winlog.event_data.QueryName"`
    QueryResultsDnsQuery_Network     string      `json:"winlog.event_data.QueryResults"`
    QueryStatusDnsQuery_Network      string      `json:"winlog.event_data.QueryStatus"`
}

// EventQueryDnsQuery_Network 结构体定义了查询结果的格式
type EventQueryDnsQuery_Network struct {
    TotalHitsDnsQuery_Network   int64       `json:"totalHits"`
    TotalPagesDnsQuery_Network  int         `json:"totalPages"`
    DocumentsDnsQuery_Network   []EventDataDnsQuery_Network `json:"documents"`
    NextPageKeyDnsQuery_Network []interface{} `json:"nextPageKey,omitempty"`
}

var esDnsQuery_Network *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCDnsQuery_Network(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeDnsQuery_Network(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime // 如果解析失败，返回原始时间字符串
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexDnsQuery_Network(input string) string {
    if input == "" {
        return ""
    }
    escaped := regexp.QuoteMeta(input)
    parts := strings.Fields(escaped)
    for i, part := range parts {
        parts[i] = ".*" + part + ".*"
    }
    return strings.Join(parts, "")
}

func addTermQueryDnsQuery_Network(must *[]map[string]interface{}, field, value string) {
    if value != "" {
        *must = append(*must, map[string]interface{}{
            "term": map[string]interface{}{
                field: value,
            },
        })
    }
}

func queryEventsDnsQuery_Network(startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQueryDnsQuery_Network, error) {
    utcStartTime, err := convertToUTCDnsQuery_Network(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCDnsQuery_Network(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.ImageLoaded",
            "winlog.event_data.TargetFilename",
            "winlog.event_data.QueryName",
            "winlog.event_data.QueryResults",
            "winlog.event_data.QueryStatus",
        },
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryDnsQuery_Network(&must, "host.ip", hostIP)
    addTermQueryDnsQuery_Network(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_id", filters["event_id"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.TargetFilename", filters["TargetFilename"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.QueryName", filters["QueryName"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.QueryStatus", filters["QueryStatus"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    if queryResults, ok := filters["QueryResults"]; ok && queryResults != "" {
        must = append(must, map[string]interface{}{
            "query_string": map[string]interface{}{
                "default_field": "winlog.event_data.QueryResults",
                "query":         fmt.Sprintf("*%s*", queryResults),
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" && key != "TargetFilename" &&
            key != "QueryName" && key != "QueryStatus" && key != "QueryResults" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQuery := &EventQueryDnsQuery_Network{
        TotalHitsDnsQuery_Network: total,
        TotalPagesDnsQuery_Network: int((total + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsDnsQuery_Network:  make([]EventDataDnsQuery_Network, 0, len(documents)),
    }

    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventData := EventDataDnsQuery_Network{
            IDDnsQuery_Network: docMap["_id"].(string),
            SortDnsQuery_Network: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventData.ComputerNameDnsQuery_Network = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                eventData.EventIDDnsQuery_Network = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventData.RuleNameDnsQuery_Network = ruleName

                    parts := strings.Split(ruleName, ",") // 使用英文逗号分割
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventData.AttackDnsQuery_Network = value
                            case "Technique":
                                eventData.TechniqueDnsQuery_Network = value
                            case "Tactic":
                                eventData.TacticDnsQuery_Network = value
                            case "DS":
                                eventData.DSDnsQuery_Network = value
                            case "Level":
                                eventData.LevelDnsQuery_Network = value
                            case "Desc":
                                eventData.DescDnsQuery_Network = value
                            case "Forensic":
                                eventData.ForensicDnsQuery_Network = value
                            case "Risk":
                                eventData.RiskDnsQuery_Network = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventData.UserDnsQuery_Network = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTimeDnsQuery_Network(utcTime)
                    eventData.TimestampDnsQuery_Network = localTime
                }

                if image, ok := eventDataMap["Image"].(string); ok {
                    eventData.ImageDnsQuery_Network = image
                }
                if parentImage, ok := eventDataMap["ParentImage"].(string); ok {
                    eventData.ParentImageDnsQuery_Network = parentImage
                }
                if commandLine, ok := eventDataMap["CommandLine"].(string); ok {
                    eventData.CommandLineDnsQuery_Network = commandLine
                }
                if parentCommandLine, ok := eventDataMap["ParentCommandLine"].(string); ok {
                    eventData.ParentCommandLineDnsQuery_Network = parentCommandLine
                }
                if imageLoaded, ok := eventDataMap["ImageLoaded"].(string); ok {
                    eventData.ImageLoadedDnsQuery_Network = imageLoaded
                }

                if targetFilename, ok := eventDataMap["TargetFilename"].(string); ok {
                    eventData.TargetFilenameDnsQuery_Network = targetFilename
                }

                if queryName, ok := eventDataMap["QueryName"].(string); ok {
                    eventData.QueryNameDnsQuery_Network = queryName
                }

                if queryResults, ok := eventDataMap["QueryResults"].(string); ok {
                    eventData.QueryResultsDnsQuery_Network = queryResults
                }

                if queryStatus, ok := eventDataMap["QueryStatus"].(string); ok {
                    eventData.QueryStatusDnsQuery_Network = queryStatus
                }
            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventData.HostIPDnsQuery_Network = ip
            }
        }

        eventQuery.DocumentsDnsQuery_Network = append(eventQuery.DocumentsDnsQuery_Network, eventData)
    }

    if len(documents) > 0 {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        if sort, ok := lastDoc["sort"].([]interface{}); ok {
            eventQuery.NextPageKeyDnsQuery_Network = sort
        }
    }

    return eventQuery, nil
}

func queryRawEventsDnsQuery_Network(startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    utcStartTime, err := convertToUTCDnsQuery_Network(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCDnsQuery_Network(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryDnsQuery_Network(&must, "host.ip", hostIP)
    addTermQueryDnsQuery_Network(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_id", filters["event_id"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.TargetFilename", filters["TargetFilename"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.QueryName", filters["QueryName"])
    addTermQueryDnsQuery_Network(&must, "winlog.event_data.QueryStatus", filters["QueryStatus"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    if queryResults, ok := filters["QueryResults"]; ok && queryResults != "" {
        must = append(must, map[string]interface{}{
            "query_string": map[string]interface{}{
                "default_field": "winlog.event_data.QueryResults",
                "query":         fmt.Sprintf("*%s*", queryResults),
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" && key != "TargetFilename" &&
            key != "QueryName" && key != "QueryStatus" && key != "QueryResults" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}


// 启用 CORS
func enableCORSDnsQuery_Network(next http.HandlerFunc) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Access-Control-Allow-Origin", "*")
        w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")

        if r.Method == "OPTIONS" {
            w.WriteHeader(http.StatusNoContent)
            return
        }

        next.ServeHTTP(w, r)
    }
}

// 处理事件查询
func HandleEventQueryDnsQuery_Network(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")
    searchAfterStr := c.Query("searchAfter")
    imageLoaded := c.Query("imageLoaded")
    targetFilename := c.Query("TargetFilename")
    queryName := c.Query("QueryName")
    queryResults := c.Query("QueryResults")
    queryStatus := c.Query("QueryStatus")

    userParam, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filters := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParam,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexDnsQuery_Network(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexDnsQuery_Network(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoaded,
        "TargetFilename": targetFilename,
        "QueryName":     queryName,
        "QueryResults":  queryResults,
        "QueryStatus":   queryStatus,
    }

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfter []interface{}
    if searchAfterStr != "" {
        err := json.Unmarshal([]byte(searchAfterStr), &searchAfter)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQuery, err := queryEventsDnsQuery_Network(startTime, endTime, hostIP, searchAfter, filters)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQuery)
}

// 处理事件下载
func HandleEventDownloadDnsQuery_Network(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")
    imageLoaded := c.Query("imageLoaded")
    targetFilename := c.Query("TargetFilename")
    queryName := c.Query("QueryName")
    queryResults := c.Query("QueryResults")
    queryStatus := c.Query("QueryStatus")

    userParam, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filters := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParam,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexDnsQuery_Network(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexDnsQuery_Network(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoaded,
        "TargetFilename": targetFilename,
        "QueryName":     queryName,
        "QueryResults":  queryResults,
        "QueryStatus":   queryStatus,
    }

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawData, err := queryRawEventsDnsQuery_Network(startTime, endTime, hostIP, filters)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")
    c.Writer.Header().Set("Access-Control-Allow-Origin", "*") // 添加CORS头
    // 创建一个新的 JSON 编码器，设置缩进为两个空格
    encoder := json.NewEncoder(c.Writer)
    encoder.SetIndent("", "  ")

    // 编码并写入格式化的 JSON 数据
    if err := encoder.Encode(rawData); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Error encoding JSON"})
        return
    }
}

