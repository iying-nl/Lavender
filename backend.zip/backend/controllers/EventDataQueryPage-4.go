package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/url"
    "regexp"
    "strings"
    "time"
    "net/http"
    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



// EventDataSysmonServiceStateChanged 结构体定义了事件数据的字段
type EventDataSysmonServiceStateChanged struct {
    IDSysmonServiceStateChanged           string      `json:"_id"`
    TimestampSysmonServiceStateChanged    string      `json:"winlog.event_data.UtcTime"`
    ComputerNameSysmonServiceStateChanged string      `json:"winlog.computer_name"`
    EventIDSysmonServiceStateChanged      string      `json:"winlog.event_id"`
    RuleNameSysmonServiceStateChanged     string      `json:"winlog.event_data.RuleName"`
    HostIPSysmonServiceStateChanged       string      `json:"host.ip"`
    UserSysmonServiceStateChanged         interface{} `json:"winlog.event_data.User"`
    SortSysmonServiceStateChanged         []interface{} `json:"sort"`
    AttackSysmonServiceStateChanged       string      `json:"attack"`
    TechniqueSysmonServiceStateChanged    string      `json:"technique"`
    TacticSysmonServiceStateChanged       string      `json:"tactic"`
    DSSysmonServiceStateChanged           string      `json:"ds"`
    AlertSysmonServiceStateChanged        string      `json:"alert"`
    DescSysmonServiceStateChanged         string      `json:"desc"`
    ForensicSysmonServiceStateChanged     string      `json:"forensic"`
    LevelSysmonServiceStateChanged        string      `json:"level"`
    RiskSysmonServiceStateChanged         string      `json:"risk"`
    StateSysmonServiceStateChanged        string      `json:"state"` 
}

// EventQuerySysmonServiceStateChanged 结构体定义了查询结果的格式
type EventQuerySysmonServiceStateChanged struct {
    TotalHitsSysmonServiceStateChanged   int64                    `json:"totalHits"`
    TotalPagesSysmonServiceStateChanged  int                      `json:"totalPages"`
    DocumentsSysmonServiceStateChanged   []EventDataSysmonServiceStateChanged `json:"documents"`
    NextPageKeySysmonServiceStateChanged []interface{}            `json:"nextPageKey,omitempty"`
}

var esSysmonServiceStateChanged *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfgSysmonServiceStateChanged := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var errSysmonServiceStateChanged error
    esSysmonServiceStateChanged, errSysmonServiceStateChanged = elasticsearch.NewClient(cfgSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        log.Fatalf("创建客户端时出错: %s", errSysmonServiceStateChanged)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCSysmonServiceStateChanged(beijingTimeSysmonServiceStateChanged string) (string, error) {
    layoutSysmonServiceStateChanged := "2006-01-02T15:04:05Z"
    beijingLocSysmonServiceStateChanged, errSysmonServiceStateChanged := time.LoadLocation("Asia/Shanghai")
    if errSysmonServiceStateChanged != nil {
        return "", errSysmonServiceStateChanged
    }
    tSysmonServiceStateChanged, errSysmonServiceStateChanged := time.ParseInLocation(layoutSysmonServiceStateChanged, beijingTimeSysmonServiceStateChanged, beijingLocSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        return "", errSysmonServiceStateChanged
    }
    return tSysmonServiceStateChanged.UTC().Format(layoutSysmonServiceStateChanged), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeSysmonServiceStateChanged(utcTimeSysmonServiceStateChanged string) string {
    layoutSysmonServiceStateChanged := "2006-01-02 15:04:05.999"
    tSysmonServiceStateChanged, errSysmonServiceStateChanged := time.Parse(layoutSysmonServiceStateChanged, utcTimeSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        return utcTimeSysmonServiceStateChanged
    }
    beijingLocSysmonServiceStateChanged, _ := time.LoadLocation("Asia/Shanghai")
    beijingTimeSysmonServiceStateChanged := tSysmonServiceStateChanged.In(beijingLocSysmonServiceStateChanged)
    return beijingTimeSysmonServiceStateChanged.Format("2006-01-02 15:04:05.999")
}

func queryEventsSysmonServiceStateChanged(startTimeSysmonServiceStateChanged, endTimeSysmonServiceStateChanged, hostIPSysmonServiceStateChanged string, searchAfterSysmonServiceStateChanged []interface{}, filtersSysmonServiceStateChanged map[string]string) (*EventQuerySysmonServiceStateChanged, error) {
    utcStartTimeSysmonServiceStateChanged, errSysmonServiceStateChanged := convertToUTCSysmonServiceStateChanged(startTimeSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", errSysmonServiceStateChanged)
    }
    utcEndTimeSysmonServiceStateChanged, errSysmonServiceStateChanged := convertToUTCSysmonServiceStateChanged(endTimeSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", errSysmonServiceStateChanged)
    }

    var bufSysmonServiceStateChanged bytes.Buffer
    querySysmonServiceStateChanged := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeSysmonServiceStateChanged,
                                "lte": utcEndTimeSysmonServiceStateChanged,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.State", 
        },
    }

    if hostIPSysmonServiceStateChanged != "" {
        querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIPSysmonServiceStateChanged,
                },
            },
        )
    }

    if computerNameSysmonServiceStateChanged, okSysmonServiceStateChanged := filtersSysmonServiceStateChanged["computer_name"]; okSysmonServiceStateChanged && computerNameSysmonServiceStateChanged != "" {
        querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.computer_name": computerNameSysmonServiceStateChanged,
                },
            },
        )
    }

    if eventIDSysmonServiceStateChanged, okSysmonServiceStateChanged := filtersSysmonServiceStateChanged["event_id"]; okSysmonServiceStateChanged && eventIDSysmonServiceStateChanged != "" {
        querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.event_id": eventIDSysmonServiceStateChanged,
                },
            },
        )
    }

    if userSysmonServiceStateChanged, okSysmonServiceStateChanged := filtersSysmonServiceStateChanged["User"]; okSysmonServiceStateChanged && userSysmonServiceStateChanged != "" {
        escapedUserSysmonServiceStateChanged := regexp.QuoteMeta(userSysmonServiceStateChanged)
        querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "regexp": map[string]interface{}{
                    "winlog.event_data.User": ".*" + escapedUserSysmonServiceStateChanged + ".*",
                },
            },
        )
    }

    if stateSysmonServiceStateChanged, okSysmonServiceStateChanged := filtersSysmonServiceStateChanged["State"]; okSysmonServiceStateChanged && stateSysmonServiceStateChanged != "" {
        querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.event_data.State": stateSysmonServiceStateChanged,
                },
            },
        )
    }

    for keySysmonServiceStateChanged, valueSysmonServiceStateChanged := range filtersSysmonServiceStateChanged {
        if valueSysmonServiceStateChanged != "" && keySysmonServiceStateChanged != "computer_name" && keySysmonServiceStateChanged != "event_id" && keySysmonServiceStateChanged != "User" && keySysmonServiceStateChanged != "State" {
            encodedValueSysmonServiceStateChanged, errSysmonServiceStateChanged := json.Marshal(valueSysmonServiceStateChanged)
            if errSysmonServiceStateChanged != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", errSysmonServiceStateChanged)
            }
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                map[string]interface{}{
                    "script": map[string]interface{}{
                        "script": map[string]interface{}{
                            "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keySysmonServiceStateChanged, string(encodedValueSysmonServiceStateChanged)),
                            "lang":   "painless",
                        },
                    },
                },
            )
        }
    }

    if len(searchAfterSysmonServiceStateChanged) > 0 {
        querySysmonServiceStateChanged["search_after"] = searchAfterSysmonServiceStateChanged
    }

    if errSysmonServiceStateChanged := json.NewEncoder(&bufSysmonServiceStateChanged).Encode(querySysmonServiceStateChanged); errSysmonServiceStateChanged != nil {
        return nil, errSysmonServiceStateChanged
    }

    resSysmonServiceStateChanged, errSysmonServiceStateChanged := esSysmonServiceStateChanged.Search(
        esSysmonServiceStateChanged.Search.WithContext(context.Background()),
        esSysmonServiceStateChanged.Search.WithIndex(indexPattern),
        esSysmonServiceStateChanged.Search.WithBody(&bufSysmonServiceStateChanged),
        esSysmonServiceStateChanged.Search.WithTrackTotalHits(true),
    )
    if errSysmonServiceStateChanged != nil {
        return nil, errSysmonServiceStateChanged
    }
    defer resSysmonServiceStateChanged.Body.Close()

    if resSysmonServiceStateChanged.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resSysmonServiceStateChanged.String())
    }

    var rSysmonServiceStateChanged map[string]interface{}
    if errSysmonServiceStateChanged := json.NewDecoder(resSysmonServiceStateChanged.Body).Decode(&rSysmonServiceStateChanged); errSysmonServiceStateChanged != nil {
        return nil, errSysmonServiceStateChanged
    }

    hitsSysmonServiceStateChanged := rSysmonServiceStateChanged["hits"].(map[string]interface{})
    totalSysmonServiceStateChanged := int64(hitsSysmonServiceStateChanged["total"].(map[string]interface{})["value"].(float64))
    documentsSysmonServiceStateChanged := hitsSysmonServiceStateChanged["hits"].([]interface{})

    eventQuerySysmonServiceStateChanged := &EventQuerySysmonServiceStateChanged{
        TotalHitsSysmonServiceStateChanged:  totalSysmonServiceStateChanged,
        TotalPagesSysmonServiceStateChanged: int((totalSysmonServiceStateChanged + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsSysmonServiceStateChanged:  make([]EventDataSysmonServiceStateChanged, 0, len(documentsSysmonServiceStateChanged)),
    }

    for _, docSysmonServiceStateChanged := range documentsSysmonServiceStateChanged {
        docMapSysmonServiceStateChanged := docSysmonServiceStateChanged.(map[string]interface{})
        sourceSysmonServiceStateChanged := docMapSysmonServiceStateChanged["_source"].(map[string]interface{})

        eventDataSysmonServiceStateChanged := EventDataSysmonServiceStateChanged{
            IDSysmonServiceStateChanged:   docMapSysmonServiceStateChanged["_id"].(string),
            SortSysmonServiceStateChanged: docMapSysmonServiceStateChanged["sort"].([]interface{}),
        }

        if winlogSysmonServiceStateChanged, okSysmonServiceStateChanged := sourceSysmonServiceStateChanged["winlog"].(map[string]interface{}); okSysmonServiceStateChanged {
            if computerNameSysmonServiceStateChanged, okSysmonServiceStateChanged := winlogSysmonServiceStateChanged["computer_name"].(string); okSysmonServiceStateChanged {
                eventDataSysmonServiceStateChanged.ComputerNameSysmonServiceStateChanged = computerNameSysmonServiceStateChanged
            }

            if eventIDSysmonServiceStateChanged, okSysmonServiceStateChanged := winlogSysmonServiceStateChanged["event_id"].(string); okSysmonServiceStateChanged {
                eventDataSysmonServiceStateChanged.EventIDSysmonServiceStateChanged = eventIDSysmonServiceStateChanged
            }

            if eventDataMapSysmonServiceStateChanged, okSysmonServiceStateChanged := winlogSysmonServiceStateChanged["event_data"].(map[string]interface{}); okSysmonServiceStateChanged {
                if ruleNameSysmonServiceStateChanged, okSysmonServiceStateChanged := eventDataMapSysmonServiceStateChanged["RuleName"].(string); okSysmonServiceStateChanged {
                    eventDataSysmonServiceStateChanged.RuleNameSysmonServiceStateChanged = ruleNameSysmonServiceStateChanged
                    
                    partsSysmonServiceStateChanged := strings.Split(ruleNameSysmonServiceStateChanged, "，")
                    for _, partSysmonServiceStateChanged := range partsSysmonServiceStateChanged {
                        kvSysmonServiceStateChanged := strings.SplitN(partSysmonServiceStateChanged, "=", 2)
                        if len(kvSysmonServiceStateChanged) == 2 {
                            keySysmonServiceStateChanged := strings.TrimSpace(kvSysmonServiceStateChanged[0])
                            valueSysmonServiceStateChanged := strings.TrimSpace(kvSysmonServiceStateChanged[1])
                            switch keySysmonServiceStateChanged {
                            case "Attack":
                                eventDataSysmonServiceStateChanged.AttackSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            case "Technique":
                                eventDataSysmonServiceStateChanged.TechniqueSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            case "Tactic":
                                eventDataSysmonServiceStateChanged.TacticSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            case "DS":
                                eventDataSysmonServiceStateChanged.DSSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            case "Level":
                                eventDataSysmonServiceStateChanged.LevelSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            case "Desc":
                                eventDataSysmonServiceStateChanged.DescSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            case "Forensic":
                                eventDataSysmonServiceStateChanged.ForensicSysmonServiceStateChanged = valueSysmonServiceStateChanged                            
                            case "Risk":
                                eventDataSysmonServiceStateChanged.RiskSysmonServiceStateChanged = valueSysmonServiceStateChanged
                            }
                        }
                    }
                }

                if userSysmonServiceStateChanged, okSysmonServiceStateChanged := eventDataMapSysmonServiceStateChanged["User"]; okSysmonServiceStateChanged {
                    eventDataSysmonServiceStateChanged.UserSysmonServiceStateChanged = userSysmonServiceStateChanged
                }

                if utcTimeSysmonServiceStateChanged, okSysmonServiceStateChanged := eventDataMapSysmonServiceStateChanged["UtcTime"].(string); okSysmonServiceStateChanged {
                    localTimeSysmonServiceStateChanged := convertToBeijingTimeSysmonServiceStateChanged(utcTimeSysmonServiceStateChanged)
                    eventDataSysmonServiceStateChanged.TimestampSysmonServiceStateChanged = localTimeSysmonServiceStateChanged
                }

                if stateSysmonServiceStateChanged, okSysmonServiceStateChanged := eventDataMapSysmonServiceStateChanged["State"].(string); okSysmonServiceStateChanged {
                    eventDataSysmonServiceStateChanged.StateSysmonServiceStateChanged = stateSysmonServiceStateChanged
                }
            }
        }

        if hostSysmonServiceStateChanged, okSysmonServiceStateChanged := sourceSysmonServiceStateChanged["host"].(map[string]interface{}); okSysmonServiceStateChanged {
            if ipSysmonServiceStateChanged, okSysmonServiceStateChanged := hostSysmonServiceStateChanged["ip"].(string); okSysmonServiceStateChanged {
                eventDataSysmonServiceStateChanged.HostIPSysmonServiceStateChanged = ipSysmonServiceStateChanged
            }
        }

        eventQuerySysmonServiceStateChanged.DocumentsSysmonServiceStateChanged = append(eventQuerySysmonServiceStateChanged.DocumentsSysmonServiceStateChanged, eventDataSysmonServiceStateChanged)
    }

    if len(documentsSysmonServiceStateChanged) > 0 {
        lastDocSysmonServiceStateChanged := documentsSysmonServiceStateChanged[len(documentsSysmonServiceStateChanged)-1].(map[string]interface{})
        if sortSysmonServiceStateChanged, okSysmonServiceStateChanged := lastDocSysmonServiceStateChanged["sort"].([]interface{}); okSysmonServiceStateChanged {
            eventQuerySysmonServiceStateChanged.NextPageKeySysmonServiceStateChanged = sortSysmonServiceStateChanged
        }
    }

    return eventQuerySysmonServiceStateChanged, nil
}

func queryRawEventsSysmonServiceStateChanged(startTimeSysmonServiceStateChanged, endTimeSysmonServiceStateChanged, hostIPSysmonServiceStateChanged string, filtersSysmonServiceStateChanged map[string]string) ([]map[string]interface{}, error) {
    utcStartTimeSysmonServiceStateChanged, errSysmonServiceStateChanged := convertToUTCSysmonServiceStateChanged(startTimeSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", errSysmonServiceStateChanged)
    }
    utcEndTimeSysmonServiceStateChanged, errSysmonServiceStateChanged := convertToUTCSysmonServiceStateChanged(endTimeSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", errSysmonServiceStateChanged)
    }

    var bufSysmonServiceStateChanged bytes.Buffer
    querySysmonServiceStateChanged := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeSysmonServiceStateChanged,
                                "lte": utcEndTimeSysmonServiceStateChanged,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 100000000,
    }

    if hostIPSysmonServiceStateChanged != "" {
        querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIPSysmonServiceStateChanged,
                },
            },
        )
    }

    for keySysmonServiceStateChanged, valueSysmonServiceStateChanged := range filtersSysmonServiceStateChanged {
        if valueSysmonServiceStateChanged != "" {
            if keySysmonServiceStateChanged == "computer_name" || keySysmonServiceStateChanged == "event_id" {
                querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "term": map[string]interface{}{
                            fmt.Sprintf("winlog.%s", keySysmonServiceStateChanged): valueSysmonServiceStateChanged,
                        },
                    },
                )


            } else if keySysmonServiceStateChanged == "User" {
                escapedUserSysmonServiceStateChanged := regexp.QuoteMeta(valueSysmonServiceStateChanged)
                querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "regexp": map[string]interface{}{
                            "winlog.event_data.User": ".*" + escapedUserSysmonServiceStateChanged + ".*",
                        },
                    },
                )
            } else if keySysmonServiceStateChanged == "State" {
                querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "term": map[string]interface{}{
                            "winlog.event_data.State": valueSysmonServiceStateChanged,
                        },
                    },
                )
            } else {
                encodedValueSysmonServiceStateChanged, errSysmonServiceStateChanged := json.Marshal(valueSysmonServiceStateChanged)
                if errSysmonServiceStateChanged != nil {
                    return nil, fmt.Errorf("编码过滤值时出错: %v", errSysmonServiceStateChanged)
                }

                querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    querySysmonServiceStateChanged["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "script": map[string]interface{}{
                            "script": map[string]interface{}{
                                "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keySysmonServiceStateChanged, string(encodedValueSysmonServiceStateChanged)),
                                "lang":   "painless",
                            },
                        },
                    },
                )
            }
        }
    }

    if errSysmonServiceStateChanged := json.NewEncoder(&bufSysmonServiceStateChanged).Encode(querySysmonServiceStateChanged); errSysmonServiceStateChanged != nil {
        return nil, errSysmonServiceStateChanged
    }

    resSysmonServiceStateChanged, errSysmonServiceStateChanged := esSysmonServiceStateChanged.Search(
        esSysmonServiceStateChanged.Search.WithContext(context.Background()),
        esSysmonServiceStateChanged.Search.WithIndex(indexPattern),
        esSysmonServiceStateChanged.Search.WithBody(&bufSysmonServiceStateChanged),
        esSysmonServiceStateChanged.Search.WithTrackTotalHits(true),
    )
    if errSysmonServiceStateChanged != nil {
        return nil, errSysmonServiceStateChanged
    }
    defer resSysmonServiceStateChanged.Body.Close()

    if resSysmonServiceStateChanged.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resSysmonServiceStateChanged.String())
    }

    var rSysmonServiceStateChanged map[string]interface{}
    if errSysmonServiceStateChanged := json.NewDecoder(resSysmonServiceStateChanged.Body).Decode(&rSysmonServiceStateChanged); errSysmonServiceStateChanged != nil {
        return nil, errSysmonServiceStateChanged
    }

    hitsSysmonServiceStateChanged := rSysmonServiceStateChanged["hits"].(map[string]interface{})
    documentsSysmonServiceStateChanged := hitsSysmonServiceStateChanged["hits"].([]interface{})

    rawDataSysmonServiceStateChanged := make([]map[string]interface{}, len(documentsSysmonServiceStateChanged))
    for i, docSysmonServiceStateChanged := range documentsSysmonServiceStateChanged {
        rawDataSysmonServiceStateChanged[i] = docSysmonServiceStateChanged.(map[string]interface{})
    }

    return rawDataSysmonServiceStateChanged, nil
}

// 处理事件查询
func HandleEventQuerySysmonServiceStateChanged(cSysmonServiceStateChanged *gin.Context) {
    startTimeSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("startTime")
    endTimeSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("endTime")
    hostIPSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("hostIP")
    searchAfterStrSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("searchAfter")

    userParamSysmonServiceStateChanged, errSysmonServiceStateChanged := url.QueryUnescape(cSysmonServiceStateChanged.Query("User"))
    if errSysmonServiceStateChanged != nil {
        cSysmonServiceStateChanged.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersSysmonServiceStateChanged := map[string]string{
        "Attack":        cSysmonServiceStateChanged.Query("Attack"),
        "Technique":     cSysmonServiceStateChanged.Query("Technique"),
        "Tactic":        cSysmonServiceStateChanged.Query("Tactic"),
        "DS":            cSysmonServiceStateChanged.Query("DS"),
        "Alert":         cSysmonServiceStateChanged.Query("Alert"),
        "Desc":          cSysmonServiceStateChanged.Query("Desc"),
        "Forensic":      cSysmonServiceStateChanged.Query("Forensic"),
        "Level":         cSysmonServiceStateChanged.Query("Level"),
        "Risk":          cSysmonServiceStateChanged.Query("Risk"),
        "computer_name": cSysmonServiceStateChanged.Query("computer_name"),
        "event_id":      cSysmonServiceStateChanged.Query("event_id"),
        "User":          userParamSysmonServiceStateChanged,
        "State":         cSysmonServiceStateChanged.Query("State"), 
    }

    if startTimeSysmonServiceStateChanged == "" || endTimeSysmonServiceStateChanged == "" {
        cSysmonServiceStateChanged.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfterSysmonServiceStateChanged []interface{}
    if searchAfterStrSysmonServiceStateChanged != "" {
        errSysmonServiceStateChanged := json.Unmarshal([]byte(searchAfterStrSysmonServiceStateChanged), &searchAfterSysmonServiceStateChanged)
        if errSysmonServiceStateChanged != nil {
            cSysmonServiceStateChanged.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQuerySysmonServiceStateChanged, errSysmonServiceStateChanged := queryEventsSysmonServiceStateChanged(startTimeSysmonServiceStateChanged, endTimeSysmonServiceStateChanged, hostIPSysmonServiceStateChanged, searchAfterSysmonServiceStateChanged, filtersSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        cSysmonServiceStateChanged.JSON(http.StatusInternalServerError, gin.H{"error": errSysmonServiceStateChanged.Error()})
        return
    }

    cSysmonServiceStateChanged.JSON(http.StatusOK, eventQuerySysmonServiceStateChanged)
}

// 处理事件下载
func HandleEventDownloadSysmonServiceStateChanged(cSysmonServiceStateChanged *gin.Context) {
    startTimeSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("startTime")
    endTimeSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("endTime")
    hostIPSysmonServiceStateChanged := cSysmonServiceStateChanged.Query("hostIP")

    userParamSysmonServiceStateChanged, errSysmonServiceStateChanged := url.QueryUnescape(cSysmonServiceStateChanged.Query("User"))
    if errSysmonServiceStateChanged != nil {
        cSysmonServiceStateChanged.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersSysmonServiceStateChanged := map[string]string{
        "Attack":        cSysmonServiceStateChanged.Query("Attack"),
        "Technique":     cSysmonServiceStateChanged.Query("Technique"),
        "Tactic":        cSysmonServiceStateChanged.Query("Tactic"),
        "DS":            cSysmonServiceStateChanged.Query("DS"),
        "Alert":         cSysmonServiceStateChanged.Query("Alert"),
        "Desc":          cSysmonServiceStateChanged.Query("Desc"),
        "Forensic":      cSysmonServiceStateChanged.Query("Forensic"),
        "Level":         cSysmonServiceStateChanged.Query("Level"),
        "Risk":          cSysmonServiceStateChanged.Query("Risk"),
        "computer_name": cSysmonServiceStateChanged.Query("computer_name"),
        "event_id":      cSysmonServiceStateChanged.Query("event_id"),
        "User":          userParamSysmonServiceStateChanged,
        "State":         cSysmonServiceStateChanged.Query("State"), 
    }

    if startTimeSysmonServiceStateChanged == "" || endTimeSysmonServiceStateChanged == "" {
        cSysmonServiceStateChanged.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawDataSysmonServiceStateChanged, errSysmonServiceStateChanged := queryRawEventsSysmonServiceStateChanged(startTimeSysmonServiceStateChanged, endTimeSysmonServiceStateChanged, hostIPSysmonServiceStateChanged, filtersSysmonServiceStateChanged)
    if errSysmonServiceStateChanged != nil {
        cSysmonServiceStateChanged.JSON(http.StatusInternalServerError, gin.H{"error": errSysmonServiceStateChanged.Error()})
        return
    }

    cSysmonServiceStateChanged.Header("Content-Disposition", "attachment; filename=events.json")
    cSysmonServiceStateChanged.Header("Content-Type", "application/json")

    encoderSysmonServiceStateChanged := json.NewEncoder(cSysmonServiceStateChanged.Writer)
    encoderSysmonServiceStateChanged.SetIndent("", "  ")

    if errSysmonServiceStateChanged := encoderSysmonServiceStateChanged.Encode(rawDataSysmonServiceStateChanged); errSysmonServiceStateChanged != nil {
        cSysmonServiceStateChanged.JSON(http.StatusInternalServerError, gin.H{"error": "Error encoding JSON"})
        return
    }
}

