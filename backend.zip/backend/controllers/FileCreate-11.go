package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



// EventDataFileCreate 结构体定义了事件数据的字段
type EventDataFileCreate struct {
    IDFileCreate                string      `json:"_id"`
    TimestampFileCreate         string      `json:"winlog.event_data.UtcTime"`
    ComputerNameFileCreate      string      `json:"winlog.computer_name"`
    EventIDFileCreate           string      `json:"winlog.event_id"`
    RuleNameFileCreate          string      `json:"winlog.event_data.RuleName"`
    HostIPFileCreate            string      `json:"host.ip"`
    UserFileCreate              interface{} `json:"winlog.event_data.User"`
    SortFileCreate              []interface{} `json:"sort"`
    AttackFileCreate            string      `json:"attack"`
    TechniqueFileCreate         string      `json:"technique"`
    TacticFileCreate            string      `json:"tactic"`
    DSFileCreate                string      `json:"ds"`
    AlertFileCreate             string      `json:"alert"`
    DescFileCreate              string      `json:"desc"`
    ForensicFileCreate          string      `json:"forensic"`
    LevelFileCreate             string      `json:"level"`
    RiskFileCreate              string      `json:"risk"`
    TargetFilenameFileCreate    string      `json:"winlog.event_data.TargetFilename"`
    ImageFileCreate             string      `json:"winlog.event_data.Image"`
    ParentImageFileCreate       string      `json:"winlog.event_data.ParentImage"`
    CommandLineFileCreate       string      `json:"winlog.event_data.CommandLine"`
    ParentCommandLineFileCreate string      `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedFileCreate       string      `json:"winlog.event_data.ImageLoaded"`
}

// EventQueryFileCreate 结构体定义了查询结果的格式
type EventQueryFileCreate struct {
    TotalHitsFileCreate   int64               `json:"totalHits"`
    TotalPagesFileCreate  int                 `json:"totalPages"`
    DocumentsFileCreate   []EventDataFileCreate `json:"documents"`
    NextPageKeyFileCreate []interface{}       `json:"nextPageKey,omitempty"`
}

var esFileCreate *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    esFileCreate, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCFileCreate(beijingTimeFileCreate string) (string, error) {
    layoutFileCreate := "2006-01-02T15:04:05Z"
    beijingLocFileCreate, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layoutFileCreate, beijingTimeFileCreate, beijingLocFileCreate)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layoutFileCreate), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeFileCreate(utcTimeFileCreate string) string {
    layoutFileCreate := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layoutFileCreate, utcTimeFileCreate)
    if err != nil {
        return utcTimeFileCreate // 如果解析失败，返回原始时间字符串
    }
    beijingLocFileCreate, _ := time.LoadLocation("Asia/Shanghai")
    beijingTimeFileCreate := t.In(beijingLocFileCreate)
    return beijingTimeFileCreate.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexFileCreate(inputFileCreate string) string {
    if inputFileCreate == "" {
        return ""
    }
    escapedFileCreate := regexp.QuoteMeta(inputFileCreate)
    partsFileCreate := strings.Fields(escapedFileCreate)
    for i, part := range partsFileCreate {
        partsFileCreate[i] = ".*" + part + ".*"
    }
    return strings.Join(partsFileCreate, "")
}

func addTermQueryFileCreate(mustFileCreate *[]map[string]interface{}, fieldFileCreate, valueFileCreate string) {
    if valueFileCreate != "" {
        *mustFileCreate = append(*mustFileCreate, map[string]interface{}{
            "term": map[string]interface{}{
                fieldFileCreate: valueFileCreate,
            },
        })
    }
}

func queryEventsFileCreate(startTimeFileCreate, endTimeFileCreate, hostIPFileCreate string, searchAfterFileCreate []interface{}, filtersFileCreate map[string]string) (*EventQueryFileCreate, error) {
    utcStartTimeFileCreate, err := convertToUTCFileCreate(startTimeFileCreate)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTimeFileCreate, err := convertToUTCFileCreate(endTimeFileCreate)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var bufFileCreate bytes.Buffer
    queryFileCreate := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeFileCreate,
                                "lte": utcEndTimeFileCreate,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.ImageLoaded",
            "winlog.event_data.TargetFilename",
        },
    }

    mustFileCreate := queryFileCreate["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryFileCreate(&mustFileCreate, "host.ip", hostIPFileCreate)
    addTermQueryFileCreate(&mustFileCreate, "winlog.computer_name", filtersFileCreate["computer_name"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_id", filtersFileCreate["event_id"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.Image", filtersFileCreate["Image"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.ParentImage", filtersFileCreate["ParentImage"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.ImageLoaded", filtersFileCreate["imageLoaded"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.TargetFilename", filtersFileCreate["TargetFilename"])

    if userFileCreate, ok := filtersFileCreate["User"]; ok && userFileCreate != "" {
        escapedUserFileCreate := regexp.QuoteMeta(userFileCreate)
        mustFileCreate = append(mustFileCreate, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUserFileCreate + ".*",
            },
        })
    }

    if commandLineFileCreate, ok := filtersFileCreate["CommandLine"]; ok && commandLineFileCreate != "" {
        mustFileCreate = append(mustFileCreate, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLineFileCreate,
            },
        })
    }

    if parentCommandLineFileCreate, ok := filtersFileCreate["ParentCommandLine"]; ok && parentCommandLineFileCreate != "" {
        mustFileCreate = append(mustFileCreate, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLineFileCreate,
            },
        })
    }

    for keyFileCreate, valueFileCreate := range filtersFileCreate {
        if valueFileCreate != "" && keyFileCreate != "computer_name" && keyFileCreate != "event_id" && keyFileCreate != "User" &&
            keyFileCreate != "Image" && keyFileCreate != "ParentImage" && keyFileCreate != "CommandLine" && keyFileCreate != "ParentCommandLine" && keyFileCreate != "imageLoaded" && keyFileCreate != "TargetFilename" {
            encodedValueFileCreate, err := json.Marshal(valueFileCreate)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            mustFileCreate = append(mustFileCreate, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyFileCreate, string(encodedValueFileCreate)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    queryFileCreate["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = mustFileCreate

    if len(searchAfterFileCreate) > 0 {
        queryFileCreate["search_after"] = searchAfterFileCreate
    }

    if err := json.NewEncoder(&bufFileCreate).Encode(queryFileCreate); err != nil {
        return nil, err
    }

    resFileCreate, err := esFileCreate.Search(
        esFileCreate.Search.WithContext(context.Background()),
        esFileCreate.Search.WithIndex(indexPattern),
        esFileCreate.Search.WithBody(&bufFileCreate),
        esFileCreate.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer resFileCreate.Body.Close()

    if resFileCreate.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resFileCreate.String())
    }

    var rFileCreate map[string]interface{}
    if err := json.NewDecoder(resFileCreate.Body).Decode(&rFileCreate); err != nil {
        return nil, err
    }

    hitsFileCreate := rFileCreate["hits"].(map[string]interface{})
    totalFileCreate := int64(hitsFileCreate["total"].(map[string]interface{})["value"].(float64))
    documentsFileCreate := hitsFileCreate["hits"].([]interface{})

    eventQueryFileCreate := &EventQueryFileCreate{
        TotalHitsFileCreate:  totalFileCreate,
        TotalPagesFileCreate: int((totalFileCreate + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsFileCreate:  make([]EventDataFileCreate, 0, len(documentsFileCreate)),
    }

    for _, docFileCreate := range documentsFileCreate {
        docMapFileCreate := docFileCreate.(map[string]interface{})
        sourceFileCreate := docMapFileCreate["_source"].(map[string]interface{})

        eventDataFileCreate := EventDataFileCreate{
            IDFileCreate:   docMapFileCreate["_id"].(string),
            SortFileCreate: docMapFileCreate["sort"].([]interface{}),
        }

        if winlogFileCreate, ok := sourceFileCreate["winlog"].(map[string]interface{}); ok {
            if computerNameFileCreate, ok := winlogFileCreate["computer_name"].(string); ok {
                eventDataFileCreate.ComputerNameFileCreate = computerNameFileCreate
            }

            if eventIDFileCreate, ok := winlogFileCreate["event_id"].(string); ok {
                eventDataFileCreate.EventIDFileCreate = eventIDFileCreate
            }

            if eventDataMapFileCreate, ok := winlogFileCreate["event_data"].(map[string]interface{}); ok {
                if ruleNameFileCreate, ok := eventDataMapFileCreate["RuleName"].(string); ok {
                    eventDataFileCreate.RuleNameFileCreate = ruleNameFileCreate

                    partsFileCreate := strings.Split(ruleNameFileCreate, ",") // 使用英文逗号分割
                    for _, partFileCreate := range partsFileCreate {
                        kvFileCreate := strings.SplitN(partFileCreate, "=", 2)
                        if len(kvFileCreate) == 2 {
                            keyFileCreate := strings.TrimSpace(kvFileCreate[0])
                            valueFileCreate := strings.TrimSpace(kvFileCreate[1])
                            switch keyFileCreate {
                            case "Attack":
                                eventDataFileCreate.AttackFileCreate = valueFileCreate
                            case "Technique":
                                eventDataFileCreate.TechniqueFileCreate = valueFileCreate
                            case "Tactic":
                                eventDataFileCreate.TacticFileCreate = valueFileCreate
                            case "DS":
                                eventDataFileCreate.DSFileCreate = valueFileCreate
                            case "Level":
                                eventDataFileCreate.LevelFileCreate = valueFileCreate
                            case "Desc":
                                eventDataFileCreate.DescFileCreate = valueFileCreate
                            case "Forensic":
                                eventDataFileCreate.ForensicFileCreate = valueFileCreate
                            case "Risk":
                                eventDataFileCreate.RiskFileCreate = valueFileCreate
                            }
                        }
                    }
                }

                if userFileCreate, ok := eventDataMapFileCreate["User"]; ok {
                    eventDataFileCreate.UserFileCreate = userFileCreate
                }

                if utcTimeFileCreate, ok := eventDataMapFileCreate["UtcTime"].(string); ok {
                    localTimeFileCreate := convertToBeijingTimeFileCreate(utcTimeFileCreate)
                    eventDataFileCreate.TimestampFileCreate = localTimeFileCreate
                }

                if imageFileCreate, ok := eventDataMapFileCreate["Image"].(string); ok {
                    eventDataFileCreate.ImageFileCreate = imageFileCreate
                }
                if parentImageFileCreate, ok := eventDataMapFileCreate["ParentImage"].(string); ok {
                    eventDataFileCreate.ParentImageFileCreate = parentImageFileCreate
                }
                if commandLineFileCreate, ok := eventDataMapFileCreate["CommandLine"].(string); ok {
                    eventDataFileCreate.CommandLineFileCreate = commandLineFileCreate
                }
                if parentCommandLineFileCreate, ok := eventDataMapFileCreate["ParentCommandLine"].(string); ok {
                    eventDataFileCreate.ParentCommandLineFileCreate = parentCommandLineFileCreate
                }
                if imageLoadedFileCreate, ok := eventDataMapFileCreate["ImageLoaded"].(string); ok {
                    eventDataFileCreate.ImageLoadedFileCreate = imageLoadedFileCreate
                }

                if targetFilenameFileCreate, ok := eventDataMapFileCreate["TargetFilename"].(string); ok {
                    eventDataFileCreate.TargetFilenameFileCreate = targetFilenameFileCreate
                }
            }
        }

        if hostFileCreate, ok := sourceFileCreate["host"].(map[string]interface{}); ok {
            if ipFileCreate, ok := hostFileCreate["ip"].(string); ok {
                eventDataFileCreate.HostIPFileCreate = ipFileCreate
            }
        }

        eventQueryFileCreate.DocumentsFileCreate = append(eventQueryFileCreate.DocumentsFileCreate, eventDataFileCreate)
    }

    if len(documentsFileCreate) > 0 {
        lastDocFileCreate := documentsFileCreate[len(documentsFileCreate)-1].(map[string]interface{})
        if sortFileCreate, ok := lastDocFileCreate["sort"].([]interface{}); ok {
            eventQueryFileCreate.NextPageKeyFileCreate = sortFileCreate
        }
    }

    return eventQueryFileCreate, nil
}

func queryRawEventsFileCreate(startTimeFileCreate, endTimeFileCreate, hostIPFileCreate string, filtersFileCreate map[string]string) ([]map[string]interface{}, error) {
    utcStartTimeFileCreate, err := convertToUTCFileCreate(startTimeFileCreate)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTimeFileCreate, err := convertToUTCFileCreate(endTimeFileCreate)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var bufFileCreate bytes.Buffer
    queryFileCreate := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeFileCreate,
                                "lte": utcEndTimeFileCreate,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    mustFileCreate := queryFileCreate["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryFileCreate(&mustFileCreate, "host.ip", hostIPFileCreate)
    addTermQueryFileCreate(&mustFileCreate, "winlog.computer_name", filtersFileCreate["computer_name"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_id", filtersFileCreate["event_id"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.Image", filtersFileCreate["Image"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.ParentImage", filtersFileCreate["ParentImage"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.ImageLoaded", filtersFileCreate["imageLoaded"])
    addTermQueryFileCreate(&mustFileCreate, "winlog.event_data.TargetFilename", filtersFileCreate["TargetFilename"])

    if userFileCreate, ok := filtersFileCreate["User"]; ok && userFileCreate != "" {
        escapedUserFileCreate := regexp.QuoteMeta(userFileCreate)
        mustFileCreate = append(mustFileCreate, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUserFileCreate + ".*",
            },
        })
    }

    if commandLineFileCreate, ok := filtersFileCreate["CommandLine"]; ok && commandLineFileCreate != "" {
        mustFileCreate = append(mustFileCreate, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLineFileCreate,
            },
        })
    }

    if parentCommandLineFileCreate, ok := filtersFileCreate["ParentCommandLine"]; ok && parentCommandLineFileCreate != "" {
        mustFileCreate = append(mustFileCreate, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLineFileCreate,
            },
        })
    }

    for keyFileCreate, valueFileCreate := range filtersFileCreate {
        if valueFileCreate != "" && keyFileCreate != "computer_name" && keyFileCreate != "event_id" && keyFileCreate != "User" &&
            keyFileCreate != "Image" && keyFileCreate != "ParentImage" && keyFileCreate != "CommandLine" && keyFileCreate != "ParentCommandLine" && keyFileCreate != "imageLoaded" && keyFileCreate != "TargetFilename" {
            encodedValueFileCreate, err := json.Marshal(valueFileCreate)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            mustFileCreate = append(mustFileCreate, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyFileCreate, string(encodedValueFileCreate)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    queryFileCreate["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = mustFileCreate

    if err := json.NewEncoder(&bufFileCreate).Encode(queryFileCreate); err != nil {
        return nil, err
    }

    resFileCreate, err := esFileCreate.Search(
        esFileCreate.Search.WithContext(context.Background()),
        esFileCreate.Search.WithIndex(indexPattern),
        esFileCreate.Search.WithBody(&bufFileCreate),
        esFileCreate.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer resFileCreate.Body.Close()

    if resFileCreate.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resFileCreate.String())
    }

    var rFileCreate map[string]interface{}
    if err := json.NewDecoder(resFileCreate.Body).Decode(&rFileCreate); err != nil {
        return nil, err
    }

    hitsFileCreate := rFileCreate["hits"].(map[string]interface{})
    documentsFileCreate := hitsFileCreate["hits"].([]interface{})

    rawDataFileCreate := make([]map[string]interface{}, len(documentsFileCreate))
    for iFileCreate, docFileCreate := range documentsFileCreate {
        rawDataFileCreate[iFileCreate] = docFileCreate.(map[string]interface{})
    }

    return rawDataFileCreate, nil
}

// 处理事件查询
func HandleEventQueryFileCreate(cFileCreate *gin.Context) {
    startTimeFileCreate := cFileCreate.Query("startTime")
    endTimeFileCreate := cFileCreate.Query("endTime")
    hostIPFileCreate := cFileCreate.Query("hostIP")
    searchAfterStrFileCreate := cFileCreate.Query("searchAfter")
    imageLoadedFileCreate := cFileCreate.Query("imageLoaded")
    targetFilenameFileCreate := cFileCreate.Query("TargetFilename")

    userParamFileCreate, err := url.QueryUnescape(cFileCreate.Query("User"))
    if err != nil {
        cFileCreate.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersFileCreate := map[string]string{
        "Attack":            cFileCreate.Query("Attack"),
        "Technique":         cFileCreate.Query("Technique"),
        "Tactic":            cFileCreate.Query("Tactic"),
        "DS":                cFileCreate.Query("DS"),
        "Alert":             cFileCreate.Query("Alert"),
        "Desc":              cFileCreate.Query("Desc"),
        "Forensic":          cFileCreate.Query("Forensic"),
        "Level":             cFileCreate.Query("Level"),
        "Risk":              cFileCreate.Query("Risk"),
        "computer_name":     cFileCreate.Query("computer_name"),
        "event_id":          cFileCreate.Query("event_id"),
        "User":              userParamFileCreate,
        "Image":             cFileCreate.Query("Image"),
        "ParentImage":       cFileCreate.Query("ParentImage"),
        "CommandLine":       convertToRegexFileCreate(cFileCreate.Query("CommandLine")),
        "ParentCommandLine": convertToRegexFileCreate(cFileCreate.Query("ParentCommandLine")),
        "imageLoaded":       imageLoadedFileCreate,
        "TargetFilename":    targetFilenameFileCreate,
    }

    if startTimeFileCreate == "" || endTimeFileCreate == "" {
        cFileCreate.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfterFileCreate []interface{}
    if searchAfterStrFileCreate != "" {
        err := json.Unmarshal([]byte(searchAfterStrFileCreate), &searchAfterFileCreate)
        if err != nil {
            cFileCreate.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQueryFileCreate, err := queryEventsFileCreate(startTimeFileCreate, endTimeFileCreate, hostIPFileCreate, searchAfterFileCreate, filtersFileCreate)
    if err != nil {
        cFileCreate.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    cFileCreate.JSON(http.StatusOK, eventQueryFileCreate)
}

// 处理事件下载
func HandleEventDownloadFileCreate(cFileCreate *gin.Context) {
    startTimeFileCreate := cFileCreate.Query("startTime")
    endTimeFileCreate := cFileCreate.Query("endTime")
    hostIPFileCreate := cFileCreate.Query("hostIP")
    imageLoadedFileCreate := cFileCreate.Query("imageLoaded")
    targetFilenameFileCreate := cFileCreate.Query("TargetFilename")

    userParamFileCreate, err := url.QueryUnescape(cFileCreate.Query("User"))
    if err != nil {
        cFileCreate.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersFileCreate := map[string]string{
        "Attack":            cFileCreate.Query("Attack"),
        "Technique":         cFileCreate.Query("Technique"),
        "Tactic":            cFileCreate.Query("Tactic"),
        "DS":                cFileCreate.Query("DS"),
        "Alert":             cFileCreate.Query("Alert"),
        "Desc":              cFileCreate.Query("Desc"),
        "Forensic":          cFileCreate.Query("Forensic"),
        "Level":             cFileCreate.Query("Level"),
        "Risk":              cFileCreate.Query("Risk"),
        "computer_name":     cFileCreate.Query("computer_name"),
        "event_id":          cFileCreate.Query("event_id"),
        "User":              userParamFileCreate,
        "Image":             cFileCreate.Query("Image"),
        "ParentImage":       cFileCreate.Query("ParentImage"),
        "CommandLine":       convertToRegexFileCreate(cFileCreate.Query("CommandLine")),
        "ParentCommandLine": convertToRegexFileCreate(cFileCreate.Query("ParentCommandLine")),
        "imageLoaded":       imageLoadedFileCreate,
        "TargetFilename":    targetFilenameFileCreate,
    }

    if startTimeFileCreate == "" || endTimeFileCreate == "" {
        cFileCreate.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawDataFileCreate, err := queryRawEventsFileCreate(startTimeFileCreate, endTimeFileCreate, hostIPFileCreate, filtersFileCreate)
    if err != nil {
        cFileCreate.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    cFileCreate.Header("Content-Disposition", "attachment; filename=events.json")
    cFileCreate.Header("Content-Type", "application/json")
    encoderFileCreate := json.NewEncoder(cFileCreate.Writer)
    encoderFileCreate.SetIndent("", "  ")
    if err := encoderFileCreate.Encode(rawDataFileCreate); err != nil {
        cFileCreate.JSON(http.StatusInternalServerError, gin.H{"error": "Error encoding JSON"})
        return
    }
}
