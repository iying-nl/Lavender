package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"
    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



// EventDataFileCreateTime 结构体定义了事件数据的字段
type EventDataFileCreateTime struct {
    IDFileCreateTime                      string      `json:"_id"`
    TimestampFileCreateTime               string      `json:"winlog.event_data.UtcTime"`
    ComputerNameFileCreateTime            string      `json:"winlog.computer_name"`
    EventIDFileCreateTime                 string      `json:"winlog.event_id"`
    RuleNameFileCreateTime                string      `json:"winlog.event_data.RuleName"`
    HostIPFileCreateTime                  string      `json:"host.ip"`
    UserFileCreateTime                    interface{} `json:"winlog.event_data.User"`
    SortFileCreateTime                    []interface{} `json:"sort"`
    AttackFileCreateTime                  string      `json:"attack"`
    TechniqueFileCreateTime               string      `json:"technique"`
    TacticFileCreateTime                  string      `json:"tactic"`
    DSFileCreateTime                      string      `json:"ds"`
    AlertFileCreateTime                   string      `json:"alert"`
    DescFileCreateTime                    string      `json:"desc"`
    ForensicFileCreateTime                string      `json:"forensic"`
    LevelFileCreateTime                   string      `json:"level"`
    RiskFileCreateTime                    string      `json:"risk"`
    TargetFilenameFileCreateTime          string      `json:"winlog.event_data.TargetFilename"`
    ImageFileCreateTime                   string      `json:"winlog.event_data.Image"`
    ParentImageFileCreateTime             string      `json:"winlog.event_data.ParentImage"`
    CommandLineFileCreateTime             string      `json:"winlog.event_data.CommandLine"`
    ParentCommandLineFileCreateTime       string      `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedFileCreateTime             string      `json:"winlog.event_data.ImageLoaded"`
    CreationUtcTimeFileCreateTime         string      `json:"winlog.event_data.CreationUtcTime"`
    PreviousCreationUtcTimeFileCreateTime string      `json:"winlog.event_data.PreviousCreationUtcTime"`
}

// EventQueryFileCreateTime 结构体定义了查询结果的格式
type EventQueryFileCreateTime struct {
    TotalHitsFileCreateTime   int64               `json:"totalHits"`
    TotalPagesFileCreateTime  int                 `json:"totalPages"`
    DocumentsFileCreateTime   []EventDataFileCreateTime `json:"documents"`
    NextPageKeyFileCreateTime []interface{}       `json:"nextPageKey,omitempty"`
}

var esClientFileCreateTime *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfgFileCreateTime := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    esClientFileCreateTime, err = elasticsearch.NewClient(cfgFileCreateTime)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCFileCreateTime(beijingTimeFileCreateTime string) (string, error) {
    layoutFileCreateTime := "2006-01-02T15:04:05Z"
    beijingLocFileCreateTime, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    tFileCreateTime, err := time.ParseInLocation(layoutFileCreateTime, beijingTimeFileCreateTime, beijingLocFileCreateTime)
    if err != nil {
        return "", err
    }
    return tFileCreateTime.UTC().Format(layoutFileCreateTime), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeFileCreateTime(utcTimeFileCreateTime string) string {
    layoutFileCreateTime := "2006-01-02 15:04:05.999"
    tFileCreateTime, err := time.Parse(layoutFileCreateTime, utcTimeFileCreateTime)
    if err != nil {
        return utcTimeFileCreateTime // 如果解析失败，返回原始时间字符串
    }
    beijingLocFileCreateTime, _ := time.LoadLocation("Asia/Shanghai")
    beijingTimeFileCreateTime := tFileCreateTime.In(beijingLocFileCreateTime)
    return beijingTimeFileCreateTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexFileCreateTime(inputFileCreateTime string) string {
    if inputFileCreateTime == "" {
        return ""
    }
    escapedFileCreateTime := regexp.QuoteMeta(inputFileCreateTime)
    partsFileCreateTime := strings.Fields(escapedFileCreateTime)
    for i, part := range partsFileCreateTime {
        partsFileCreateTime[i] = ".*" + part + ".*"
    }
    return strings.Join(partsFileCreateTime, "")
}

func addTermQueryFileCreateTime(mustFileCreateTime *[]map[string]interface{}, fieldFileCreateTime, valueFileCreateTime string) {
    if valueFileCreateTime != "" {
        *mustFileCreateTime = append(*mustFileCreateTime, map[string]interface{}{
            "term": map[string]interface{}{
                fieldFileCreateTime: valueFileCreateTime,
            },
        })
    }
}

func queryEventsFileCreateTime(startTimeFileCreateTime, endTimeFileCreateTime, hostIPFileCreateTime string, searchAfterFileCreateTime []interface{}, filtersFileCreateTime map[string]string) (*EventQueryFileCreateTime, error) {
    utcStartTimeFileCreateTime, err := convertToUTCFileCreateTime(startTimeFileCreateTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTimeFileCreateTime, err := convertToUTCFileCreateTime(endTimeFileCreateTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var bufFileCreateTime bytes.Buffer
    queryFileCreateTime := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeFileCreateTime,
                                "lte": utcEndTimeFileCreateTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.ImageLoaded",
            "winlog.event_data.TargetFilename",
            "winlog.event_data.CreationUtcTime",
            "winlog.event_data.PreviousCreationUtcTime",
        },
    }

    mustFileCreateTime := queryFileCreateTime["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryFileCreateTime(&mustFileCreateTime, "host.ip", hostIPFileCreateTime)
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.computer_name", filtersFileCreateTime["computer_name"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_id", filtersFileCreateTime["event_id"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.Image", filtersFileCreateTime["Image"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.ParentImage", filtersFileCreateTime["ParentImage"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.ImageLoaded", filtersFileCreateTime["imageLoaded"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.TargetFilename", filtersFileCreateTime["TargetFilename"])

    if userFileCreateTime, ok := filtersFileCreateTime["User"]; ok && userFileCreateTime != "" {
        escapedUserFileCreateTime := regexp.QuoteMeta(userFileCreateTime)
        mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUserFileCreateTime + ".*",
            },
        })
    }

    if commandLineFileCreateTime, ok := filtersFileCreateTime["CommandLine"]; ok && commandLineFileCreateTime != "" {
        mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLineFileCreateTime, // 使用正则表达式
            },
        })
    }

    if parentCommandLineFileCreateTime, ok := filtersFileCreateTime["ParentCommandLine"]; ok && parentCommandLineFileCreateTime != "" {
        mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLineFileCreateTime, // 使用正则表达式
            },
        })
    }

    for keyFileCreateTime, valueFileCreateTime := range filtersFileCreateTime {
        if valueFileCreateTime != "" && keyFileCreateTime != "computer_name" && keyFileCreateTime != "event_id" && keyFileCreateTime != "User" &&
            keyFileCreateTime != "Image" && keyFileCreateTime != "ParentImage" && keyFileCreateTime != "CommandLine" && keyFileCreateTime != "ParentCommandLine" && keyFileCreateTime != "imageLoaded" && keyFileCreateTime != "TargetFilename" {
            encodedValueFileCreateTime, err := json.Marshal(valueFileCreateTime)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyFileCreateTime, string(encodedValueFileCreateTime)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    queryFileCreateTime["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = mustFileCreateTime

    if len(searchAfterFileCreateTime) > 0 {
        queryFileCreateTime["search_after"] = searchAfterFileCreateTime
    }

    if err := json.NewEncoder(&bufFileCreateTime).Encode(queryFileCreateTime); err != nil {
        return nil, err
    }

    resFileCreateTime, err := esClientFileCreateTime.Search(
        esClientFileCreateTime.Search.WithContext(context.Background()),
        esClientFileCreateTime.Search.WithIndex(indexPattern),
        esClientFileCreateTime.Search.WithBody(&bufFileCreateTime),
        esClientFileCreateTime.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer resFileCreateTime.Body.Close()

    if resFileCreateTime.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resFileCreateTime.String())
    }

    var rFileCreateTime map[string]interface{}
    if err := json.NewDecoder(resFileCreateTime.Body).Decode(&rFileCreateTime); err != nil {
        return nil, err
    }

    hitsFileCreateTime := rFileCreateTime["hits"].(map[string]interface{})
    totalFileCreateTime := int64(hitsFileCreateTime["total"].(map[string]interface{})["value"].(float64))
    documentsFileCreateTime := hitsFileCreateTime["hits"].([]interface{})

    eventQueryFileCreateTime := &EventQueryFileCreateTime{
        TotalHitsFileCreateTime:  totalFileCreateTime,
        TotalPagesFileCreateTime: int((totalFileCreateTime + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsFileCreateTime:  make([]EventDataFileCreateTime, 0, len(documentsFileCreateTime)),
    }

    for _, docFileCreateTime := range documentsFileCreateTime {
        docMapFileCreateTime := docFileCreateTime.(map[string]interface{})
        sourceFileCreateTime := docMapFileCreateTime["_source"].(map[string]interface{})

        eventDataFileCreateTime := EventDataFileCreateTime{
            IDFileCreateTime:   docMapFileCreateTime["_id"].(string),
            SortFileCreateTime: docMapFileCreateTime["sort"].([]interface{}),
        }

        if winlogFileCreateTime, ok := sourceFileCreateTime["winlog"].(map[string]interface{}); ok {
            if computerNameFileCreateTime, ok := winlogFileCreateTime["computer_name"].(string); ok {
                eventDataFileCreateTime.ComputerNameFileCreateTime = computerNameFileCreateTime
            }

            if eventIDFileCreateTime, ok := winlogFileCreateTime["event_id"].(string); ok {
                eventDataFileCreateTime.EventIDFileCreateTime = eventIDFileCreateTime
            }

            if eventDataMapFileCreateTime, ok := winlogFileCreateTime["event_data"].(map[string]interface{}); ok {
                if ruleNameFileCreateTime, ok := eventDataMapFileCreateTime["RuleName"].(string); ok {
                    eventDataFileCreateTime.RuleNameFileCreateTime = ruleNameFileCreateTime

                    // 使用正则表达式解析 RuleName
                    reFileCreateTime := regexp.MustCompile(`(\w+)=([^,]+)`)
                    matchesFileCreateTime := reFileCreateTime.FindAllStringSubmatch(ruleNameFileCreateTime, -1)

                    for _, matchFileCreateTime := range matchesFileCreateTime {
                        keyFileCreateTime := matchFileCreateTime[1]
                        valueFileCreateTime := matchFileCreateTime[2]
                        switch keyFileCreateTime {
                        case "Attack":
                            eventDataFileCreateTime.AttackFileCreateTime = valueFileCreateTime
                        case "Technique":
                            eventDataFileCreateTime.TechniqueFileCreateTime = valueFileCreateTime
                        case "Tactic":
                            eventDataFileCreateTime.TacticFileCreateTime = valueFileCreateTime
                        case "DS":
                            eventDataFileCreateTime.DSFileCreateTime = valueFileCreateTime
                        case "Level":
                            eventDataFileCreateTime.LevelFileCreateTime = valueFileCreateTime
                        case "Desc":
                            eventDataFileCreateTime.DescFileCreateTime = valueFileCreateTime
                        case "Forensic":
                            eventDataFileCreateTime.ForensicFileCreateTime = valueFileCreateTime
                        case "Risk":
                            eventDataFileCreateTime.RiskFileCreateTime = valueFileCreateTime
                        case "Alert":
                            eventDataFileCreateTime.AlertFileCreateTime = valueFileCreateTime
                        }
                    }
                }

                if userFileCreateTime, ok := eventDataMapFileCreateTime["User"]; ok {
                    eventDataFileCreateTime.UserFileCreateTime = userFileCreateTime
                }

                if utcTimeFileCreateTime, ok := eventDataMapFileCreateTime["UtcTime"].(string); ok {
                    localTimeFileCreateTime := convertToBeijingTimeFileCreateTime(utcTimeFileCreateTime)
                    eventDataFileCreateTime.TimestampFileCreateTime = localTimeFileCreateTime
                }

                if imageFileCreateTime, ok := eventDataMapFileCreateTime["Image"].(string); ok {
                    eventDataFileCreateTime.ImageFileCreateTime = imageFileCreateTime
                }
                if parentImageFileCreateTime, ok := eventDataMapFileCreateTime["ParentImage"].(string); ok {
                    eventDataFileCreateTime.ParentImageFileCreateTime = parentImageFileCreateTime
                }
                if commandLineFileCreateTime, ok := eventDataMapFileCreateTime["CommandLine"].(string); ok {
                    eventDataFileCreateTime.CommandLineFileCreateTime = commandLineFileCreateTime
                }
                if parentCommandLineFileCreateTime, ok := eventDataMapFileCreateTime["ParentCommandLine"].(string); ok {
                    eventDataFileCreateTime.ParentCommandLineFileCreateTime = parentCommandLineFileCreateTime
                }

                if imageLoadedFileCreateTime, ok := eventDataMapFileCreateTime["ImageLoaded"].(string); ok {
                    eventDataFileCreateTime.ImageLoadedFileCreateTime = imageLoadedFileCreateTime
                }

                if targetFilenameFileCreateTime, ok := eventDataMapFileCreateTime["TargetFilename"].(string); ok {
                    eventDataFileCreateTime.TargetFilenameFileCreateTime = targetFilenameFileCreateTime
                }

                if creationUtcTimeFileCreateTime, ok := eventDataMapFileCreateTime["CreationUtcTime"].(string); ok {
                    eventDataFileCreateTime.CreationUtcTimeFileCreateTime = convertToBeijingTimeFileCreateTime(creationUtcTimeFileCreateTime)
                }
                if previousCreationUtcTimeFileCreateTime, ok := eventDataMapFileCreateTime["PreviousCreationUtcTime"].(string); ok {
                    eventDataFileCreateTime.PreviousCreationUtcTimeFileCreateTime = convertToBeijingTimeFileCreateTime(previousCreationUtcTimeFileCreateTime)
                }
            }
        }

        if hostFileCreateTime, ok := sourceFileCreateTime["host"].(map[string]interface{}); ok {
            if ipFileCreateTime, ok := hostFileCreateTime["ip"].(string); ok {
                eventDataFileCreateTime.HostIPFileCreateTime = ipFileCreateTime
            }
        }

        eventQueryFileCreateTime.DocumentsFileCreateTime = append(eventQueryFileCreateTime.DocumentsFileCreateTime, eventDataFileCreateTime)
    }

    if len(documentsFileCreateTime) > 0 {
        lastDocFileCreateTime := documentsFileCreateTime[len(documentsFileCreateTime)-1].(map[string]interface{})
        if sortFileCreateTime, ok := lastDocFileCreateTime["sort"].([]interface{}); ok {
            eventQueryFileCreateTime.NextPageKeyFileCreateTime = sortFileCreateTime
        }
    }

    return eventQueryFileCreateTime, nil
}

func queryRawEventsFileCreateTime(startTimeFileCreateTime, endTimeFileCreateTime, hostIPFileCreateTime string, filtersFileCreateTime map[string]string) ([]map[string]interface{}, error) {
    utcStartTimeFileCreateTime, err := convertToUTCFileCreateTime(startTimeFileCreateTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTimeFileCreateTime, err := convertToUTCFileCreateTime(endTimeFileCreateTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var bufFileCreateTime bytes.Buffer
    queryFileCreateTime := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeFileCreateTime,
                                "lte": utcEndTimeFileCreateTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    mustFileCreateTime := queryFileCreateTime["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryFileCreateTime(&mustFileCreateTime, "host.ip", hostIPFileCreateTime)
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.computer_name", filtersFileCreateTime["computer_name"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_id", filtersFileCreateTime["event_id"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.Image", filtersFileCreateTime["Image"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.ParentImage", filtersFileCreateTime["ParentImage"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.ImageLoaded", filtersFileCreateTime["imageLoaded"])
    addTermQueryFileCreateTime(&mustFileCreateTime, "winlog.event_data.TargetFilename", filtersFileCreateTime["TargetFilename"])

    if userFileCreateTime, ok := filtersFileCreateTime["User"]; ok && userFileCreateTime != "" {
        escapedUserFileCreateTime := regexp.QuoteMeta(userFileCreateTime)
        mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUserFileCreateTime + ".*",
            },
        })
    }

    if commandLineFileCreateTime, ok := filtersFileCreateTime["CommandLine"]; ok && commandLineFileCreateTime != "" {
        mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLineFileCreateTime,
            },
        })
    }

    if parentCommandLineFileCreateTime, ok := filtersFileCreateTime["ParentCommandLine"]; ok && parentCommandLineFileCreateTime != "" {
        mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLineFileCreateTime,
            },
        })
    }

    for keyFileCreateTime, valueFileCreateTime := range filtersFileCreateTime {
        if valueFileCreateTime != "" && keyFileCreateTime != "computer_name" && keyFileCreateTime != "event_id" && keyFileCreateTime != "User" &&
            keyFileCreateTime != "Image" && keyFileCreateTime != "ParentImage" && keyFileCreateTime != "CommandLine" && keyFileCreateTime != "ParentCommandLine" && keyFileCreateTime != "imageLoaded" && keyFileCreateTime != "TargetFilename" {
            encodedValueFileCreateTime, err := json.Marshal(valueFileCreateTime)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            mustFileCreateTime = append(mustFileCreateTime, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyFileCreateTime, string(encodedValueFileCreateTime)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    queryFileCreateTime["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = mustFileCreateTime

    if err := json.NewEncoder(&bufFileCreateTime).Encode(queryFileCreateTime); err != nil {
        return nil, err
    }

    resFileCreateTime, err := esClientFileCreateTime.Search(
        esClientFileCreateTime.Search.WithContext(context.Background()),
        esClientFileCreateTime.Search.WithIndex(indexPattern),
        esClientFileCreateTime.Search.WithBody(&bufFileCreateTime),
        esClientFileCreateTime.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer resFileCreateTime.Body.Close()

    if resFileCreateTime.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resFileCreateTime.String())
    }

    var rFileCreateTime map[string]interface{}
    if err := json.NewDecoder(resFileCreateTime.Body).Decode(&rFileCreateTime); err != nil {
        return nil, err
    }

    hitsFileCreateTime := rFileCreateTime["hits"].(map[string]interface{})
    documentsFileCreateTime := hitsFileCreateTime["hits"].([]interface{})

    rawDataFileCreateTime := make([]map[string]interface{}, len(documentsFileCreateTime))
    for i, docFileCreateTime := range documentsFileCreateTime {
        rawDataFileCreateTime[i] = docFileCreateTime.(map[string]interface{})
        sourceFileCreateTime := rawDataFileCreateTime[i]["_source"].(map[string]interface{})
        if winlogFileCreateTime, ok := sourceFileCreateTime["winlog"].(map[string]interface{}); ok {
            if eventDataFileCreateTime, ok := winlogFileCreateTime["event_data"].(map[string]interface{}); ok {
                if creationUtcTimeFileCreateTime, ok := eventDataFileCreateTime["CreationUtcTime"].(string); ok {
                    eventDataFileCreateTime["CreationUtcTime"] = convertToBeijingTimeFileCreateTime(creationUtcTimeFileCreateTime)
                }
                if previousCreationUtcTimeFileCreateTime, ok := eventDataFileCreateTime["PreviousCreationUtcTime"].(string); ok {
                    eventDataFileCreateTime["PreviousCreationUtcTime"] = convertToBeijingTimeFileCreateTime(previousCreationUtcTimeFileCreateTime)
                }
            }
        }
    }

    return rawDataFileCreateTime, nil
}

// 处理事件查询
func HandleEventQueryFileCreateTime(c *gin.Context) {
    startTimeFileCreateTime := c.Query("startTime")
    endTimeFileCreateTime := c.Query("endTime")
    hostIPFileCreateTime := c.Query("hostIP")
    searchAfterStrFileCreateTime := c.Query("searchAfter")
    imageLoadedFileCreateTime := c.Query("imageLoaded")
    targetFilenameFileCreateTime := c.Query("TargetFilename")

    userParamFileCreateTime, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.String(http.StatusBadRequest, "Invalid User parameter")
        return
    }

    filtersFileCreateTime := map[string]string{
        "Attack":           c.Query("Attack"),
        "Technique":        c.Query("Technique"),
        "Tactic":           c.Query("Tactic"),
        "DS":               c.Query("DS"),
        "Alert":            c.Query("Alert"),
        "Desc":             c.Query("Desc"),
        "Forensic":         c.Query("Forensic"),
        "Level":            c.Query("Level"),
        "Risk":             c.Query("Risk"),
        "computer_name":    c.Query("computer_name"),
        "event_id":         c.Query("event_id"),
        "User":             userParamFileCreateTime,
        "Image":            c.Query("Image"),
        "ParentImage":      c.Query("ParentImage"),
        "CommandLine":      convertToRegexFileCreateTime(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexFileCreateTime(c.Query("ParentCommandLine")),
        "imageLoaded":      imageLoadedFileCreateTime,
        "TargetFilename":   targetFilenameFileCreateTime,
    }

    if startTimeFileCreateTime == "" || endTimeFileCreateTime == "" {
        c.String(http.StatusBadRequest, "缺少 startTime 或 endTime")
        return
    }

    var searchAfterFileCreateTime []interface{}
    if searchAfterStrFileCreateTime != "" {
        err := json.Unmarshal([]byte(searchAfterStrFileCreateTime), &searchAfterFileCreateTime)
        if err != nil {
            c.String(http.StatusBadRequest, "无效的 searchAfter 参数")
            return
        }
    }

    eventQueryFileCreateTime, err := queryEventsFileCreateTime(startTimeFileCreateTime, endTimeFileCreateTime, hostIPFileCreateTime, searchAfterFileCreateTime, filtersFileCreateTime)
    if err != nil {
        c.String(http.StatusInternalServerError, err.Error())
        return
    }

    c.JSON(http.StatusOK, eventQueryFileCreateTime)
}

// 处理事件下载
func HandleEventDownloadFileCreateTime(c *gin.Context) {
    startTimeFileCreateTime := c.Query("startTime")
    endTimeFileCreateTime := c.Query("endTime")
    hostIPFileCreateTime := c.Query("hostIP")
    imageLoadedFileCreateTime := c.Query("imageLoaded")
    targetFilenameFileCreateTime := c.Query("TargetFilename")

    userParamFileCreateTime, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.String(http.StatusBadRequest, "Invalid User parameter")
        return
    }

    filtersFileCreateTime := map[string]string{
        "Attack":           c.Query("Attack"),
        "Technique":        c.Query("Technique"),
        "Tactic":           c.Query("Tactic"),
        "DS":               c.Query("DS"),
        "Alert":            c.Query("Alert"),
        "Desc":             c.Query("Desc"),
        "Forensic":         c.Query("Forensic"),
        "Level":            c.Query("Level"),
        "Risk":             c.Query("Risk"),
        "computer_name":    c.Query("computer_name"),
        "event_id":         c.Query("event_id"),
        "User":             userParamFileCreateTime,
        "Image":            c.Query("Image"),
        "ParentImage":      c.Query("ParentImage"),
        "CommandLine":      convertToRegexFileCreateTime(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexFileCreateTime(c.Query("ParentCommandLine")),
        "imageLoaded":      imageLoadedFileCreateTime,
        "TargetFilename":   targetFilenameFileCreateTime,
    }

    if startTimeFileCreateTime == "" || endTimeFileCreateTime == "" {
        c.String(http.StatusBadRequest, "缺少 startTime 或 endTime")
        return
    }

    rawDataFileCreateTime, err := queryRawEventsFileCreateTime(startTimeFileCreateTime, endTimeFileCreateTime, hostIPFileCreateTime, filtersFileCreateTime)
    if err != nil {
        c.String(http.StatusInternalServerError, err.Error())
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")

    // 创建一个新的 JSON 编码器，设置缩进为两个空格
    encoderFileCreateTime := json.NewEncoder(c.Writer)
    encoderFileCreateTime.SetIndent("", "  ")

    // 编码并写入格式化的 JSON 数据
    if err := encoderFileCreateTime.Encode(rawDataFileCreateTime); err != nil {
        c.String(http.StatusInternalServerError, "Error encoding JSON")
        return
    }
}

