package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



// EventDataImageLoad 结构体定义了事件数据的字段
type EventDataImageLoad struct {
    IDImageLoad             string      `json:"_id"`
    TimestampImageLoad        string      `json:"winlog.event_data.UtcTime"`
    ComputerNameImageLoad    string      `json:"winlog.computer_name"`
    EventIDImageLoad         string      `json:"winlog.event_id"`
    RuleNameImageLoad        string      `json:"winlog.event_data.RuleName"`
    HostIPImageLoad          string      `json:"host.ip"`
    UserImageLoad            interface{} `json:"winlog.event_data.User"`
    SortImageLoad            []interface{} `json:"sort"`
    AttackImageLoad          string      `json:"attack"`
    TechniqueImageLoad       string      `json:"technique"`
    TacticImageLoad          string      `json:"tactic"`
    DSImageLoad              string      `json:"ds"`
    AlertImageLoad           string      `json:"alert"`
    DescImageLoad            string      `json:"desc"`
    ForensicImageLoad        string      `json:"forensic"`
    LevelImageLoad           string      `json:"level"`
    RiskImageLoad            string      `json:"risk"`
    ImageImageLoad           string      `json:"winlog.event_data.Image"`
    ParentImageImageLoad     string      `json:"winlog.event_data.ParentImage"`
    CommandLineImageLoad     string      `json:"winlog.event_data.CommandLine"`
    ParentCommandLineImageLoad string      `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedImageLoad      string      `json:"winlog.event_data.ImageLoaded"`
}

// EventQueryImageLoad 结构体定义了查询结果的格式
type EventQueryImageLoad struct {
    TotalHitsImageLoad   int64          `json:"totalHits"`
    TotalPagesImageLoad  int            `json:"totalPages"`
    DocumentsImageLoad   []EventDataImageLoad `json:"documents"`
    NextPageKeyImageLoad []interface{} `json:"nextPageKey,omitempty"`
}

var esImageLoad *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCImageLoad(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeImageLoad(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime // 如果解析失败，返回原始时间字符串
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexImageLoad(input string) string {
    if input == "" {
        return ""
    }
    escaped := regexp.QuoteMeta(input)
    parts := strings.Fields(escaped)
    for i, part := range parts {
        parts[i] = ".*" + part + ".*"
    }
    return strings.Join(parts, "")
}

func addTermQueryImageLoad(must *[]map[string]interface{}, field, value string) {
    if value != "" {
        *must = append(*must, map[string]interface{}{
            "term": map[string]interface{}{
                field: value,
            },
        })
    }
}

func queryEventsImageLoad(startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQueryImageLoad, error) {
    utcStartTime, err := convertToUTCImageLoad(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCImageLoad(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.ImageLoaded",
        },
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryImageLoad(&must, "host.ip", hostIP)
    addTermQueryImageLoad(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryImageLoad(&must, "winlog.event_id", filters["event_id"])
    addTermQueryImageLoad(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryImageLoad(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryImageLoad(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQueryImageLoad := &EventQueryImageLoad{
        TotalHitsImageLoad: total,
        TotalPagesImageLoad: int((total + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsImageLoad:  make([]EventDataImageLoad, 0, len(documents)),
    }

    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventDataImageLoad := EventDataImageLoad{
            IDImageLoad: docMap["_id"].(string),
            SortImageLoad: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventDataImageLoad.ComputerNameImageLoad = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                eventDataImageLoad.EventIDImageLoad = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventDataImageLoad.RuleNameImageLoad = ruleName

                    parts := strings.Split(ruleName, "，")
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventDataImageLoad.AttackImageLoad = value
                            case "Technique":
                                eventDataImageLoad.TechniqueImageLoad = value
                            case "Tactic":
                                eventDataImageLoad.TacticImageLoad = value
                            case "DS":
                                eventDataImageLoad.DSImageLoad = value
                            case "Level":
                                eventDataImageLoad.LevelImageLoad = value
                            case "Desc":
                                eventDataImageLoad.DescImageLoad = value
                            case "Forensic":
                                eventDataImageLoad.ForensicImageLoad = value
                            case "Risk":
                                eventDataImageLoad.RiskImageLoad = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventDataImageLoad.UserImageLoad = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTimeImageLoad(utcTime)
                    eventDataImageLoad.TimestampImageLoad = localTime
                }

                if image, ok := eventDataMap["Image"].(string); ok {
                    eventDataImageLoad.ImageImageLoad = image
                }
                if parentImage, ok := eventDataMap["ParentImage"].(string); ok {
                    eventDataImageLoad.ParentImageImageLoad = parentImage
                }
                if commandLine, ok := eventDataMap["CommandLine"].(string); ok {
                    eventDataImageLoad.CommandLineImageLoad = commandLine
                }
                if parentCommandLine, ok := eventDataMap["ParentCommandLine"].(string); ok {
                    eventDataImageLoad.ParentCommandLineImageLoad = parentCommandLine
                }
                if imageLoaded, ok := eventDataMap["ImageLoaded"].(string); ok {
                    eventDataImageLoad.ImageLoadedImageLoad = imageLoaded
                }
            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventDataImageLoad.HostIPImageLoad = ip
            }
        }

        eventQueryImageLoad.DocumentsImageLoad = append(eventQueryImageLoad.DocumentsImageLoad, eventDataImageLoad)
    }

    if len(documents) > 0 {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        if sort, ok := lastDoc["sort"].([]interface{}); ok {
            eventQueryImageLoad.NextPageKeyImageLoad = sort
        }
    }

    return eventQueryImageLoad, nil
}

func queryRawEventsImageLoad(startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    utcStartTime, err := convertToUTCImageLoad(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCImageLoad(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryImageLoad(&must, "host.ip", hostIP)
    addTermQueryImageLoad(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryImageLoad(&must, "winlog.event_id", filters["event_id"])
    addTermQueryImageLoad(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryImageLoad(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryImageLoad(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}

// 启用 CORS
func enableCORSImageLoad(next func(*gin.Context)) func(*gin.Context) {
    return func(c *gin.Context) {
        c.Header("Access-Control-Allow-Origin", "*")
        c.Header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        c.Header("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")

        if c.Request.Method == "OPTIONS" {
            c.AbortWithStatus(http.StatusNoContent)
            return
        }

        next(c)
    }
}

// 处理事件查询
func HandleEventQueryImageLoad(c *gin.Context) {
    startTimeImageLoad := c.Query("startTime")
    endTimeImageLoad := c.Query("endTime")
    hostIPImageLoad := c.Query("hostIP")
    searchAfterStrImageLoad := c.Query("searchAfter")
    imageLoadedImageLoad := c.Query("imageLoaded")

    userParamImageLoad, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersImageLoad := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamImageLoad,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexImageLoad(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexImageLoad(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoadedImageLoad,
    }

    if startTimeImageLoad == "" || endTimeImageLoad == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfterImageLoad []interface{}
    if searchAfterStrImageLoad != "" {
        err := json.Unmarshal([]byte(searchAfterStrImageLoad), &searchAfterImageLoad)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQueryImageLoad, err := queryEventsImageLoad(startTimeImageLoad, endTimeImageLoad, hostIPImageLoad, searchAfterImageLoad, filtersImageLoad)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQueryImageLoad)
}

// 处理事件下载
func HandleEventDownloadImageLoad(c *gin.Context) {
    startTimeImageLoad := c.Query("startTime")
    endTimeImageLoad := c.Query("endTime")
    hostIPImageLoad := c.Query("hostIP")
    imageLoadedImageLoad := c.Query("imageLoaded")

    userParamImageLoad, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersImageLoad := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamImageLoad,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexImageLoad(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexImageLoad(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoadedImageLoad,
    }

    if startTimeImageLoad == "" || endTimeImageLoad == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawDataImageLoad, err := queryRawEventsImageLoad(startTimeImageLoad, endTimeImageLoad, hostIPImageLoad, filtersImageLoad)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")

    // 创建一个新的 JSON 编码器，设置缩进为两个空格
    encoder := json.NewEncoder(c.Writer)
    encoder.SetIndent("", "  ")

    // 编码并写入格式化的 JSON 数据
    if err := encoder.Encode(rawDataImageLoad); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Error encoding JSON"})
        return
    }
}

