package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)


// EventData 结构体定义了事件数据的字段
type EventDataNetworkConnect struct {
    ID                  string      `json:"_id"`
    Timestamp           string      `json:"winlog.event_data.UtcTime"`
    ComputerName        string      `json:"winlog.computer_name"`
    EventID             string      `json:"winlog.event_id"`
    RuleName            string      `json:"winlog.event_data.RuleName"`
    HostIP              string      `json:"host.ip"`
    User                interface{} `json:"winlog.event_data.User"`
    Sort                []interface{} `json:"sort"`
    Attack              string      `json:"attack"`
    Technique           string      `json:"technique"`
    Tactic              string      `json:"tactic"`
    DS                  string      `json:"ds"`
    Alert               string      `json:"alert"`
    Desc                string      `json:"desc"`
    Forensic            string      `json:"forensic"`
    Level               string      `json:"level"`
    Risk                string      `json:"risk"`
    Protocol            string      `json:"winlog.event_data.Protocol"`
    Initiated           string      `json:"winlog.event_data.Initiated"`
    SourceIsIpv6        string      `json:"winlog.event_data.SourceIsIpv6"`
    SourceIp            string      `json:"winlog.event_data.SourceIp"`
    SourceHostname      string      `json:"winlog.event_data.SourceHostname"`
    SourcePort          string      `json:"winlog.event_data.SourcePort"`
    SourcePortName      string      `json:"winlog.event_data.SourcePortName"`
    DestinationIsIpv6   string      `json:"winlog.event_data.DestinationIsIpv6"`
    DestinationIp       string      `json:"winlog.event_data.DestinationIp"`
    DestinationHostname string      `json:"winlog.event_data.DestinationHostname"`
    DestinationPort     string      `json:"winlog.event_data.DestinationPort"`
    DestinationPortName string      `json:"winlog.event_data.DestinationPortName"`
    Image               string      `json:"winlog.event_data.Image"`
}

// EventQuery 结构体定义了查询结果的格式
type EventQueryNetworkConnect struct {
    TotalHits   int64       `json:"totalHits"`
    TotalPages  int         `json:"totalPages"`
    Documents   []EventDataNetworkConnect `json:"documents"`
    NextPageKey []interface{} `json:"nextPageKey,omitempty"`
}

var esNetworkConnect *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfgNetworkConnect := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    esNetworkConnect, err = elasticsearch.NewClient(cfgNetworkConnect)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCNetworkConnect(beijingTimeNetworkConnect string) (string, error) {
    layoutNetworkConnect := "2006-01-02T15:04:05Z"
    beijingLocNetworkConnect, errNetworkConnect := time.LoadLocation("Asia/Shanghai")
    if errNetworkConnect != nil {
        return "", errNetworkConnect
    }
    tNetworkConnect, errNetworkConnect := time.ParseInLocation(layoutNetworkConnect, beijingTimeNetworkConnect, beijingLocNetworkConnect)
    if errNetworkConnect != nil {
        return "", errNetworkConnect
    }
    return tNetworkConnect.UTC().Format(layoutNetworkConnect), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeNetworkConnect(utcTimeNetworkConnect string) string {
    layoutNetworkConnect := "2006-01-02 15:04:05.999"
    tNetworkConnect, errNetworkConnect := time.Parse(layoutNetworkConnect, utcTimeNetworkConnect)
    if errNetworkConnect != nil {
        return utcTimeNetworkConnect // 如果解析失败，返回原始时间字符串
    }
    beijingLocNetworkConnect, _ := time.LoadLocation("Asia/Shanghai")
    beijingTimeNetworkConnect := tNetworkConnect.In(beijingLocNetworkConnect)
    return beijingTimeNetworkConnect.Format("2006-01-02 15:04:05.999")
}

func queryEventsNetworkConnect(startTimeNetworkConnect, endTimeNetworkConnect, hostIPNetworkConnect string, searchAfterNetworkConnect []interface{}, filtersNetworkConnect map[string]string) (*EventQueryNetworkConnect, error) {
    utcStartTimeNetworkConnect, errNetworkConnect := convertToUTCNetworkConnect(startTimeNetworkConnect)
    if errNetworkConnect != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", errNetworkConnect)
    }
    utcEndTimeNetworkConnect, errNetworkConnect := convertToUTCNetworkConnect(endTimeNetworkConnect)
    if errNetworkConnect != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", errNetworkConnect)
    }

    var bufNetworkConnect bytes.Buffer
    queryNetworkConnect := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeNetworkConnect,
                                "lte": utcEndTimeNetworkConnect,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Protocol",
            "winlog.event_data.Initiated",
            "winlog.event_data.SourceIsIpv6",
            "winlog.event_data.SourceIp",
            "winlog.event_data.SourceHostname",
            "winlog.event_data.SourcePort",
            "winlog.event_data.SourcePortName",
            "winlog.event_data.DestinationIsIpv6",
            "winlog.event_data.DestinationIp",
            "winlog.event_data.DestinationHostname",
            "winlog.event_data.DestinationPort",
            "winlog.event_data.DestinationPortName",
            "winlog.event_data.Image",
        },
    }

    if hostIPNetworkConnect != "" {
        queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIPNetworkConnect,
                },
            },
        )
    }

    filterFieldsNetworkConnect := map[string]string{
        "winlog.computer_name":                 filtersNetworkConnect["computer_name"],
        "winlog.event_id":                      filtersNetworkConnect["event_id"],
        "winlog.event_data.Protocol":           filtersNetworkConnect["Protocol"],
        "winlog.event_data.Initiated":          filtersNetworkConnect["Initiated"],
        "winlog.event_data.SourceIsIpv6":       filtersNetworkConnect["SourceIsIpv6"],
        "winlog.event_data.SourceIp":           filtersNetworkConnect["SourceIp"],
        "winlog.event_data.SourceHostname":     filtersNetworkConnect["SourceHostname"],
        "winlog.event_data.SourcePort":         filtersNetworkConnect["SourcePort"],
        "winlog.event_data.SourcePortName":     filtersNetworkConnect["SourcePortName"],
        "winlog.event_data.DestinationIsIpv6":  filtersNetworkConnect["DestinationIsIpv6"],
        "winlog.event_data.DestinationIp":      filtersNetworkConnect["DestinationIp"],
        "winlog.event_data.DestinationHostname": filtersNetworkConnect["DestinationHostname"],
        "winlog.event_data.DestinationPort":    filtersNetworkConnect["DestinationPort"],
        "winlog.event_data.DestinationPortName": filtersNetworkConnect["DestinationPortName"],
        "winlog.event_data.Image":              filtersNetworkConnect["Image"],
    }

    for fieldNetworkConnect, valueNetworkConnect := range filterFieldsNetworkConnect {
        if valueNetworkConnect != "" {
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                map[string]interface{}{
                    "term": map[string]interface{}{
                        fieldNetworkConnect: valueNetworkConnect,
                    },
                },
            )
        }
    }

    if userNetworkConnect, okNetworkConnect := filtersNetworkConnect["User"]; okNetworkConnect && userNetworkConnect != "" {
        escapedUserNetworkConnect := regexp.QuoteMeta(userNetworkConnect)
        queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "regexp": map[string]interface{}{
                    "winlog.event_data.User": ".*" + escapedUserNetworkConnect + ".*",
                },
            },
        )
    }

    ruleNameFiltersNetworkConnect := []string{"Attack", "Technique", "Tactic", "DS", "Alert", "Desc", "Forensic", "Level", "Risk"}
    for _, keyNetworkConnect := range ruleNameFiltersNetworkConnect {
        if valueNetworkConnect, okNetworkConnect := filtersNetworkConnect[keyNetworkConnect]; okNetworkConnect && valueNetworkConnect != "" {
            encodedValueNetworkConnect, errNetworkConnect := json.Marshal(valueNetworkConnect)
            if errNetworkConnect != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", errNetworkConnect)
            }
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                map[string]interface{}{
                    "script": map[string]interface{}{
                        "script": map[string]interface{}{
                            "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyNetworkConnect, string(encodedValueNetworkConnect)),
                            "lang":   "painless",
                        },
                    },
                },
            )
        }
    }

    if len(searchAfterNetworkConnect) > 0 {
        queryNetworkConnect["search_after"] = searchAfterNetworkConnect
    }

    if errNetworkConnect := json.NewEncoder(&bufNetworkConnect).Encode(queryNetworkConnect); errNetworkConnect != nil {
        return nil, errNetworkConnect
    }

    resNetworkConnect, errNetworkConnect := esNetworkConnect.Search(
        esNetworkConnect.Search.WithContext(context.Background()),
        esNetworkConnect.Search.WithIndex(indexPattern),
        esNetworkConnect.Search.WithBody(&bufNetworkConnect),
        esNetworkConnect.Search.WithTrackTotalHits(true),
    )
    if errNetworkConnect != nil {
        return nil, errNetworkConnect
    }
    defer resNetworkConnect.Body.Close()

    if resNetworkConnect.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resNetworkConnect.String())
    }

    var rNetworkConnect map[string]interface{}
    if errNetworkConnect := json.NewDecoder(resNetworkConnect.Body).Decode(&rNetworkConnect); errNetworkConnect != nil {
        return nil, errNetworkConnect
    }

    hitsNetworkConnect := rNetworkConnect["hits"].(map[string]interface{})
    totalNetworkConnect := int64(hitsNetworkConnect["total"].(map[string]interface{})["value"].(float64))
    documentsNetworkConnect := hitsNetworkConnect["hits"].([]interface{})

    eventQueryNetworkConnect := &EventQueryNetworkConnect{
        TotalHits:  totalNetworkConnect,
        TotalPages: int((totalNetworkConnect + int64(pageSize) - 1) / int64(pageSize)),
        Documents:  make([]EventDataNetworkConnect, 0, len(documentsNetworkConnect)),
    }

    for _, docNetworkConnect := range documentsNetworkConnect {
        docMapNetworkConnect := docNetworkConnect.(map[string]interface{})
        sourceNetworkConnect := docMapNetworkConnect["_source"].(map[string]interface{})

        eventDataNetworkConnect := EventDataNetworkConnect{
            ID:   docMapNetworkConnect["_id"].(string),
            Sort: docMapNetworkConnect["sort"].([]interface{}),
        }

        if winlogNetworkConnect, okNetworkConnect := sourceNetworkConnect["winlog"].(map[string]interface{}); okNetworkConnect {
            if computerNameNetworkConnect, okNetworkConnect := winlogNetworkConnect["computer_name"].(string); okNetworkConnect {
                eventDataNetworkConnect.ComputerName = computerNameNetworkConnect
            }

            if eventIDNetworkConnect, okNetworkConnect := winlogNetworkConnect["event_id"].(string); okNetworkConnect {
                eventDataNetworkConnect.EventID = eventIDNetworkConnect
            }

            if eventDataMapNetworkConnect, okNetworkConnect := winlogNetworkConnect["event_data"].(map[string]interface{}); okNetworkConnect {
                if ruleNameNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["RuleName"].(string); okNetworkConnect {
                    eventDataNetworkConnect.RuleName = ruleNameNetworkConnect

                    // 使用英文逗号进行分割，并去除前导空格
                    partsNetworkConnect := strings.Split(ruleNameNetworkConnect, ",")
                    for _, partNetworkConnect := range partsNetworkConnect {
                        partNetworkConnect = strings.TrimSpace(partNetworkConnect)
                        kvNetworkConnect := strings.SplitN(partNetworkConnect, "=", 2)
                        if len(kvNetworkConnect) == 2 {
                            keyNetworkConnect := strings.TrimSpace(kvNetworkConnect[0])
                            valueNetworkConnect := strings.TrimSpace(kvNetworkConnect[1])
                            switch keyNetworkConnect {
                            case "Attack":
                                eventDataNetworkConnect.Attack = valueNetworkConnect
                            case "Technique":
                                eventDataNetworkConnect.Technique = valueNetworkConnect
                            case "Tactic":
                                eventDataNetworkConnect.Tactic = valueNetworkConnect
                            case "DS":
                                eventDataNetworkConnect.DS = valueNetworkConnect
                            case "Level":
                                eventDataNetworkConnect.Level = valueNetworkConnect
                            case "Desc":
                                eventDataNetworkConnect.Desc = valueNetworkConnect
                            case "Forensic":
                                eventDataNetworkConnect.Forensic = valueNetworkConnect
                            case "Risk":
                                eventDataNetworkConnect.Risk = valueNetworkConnect
                            }
                        }
                    }
                }
                if userNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["User"]; okNetworkConnect {
                    eventDataNetworkConnect.User = userNetworkConnect
                }

                if utcTimeNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["UtcTime"].(string); okNetworkConnect {
                    localTimeNetworkConnect := convertToBeijingTimeNetworkConnect(utcTimeNetworkConnect)
                    eventDataNetworkConnect.Timestamp = localTimeNetworkConnect
                }

                // 添加新的字段
                if protocolNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["Protocol"].(string); okNetworkConnect {
                    eventDataNetworkConnect.Protocol = protocolNetworkConnect
                }
                if initiatedNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["Initiated"].(string); okNetworkConnect {
                    eventDataNetworkConnect.Initiated = initiatedNetworkConnect
                }
                if sourceIsIpv6NetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["SourceIsIpv6"].(string); okNetworkConnect {
                    eventDataNetworkConnect.SourceIsIpv6 = sourceIsIpv6NetworkConnect
                }
                if sourceIpNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["SourceIp"].(string); okNetworkConnect {
                    eventDataNetworkConnect.SourceIp = sourceIpNetworkConnect
                }
                if sourceHostnameNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["SourceHostname"].(string); okNetworkConnect {
                    eventDataNetworkConnect.SourceHostname = sourceHostnameNetworkConnect
                }

                if sourcePortNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["SourcePort"].(string); okNetworkConnect {
                    eventDataNetworkConnect.SourcePort = sourcePortNetworkConnect
                }
                if sourcePortNameNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["SourcePortName"].(string); okNetworkConnect {
                    eventDataNetworkConnect.SourcePortName = sourcePortNameNetworkConnect
                }
                if destinationIsIpv6NetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["DestinationIsIpv6"].(string); okNetworkConnect {
                    eventDataNetworkConnect.DestinationIsIpv6 = destinationIsIpv6NetworkConnect
                }
                if destinationIpNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["DestinationIp"].(string); okNetworkConnect {
                    eventDataNetworkConnect.DestinationIp = destinationIpNetworkConnect
                }
                if destinationHostnameNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["DestinationHostname"].(string); okNetworkConnect {
                    eventDataNetworkConnect.DestinationHostname = destinationHostnameNetworkConnect
                }
                if destinationPortNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["DestinationPort"].(string); okNetworkConnect {
                    eventDataNetworkConnect.DestinationPort = destinationPortNetworkConnect
                }
                if destinationPortNameNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["DestinationPortName"].(string); okNetworkConnect {
                    eventDataNetworkConnect.DestinationPortName = destinationPortNameNetworkConnect
                }
                if imageNetworkConnect, okNetworkConnect := eventDataMapNetworkConnect["Image"].(string); okNetworkConnect {
                    eventDataNetworkConnect.Image = imageNetworkConnect
                }
            }
        }

        if hostNetworkConnect, okNetworkConnect := sourceNetworkConnect["host"].(map[string]interface{}); okNetworkConnect {
            if ipNetworkConnect, okNetworkConnect := hostNetworkConnect["ip"].(string); okNetworkConnect {
                eventDataNetworkConnect.HostIP = ipNetworkConnect
            }
        }

        eventQueryNetworkConnect.Documents = append(eventQueryNetworkConnect.Documents, eventDataNetworkConnect)
    }

    if len(documentsNetworkConnect) > 0 {
        lastDocNetworkConnect := documentsNetworkConnect[len(documentsNetworkConnect)-1].(map[string]interface{})
        if sortNetworkConnect, okNetworkConnect := lastDocNetworkConnect["sort"].([]interface{}); okNetworkConnect {
            eventQueryNetworkConnect.NextPageKey = sortNetworkConnect
        }
    }

    return eventQueryNetworkConnect, nil
}

func queryRawEventsNetworkConnect(startTimeNetworkConnect, endTimeNetworkConnect, hostIPNetworkConnect string, filtersNetworkConnect map[string]string) ([]map[string]interface{}, error) {
    utcStartTimeNetworkConnect, errNetworkConnect := convertToUTCNetworkConnect(startTimeNetworkConnect)
    if errNetworkConnect != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", errNetworkConnect)
    }
    utcEndTimeNetworkConnect, errNetworkConnect := convertToUTCNetworkConnect(endTimeNetworkConnect)
    if errNetworkConnect != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", errNetworkConnect)
    }

    var bufNetworkConnect bytes.Buffer
    queryNetworkConnect := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeNetworkConnect,
                                "lte": utcEndTimeNetworkConnect,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    if hostIPNetworkConnect != "" {
        queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIPNetworkConnect,
                },
            },
        )
    }

    filterFieldsNetworkConnect := map[string]string{
        "winlog.computer_name":                 filtersNetworkConnect["computer_name"],
        "winlog.event_id":                      filtersNetworkConnect["event_id"],
        "winlog.event_data.Protocol":           filtersNetworkConnect["Protocol"],
        "winlog.event_data.Initiated":          filtersNetworkConnect["Initiated"],
        "winlog.event_data.SourceIsIpv6":       filtersNetworkConnect["SourceIsIpv6"],
        "winlog.event_data.SourceIp":           filtersNetworkConnect["SourceIp"],
        "winlog.event_data.SourceHostname":     filtersNetworkConnect["SourceHostname"],
        "winlog.event_data.SourcePort":         filtersNetworkConnect["SourcePort"],
        "winlog.event_data.SourcePortName":     filtersNetworkConnect["SourcePortName"],
        "winlog.event_data.DestinationIsIpv6":  filtersNetworkConnect["DestinationIsIpv6"],
        "winlog.event_data.DestinationIp":      filtersNetworkConnect["DestinationIp"],
        "winlog.event_data.DestinationHostname": filtersNetworkConnect["DestinationHostname"],
        "winlog.event_data.DestinationPort":    filtersNetworkConnect["DestinationPort"],
        "winlog.event_data.DestinationPortName": filtersNetworkConnect["DestinationPortName"],
        "winlog.event_data.Image":              filtersNetworkConnect["Image"],
    }

    for fieldNetworkConnect, valueNetworkConnect := range filterFieldsNetworkConnect {
        if valueNetworkConnect != "" {
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                map[string]interface{}{
                    "term": map[string]interface{}{
                        fieldNetworkConnect: valueNetworkConnect,
                    },
                },
            )
        }
    }

    if userNetworkConnect, okNetworkConnect := filtersNetworkConnect["User"]; okNetworkConnect && userNetworkConnect != "" {
        escapedUserNetworkConnect := regexp.QuoteMeta(userNetworkConnect)
        queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "regexp": map[string]interface{}{
                    "winlog.event_data.User": ".*" + escapedUserNetworkConnect + ".*",
                },
            },
        )
    }

    ruleNameFiltersNetworkConnect := []string{"Attack", "Technique", "Tactic", "DS", "Alert", "Desc", "Forensic", "Level", "Risk"}
    for _, keyNetworkConnect := range ruleNameFiltersNetworkConnect {
        if valueNetworkConnect, okNetworkConnect := filtersNetworkConnect[keyNetworkConnect]; okNetworkConnect && valueNetworkConnect != "" {
            encodedValueNetworkConnect, errNetworkConnect := json.Marshal(valueNetworkConnect)
            if errNetworkConnect != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", errNetworkConnect)
            }
            queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                queryNetworkConnect["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                map[string]interface{}{
                    "script": map[string]interface{}{
                        "script": map[string]interface{}{
                            "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyNetworkConnect, string(encodedValueNetworkConnect)),
                            "lang":   "painless",
                        },
                    },
                },
            )
        }
    }

    if errNetworkConnect := json.NewEncoder(&bufNetworkConnect).Encode(queryNetworkConnect); errNetworkConnect != nil {
        return nil, errNetworkConnect
    }

    resNetworkConnect, errNetworkConnect := esNetworkConnect.Search(
        esNetworkConnect.Search.WithContext(context.Background()),
        esNetworkConnect.Search.WithIndex(indexPattern),
        esNetworkConnect.Search.WithBody(&bufNetworkConnect),
        esNetworkConnect.Search.WithTrackTotalHits(true),
    )
    if errNetworkConnect != nil {
        return nil, errNetworkConnect
    }
    defer resNetworkConnect.Body.Close()

    if resNetworkConnect.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resNetworkConnect.String())
    }

    var rNetworkConnect map[string]interface{}
    if errNetworkConnect := json.NewDecoder(resNetworkConnect.Body).Decode(&rNetworkConnect); errNetworkConnect != nil {
        return nil, errNetworkConnect
    }

    hitsNetworkConnect := rNetworkConnect["hits"].(map[string]interface{})
    documentsNetworkConnect := hitsNetworkConnect["hits"].([]interface{})

    rawDataNetworkConnect := make([]map[string]interface{}, len(documentsNetworkConnect))
    for iNetworkConnect, docNetworkConnect := range documentsNetworkConnect {
        rawDataNetworkConnect[iNetworkConnect] = docNetworkConnect.(map[string]interface{})
    }

    return rawDataNetworkConnect, nil
}



// 处理事件查询
func HandleEventQueryNetworkConnect(cNetworkConnect *gin.Context) {
    startTimeNetworkConnect := cNetworkConnect.Query("startTime")
    endTimeNetworkConnect := cNetworkConnect.Query("endTime")
    hostIPNetworkConnect := cNetworkConnect.Query("hostIP")
    searchAfterStrNetworkConnect := cNetworkConnect.Query("searchAfter")

    userParamNetworkConnect, errNetworkConnect := url.QueryUnescape(cNetworkConnect.Query("User"))
    if errNetworkConnect != nil {
        cNetworkConnect.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersNetworkConnect := map[string]string{
        "Attack":        cNetworkConnect.Query("Attack"),
        "Technique":     cNetworkConnect.Query("Technique"),
        "Tactic":        cNetworkConnect.Query("Tactic"),
        "DS":            cNetworkConnect.Query("DS"),
        "Alert":         cNetworkConnect.Query("Alert"),
        "Desc":          cNetworkConnect.Query("Desc"),
        "Forensic":      cNetworkConnect.Query("Forensic"),
        "Level":         cNetworkConnect.Query("Level"),
        "Risk":          cNetworkConnect.Query("Risk"),
        "computer_name": cNetworkConnect.Query("computer_name"),
        "event_id":      cNetworkConnect.Query("event_id"),
        "User":          userParamNetworkConnect,
        "Protocol":           cNetworkConnect.Query("Protocol"),
        "Initiated":          cNetworkConnect.Query("Initiated"),
        "SourceIsIpv6":       cNetworkConnect.Query("SourceIsIpv6"),
        "SourceIp":           cNetworkConnect.Query("SourceIp"),
        "SourceHostname":     cNetworkConnect.Query("SourceHostname"),
        "SourcePort":         cNetworkConnect.Query("SourcePort"),
        "SourcePortName":     cNetworkConnect.Query("SourcePortName"),
        "DestinationIsIpv6":  cNetworkConnect.Query("DestinationIsIpv6"),
        "DestinationIp":      cNetworkConnect.Query("DestinationIp"),
        "DestinationHostname": cNetworkConnect.Query("DestinationHostname"),
        "DestinationPort":    cNetworkConnect.Query("DestinationPort"),
        "DestinationPortName": cNetworkConnect.Query("DestinationPortName"),
        "Image":              cNetworkConnect.Query("Image"),
    }

    if startTimeNetworkConnect == "" || endTimeNetworkConnect == "" {
        cNetworkConnect.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfterNetworkConnect []interface{}
    if searchAfterStrNetworkConnect != "" {
        errNetworkConnect := json.Unmarshal([]byte(searchAfterStrNetworkConnect), &searchAfterNetworkConnect)
        if errNetworkConnect != nil {
            cNetworkConnect.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQueryNetworkConnect, errNetworkConnect := queryEventsNetworkConnect(startTimeNetworkConnect, endTimeNetworkConnect, hostIPNetworkConnect, searchAfterNetworkConnect, filtersNetworkConnect)
    if errNetworkConnect != nil {
        cNetworkConnect.JSON(http.StatusInternalServerError, gin.H{"error": errNetworkConnect.Error()})
        return
    }

    cNetworkConnect.JSON(http.StatusOK, eventQueryNetworkConnect)
}

// 处理事件下载
func HandleEventDownloadNetworkConnect(cNetworkConnect *gin.Context) {
    startTimeNetworkConnect := cNetworkConnect.Query("startTime")
    endTimeNetworkConnect := cNetworkConnect.Query("endTime")
    hostIPNetworkConnect := cNetworkConnect.Query("hostIP")

    userParamNetworkConnect, errNetworkConnect := url.QueryUnescape(cNetworkConnect.Query("User"))
    if errNetworkConnect != nil {
        cNetworkConnect.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersNetworkConnect := map[string]string{
        "Attack":        cNetworkConnect.Query("Attack"),
        "Technique":     cNetworkConnect.Query("Technique"),
        "Tactic":        cNetworkConnect.Query("Tactic"),
        "DS":            cNetworkConnect.Query("DS"),
        "Alert":         cNetworkConnect.Query("Alert"),
        "Desc":          cNetworkConnect.Query("Desc"),
        "Forensic":      cNetworkConnect.Query("Forensic"),
        "Level":         cNetworkConnect.Query("Level"),
        "Risk":          cNetworkConnect.Query("Risk"),
        "computer_name": cNetworkConnect.Query("computer_name"),
        "event_id":      cNetworkConnect.Query("event_id"),
        "User":          userParamNetworkConnect,
        "Protocol":           cNetworkConnect.Query("Protocol"),
        "Initiated":          cNetworkConnect.Query("Initiated"),
        "SourceIsIpv6":       cNetworkConnect.Query("SourceIsIpv6"),
        "SourceIp":           cNetworkConnect.Query("SourceIp"),
        "SourceHostname":     cNetworkConnect.Query("SourceHostname"),
        "SourcePort":         cNetworkConnect.Query("SourcePort"),
        "SourcePortName":     cNetworkConnect.Query("SourcePortName"),
        "DestinationIsIpv6":  cNetworkConnect.Query("DestinationIsIpv6"),
        "DestinationIp":      cNetworkConnect.Query("DestinationIp"),
        "DestinationHostname": cNetworkConnect.Query("DestinationHostname"),
        "DestinationPort":    cNetworkConnect.Query("DestinationPort"),
        "DestinationPortName": cNetworkConnect.Query("DestinationPortName"),
        "Image":              cNetworkConnect.Query("Image"),
    }

    if startTimeNetworkConnect == "" || endTimeNetworkConnect == "" {
        cNetworkConnect.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawDataNetworkConnect, errNetworkConnect := queryRawEventsNetworkConnect(startTimeNetworkConnect, endTimeNetworkConnect, hostIPNetworkConnect, filtersNetworkConnect)
    if errNetworkConnect != nil {
        cNetworkConnect.JSON(http.StatusInternalServerError, gin.H{"error": errNetworkConnect.Error()})
        return
    }

    cNetworkConnect.Header("Content-Disposition", "attachment; filename=events.json")
    cNetworkConnect.Header("Content-Type", "application/json")

    // 创建一个新的 JSON 编码器，设置缩进为两个空格
    encoderNetworkConnect := json.NewEncoder(cNetworkConnect.Writer)
    encoderNetworkConnect.SetIndent("", "  ")

    // 编码并写入格式化的 JSON 数据
    if errNetworkConnect := encoderNetworkConnect.Encode(rawDataNetworkConnect); errNetworkConnect != nil {
        cNetworkConnect.JSON(http.StatusInternalServerError, gin.H{"error": "Error encoding JSON"})
        return
    }
}

