package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)




// EventDataPipeConn_Pipe 结构体定义了事件数据的字段，包含 Sysmon 事件 17 的相关字段
type EventDataPipeConn_Pipe struct {
    IDPipeConn_Pipe          string      `json:"_id"`
    TimestampPipeConn_Pipe   string      `json:"winlog.event_data.UtcTime"`
    ComputerNamePipeConn_Pipe string      `json:"winlog.computer_name"`
    EventIDPipeConn_Pipe     string      `json:"winlog.event_id"`
    RuleNamePipeConn_Pipe    string      `json:"winlog.event_data.RuleName"`
    HostIPPipeConn_Pipe      string      `json:"host.ip"`
    UserPipeConn_Pipe        interface{} `json:"winlog.event_data.User"`
    SortPipeConn_Pipe        []interface{} `json:"sort"`
    // Sysmon Event 17 specific fields
    ProcessIDPipeConn_Pipe   string `json:"winlog.event_data.ProcessId"`
    ProcessGUIDPipeConn_Pipe string `json:"winlog.event_data.ProcessGuid"`
    ImagePipeConn_Pipe       string `json:"winlog.event_data.Image"`
    PipeNamePipeConn_Pipe    string `json:"winlog.event_data.PipeName"`
    EventTypePipeConn_Pipe   string `json:"winlog.event_data.EventType"`
    // Additional fields from RuleName
    AttackPipeConn_Pipe            string      `json:"attack"`
    TechniquePipeConn_Pipe         string      `json:"technique"`
    TacticPipeConn_Pipe            string      `json:"tactic"`
    DSPipeConn_Pipe                string      `json:"ds"`
    AlertPipeConn_Pipe             string      `json:"alert"`
    DescPipeConn_Pipe              string      `json:"desc"`
    ForensicPipeConn_Pipe          string      `json:"forensic"`
    LevelPipeConn_Pipe             string      `json:"level"`
    RiskPipeConn_Pipe              string      `json:"risk"`
}

// EventQueryPipeConn_Pipe 结构体定义了查询结果的格式
type EventQueryPipeConn_Pipe struct {
    TotalHitsPipeConn_Pipe   int64       `json:"totalHits"`
    TotalPagesPipeConn_Pipe  int         `json:"totalPages"`
    DocumentsPipeConn_Pipe   []EventDataPipeConn_Pipe `json:"documents"`
    NextPageKeyPipeConn_Pipe []interface{} `json:"nextPageKey,omitempty"`
}

var esPipeConn_Pipe *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCPipeConn_Pipe(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimePipeConn_Pipe(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime // 如果解析失败，返回原始时间字符串
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexPipeConn_Pipe(input string) string {
    if input == "" {
        return ""
    }
    escaped := regexp.QuoteMeta(input)
    parts := strings.Fields(escaped)
    for i, part := range parts {
        parts[i] = ".*" + part + ".*"
    }
    return strings.Join(parts, "")
}

func addTermQueryPipeConn_Pipe(must *[]map[string]interface{}, field, value string) {
    if value != "" {
        *must = append(*must, map[string]interface{}{
            "term": map[string]interface{}{
                field: value,
            },
        })
    }
}

func queryEventsPipeConn_Pipe(startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQueryPipeConn_Pipe, error) {
    utcStartTime, err := convertToUTCPipeConn_Pipe(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCPipeConn_Pipe(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.ProcessId",
            "winlog.event_data.ProcessGuid",
            "winlog.event_data.Image",
            "winlog.event_data.PipeName",
            "winlog.event_data.EventType",
        },
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    // 添加过滤条件
    addTermQueryPipeConn_Pipe(&must, "host.ip", hostIP)
    addTermQueryPipeConn_Pipe(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_id", filters["event_id"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.ProcessGuid", filters["ProcessGuid"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.PipeName", filters["PipeName"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.EventType", filters["EventType"])

    // 处理用户过滤
    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    // 处理其他过滤条件
    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ProcessId" && key != "ProcessGuid" &&
            key != "PipeName" && key != "EventType" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    // 添加 search_after 参数
    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    // 执行搜索
    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQuery := &EventQueryPipeConn_Pipe{
        TotalHitsPipeConn_Pipe:  total,
        TotalPagesPipeConn_Pipe: int((total + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsPipeConn_Pipe:  make([]EventDataPipeConn_Pipe, 0, len(documents)),
    }

    // 处理文档
    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventData := EventDataPipeConn_Pipe{
            IDPipeConn_Pipe: docMap["_id"].(string),
            SortPipeConn_Pipe: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventData.ComputerNamePipeConn_Pipe = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                eventData.EventIDPipeConn_Pipe = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventData.RuleNamePipeConn_Pipe = ruleName

                    parts := strings.Split(ruleName, ",") // 使用英文逗号分割
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventData.AttackPipeConn_Pipe = value
                            case "Technique":
                                eventData.TechniquePipeConn_Pipe = value
                            case "Tactic":
                                eventData.TacticPipeConn_Pipe = value
                            case "DS":
                                eventData.DSPipeConn_Pipe = value
                            case "Level":
                                eventData.LevelPipeConn_Pipe = value
                            case "Desc":
                                eventData.DescPipeConn_Pipe = value
                            case "Forensic":
                                eventData.ForensicPipeConn_Pipe = value
                            case "Risk":
                                eventData.RiskPipeConn_Pipe = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventData.UserPipeConn_Pipe = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTimePipeConn_Pipe(utcTime)
                    eventData.TimestampPipeConn_Pipe = localTime
                }

                // Sysmon Event 17 specific fields
                if processID, ok := eventDataMap["ProcessId"].(string); ok {
                    eventData.ProcessIDPipeConn_Pipe = processID
                }
                if processGUID, ok := eventDataMap["ProcessGuid"].(string); ok {
                    eventData.ProcessGUIDPipeConn_Pipe = processGUID
                }
                if image, ok := eventDataMap["Image"].(string); ok {
                    eventData.ImagePipeConn_Pipe = image
                }
                if pipeName, ok := eventDataMap["PipeName"].(string); ok {
                    eventData.PipeNamePipeConn_Pipe = pipeName
                }
                if eventType, ok := eventDataMap["EventType"].(string); ok {
                    eventData.EventTypePipeConn_Pipe = eventType
                }
            }
        }

        if timestamp, ok := source["@timestamp"].(string); ok {
            localTime := convertToBeijingTimePipeConn_Pipe(timestamp)
            eventData.TimestampPipeConn_Pipe = localTime
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventData.HostIPPipeConn_Pipe = ip
            }
        }

        eventQuery.DocumentsPipeConn_Pipe = append(eventQuery.DocumentsPipeConn_Pipe, eventData)
    }

    // 设置下一页的 key
    if len(documents) == pageSize {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        eventQuery.NextPageKeyPipeConn_Pipe = lastDoc["sort"].([]interface{})
    }

    return eventQuery, nil
}

func queryRawEventsPipeConn_Pipe(startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    utcStartTime, err := convertToUTCPipeConn_Pipe(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCPipeConn_Pipe(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 可以根据需要调整大小
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryPipeConn_Pipe(&must, "host.ip", hostIP)
    addTermQueryPipeConn_Pipe(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_id", filters["event_id"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.ProcessGuid", filters["ProcessGuid"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.PipeName", filters["PipeName"])
    addTermQueryPipeConn_Pipe(&must, "winlog.event_data.EventType", filters["EventType"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" && key != "Image" && key != "ProcessId" && key != "ProcessGuid" && key != "PipeName" && key != "EventType" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }
    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}

// 启用 CORS
func enableCORSPipeConn_Pipe(c *gin.Context) {
    c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
    c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")

    if c.Request.Method == "OPTIONS" {
        c.AbortWithStatus(http.StatusNoContent)
        return
    }
}

// 处理事件查询
func HandleEventQueryPipeConn_Pipe(c *gin.Context) {
    startTimePipeConn_Pipe := c.Query("startTime")
    endTimePipeConn_Pipe := c.Query("endTime")
    hostIPPipeConn_Pipe := c.Query("hostIP")
    searchAfterStrPipeConn_Pipe := c.Query("searchAfter")

    // URL解码 User 参数
    userParamPipeConn_Pipe, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        c.Abort()
        return
    }

    // 构建 filters map
    filtersPipeConn_Pipe := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamPipeConn_Pipe,
        "Image":         c.Query("Image"),
        "ProcessId":     c.Query("ProcessId"),
        "ProcessGuid":   c.Query("ProcessGuid"),
        "PipeName":      c.Query("PipeName"),
        "EventType":     c.Query("EventType"),
    }

    // 检查 startTime 和 endTime 是否为空
    if startTimePipeConn_Pipe == "" || endTimePipeConn_Pipe == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        c.Abort()
        return
    }

    // 解析 searchAfter 参数
    var searchAfterPipeConn_Pipe []interface{}
    if searchAfterStrPipeConn_Pipe != "" {
        err := json.Unmarshal([]byte(searchAfterStrPipeConn_Pipe), &searchAfterPipeConn_Pipe)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            c.Abort()
            return
        }
    }

    // 调用 queryEvents 函数查询数据
    eventQueryPipeConn_Pipe, err := queryEventsPipeConn_Pipe(startTimePipeConn_Pipe, endTimePipeConn_Pipe, hostIPPipeConn_Pipe, searchAfterPipeConn_Pipe, filtersPipeConn_Pipe)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        c.Abort()
        return
    }

    c.JSON(http.StatusOK, eventQueryPipeConn_Pipe)
}

// 处理事件下载
func HandleEventDownloadPipeConn_Pipe(c *gin.Context) {
    startTimePipeConn_Pipe := c.Query("startTime")
    endTimePipeConn_Pipe := c.Query("endTime")
    hostIPPipeConn_Pipe := c.Query("hostIP")

    userParamPipeConn_Pipe, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        c.Abort()
        return
    }

    filtersPipeConn_Pipe := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamPipeConn_Pipe,
        "Image":         c.Query("Image"),
        "ProcessId":     c.Query("ProcessId"),
        "ProcessGuid":   c.Query("ProcessGuid"),
        "PipeName":      c.Query("PipeName"),
        "EventType":     c.Query("EventType"),
    }

    if startTimePipeConn_Pipe == "" || endTimePipeConn_Pipe == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        c.Abort()
        return
    }

    rawDataPipeConn_Pipe, err := queryRawEventsPipeConn_Pipe(startTimePipeConn_Pipe, endTimePipeConn_Pipe, hostIPPipeConn_Pipe, filtersPipeConn_Pipe)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        c.Abort()
        return
    }

    c.Header("Content-Type", "application/json")
    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.JSON(http.StatusOK, rawDataPipeConn_Pipe)
}

