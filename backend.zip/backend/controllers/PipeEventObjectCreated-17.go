package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)


// EventDataPipeCreate_Pipe 结构体定义了事件数据的字段，包含 Sysmon 事件 17 的相关字段
type EventDataPipeCreate_Pipe struct {
    IDPipeCreate_Pipe          string      `json:"_id"`
    TimestampPipeCreate_Pipe   string      `json:"winlog.event_data.UtcTime"`
    ComputerNamePipeCreate_Pipe string      `json:"winlog.computer_name"`
    EventIDPipeCreate_Pipe     string      `json:"winlog.event_id"`
    RuleNamePipeCreate_Pipe    string      `json:"winlog.event_data.RuleName"`
    HostIPPipeCreate_Pipe      string      `json:"host.ip"`
    UserPipeCreate_Pipe        interface{} `json:"winlog.event_data.User"`
    SortPipeCreate_Pipe        []interface{} `json:"sort"`
    // Sysmon Event 17 specific fields
    ProcessIDPipeCreate_Pipe   string `json:"winlog.event_data.ProcessId"`
    ProcessGUIDPipeCreate_Pipe string `json:"winlog.event_data.ProcessGuid"`
    ImagePipeCreate_Pipe       string `json:"winlog.event_data.Image"`
    PipeNamePipeCreate_Pipe    string `json:"winlog.event_data.PipeName"`
    EventTypePipeCreate_Pipe   string `json:"winlog.event_data.EventType"`
    // Additional fields from RuleName
    AttackPipeCreate_Pipe            string      `json:"attack"`
    TechniquePipeCreate_Pipe         string      `json:"technique"`
    TacticPipeCreate_Pipe            string      `json:"tactic"`
    DSPipeCreate_Pipe                string      `json:"ds"`
    AlertPipeCreate_Pipe             string      `json:"alert"`
    DescPipeCreate_Pipe              string      `json:"desc"`
    ForensicPipeCreate_Pipe          string      `json:"forensic"`
    LevelPipeCreate_Pipe             string      `json:"level"`
    RiskPipeCreate_Pipe              string      `json:"risk"`
}

// EventQueryPipeCreate_Pipe 结构体定义了查询结果的格式
type EventQueryPipeCreate_Pipe struct {
    TotalHitsPipeCreate_Pipe   int64          `json:"totalHits"`
    TotalPagesPipeCreate_Pipe  int            `json:"totalPages"`
    DocumentsPipeCreate_Pipe   []EventDataPipeCreate_Pipe `json:"documents"`
    NextPageKeyPipeCreate_Pipe []interface{} `json:"nextPageKey,omitempty"`
}

var esPipeCreate_Pipe *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCPipeCreate_Pipe(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimePipeCreate_Pipe(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime // 如果解析失败，返回原始时间字符串
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexPipeCreate_Pipe(input string) string {
    if input == "" {
        return ""
    }
    escaped := regexp.QuoteMeta(input)
    parts := strings.Fields(escaped)
    for i, part := range parts {
        parts[i] = ".*" + part + ".*"
    }
    return strings.Join(parts, "")
}

func addTermQueryPipeCreate_Pipe(must *[]map[string]interface{}, field, value string) {
    if value != "" {
        *must = append(*must, map[string]interface{}{
            "term": map[string]interface{}{
                field: value,
            },
        })
    }
}

func queryEventsPipeCreate_Pipe(startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQueryPipeCreate_Pipe, error) {
    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": startTime,
                                "lte": endTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.ProcessId",
            "winlog.event_data.ProcessGuid",
            "winlog.event_data.Image",
            "winlog.event_data.PipeName",
            "winlog.event_data.EventType",
        },
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    // 添加过滤条件
    addTermQueryPipeCreate_Pipe(&must, "host.ip", hostIP)
    addTermQueryPipeCreate_Pipe(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_id", filters["event_id"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.ProcessGuid", filters["ProcessGuid"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.PipeName", filters["PipeName"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.EventType", filters["EventType"])

    // 处理用户过滤
    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    // 处理其他过滤条件
    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ProcessId" && key != "ProcessGuid" &&
            key != "PipeName" && key != "EventType" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQuery := &EventQueryPipeCreate_Pipe{
        TotalHitsPipeCreate_Pipe:  total,
        TotalPagesPipeCreate_Pipe: int((total + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsPipeCreate_Pipe:  make([]EventDataPipeCreate_Pipe, 0, len(documents)),
    }

    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventData := EventDataPipeCreate_Pipe{
            IDPipeCreate_Pipe: docMap["_id"].(string),
            SortPipeCreate_Pipe: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventData.ComputerNamePipeCreate_Pipe = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                eventData.EventIDPipeCreate_Pipe = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventData.RuleNamePipeCreate_Pipe = ruleName

                    parts := strings.Split(ruleName, ",") // 使用英文逗号分割
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventData.AttackPipeCreate_Pipe = value
                            case "Technique":
                                eventData.TechniquePipeCreate_Pipe = value
                            case "Tactic":
                                eventData.TacticPipeCreate_Pipe = value
                            case "DS":
                                eventData.DSPipeCreate_Pipe = value
                            case "Level":
                                eventData.LevelPipeCreate_Pipe = value
                            case "Desc":
                                eventData.DescPipeCreate_Pipe = value
                            case "Forensic":
                                eventData.ForensicPipeCreate_Pipe = value
                            case "Risk":
                                eventData.RiskPipeCreate_Pipe = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventData.UserPipeCreate_Pipe = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTimePipeCreate_Pipe(utcTime)
                    eventData.TimestampPipeCreate_Pipe = localTime
                }

                if processID, ok := eventDataMap["ProcessId"].(string); ok {
                    eventData.ProcessIDPipeCreate_Pipe = processID
                }
                if processGUID, ok := eventDataMap["ProcessGuid"].(string); ok {
                    eventData.ProcessGUIDPipeCreate_Pipe = processGUID
                }
                if image, ok := eventDataMap["Image"].(string); ok {
                    eventData.ImagePipeCreate_Pipe = image
                }
                if pipeName, ok := eventDataMap["PipeName"].(string); ok {
                    eventData.PipeNamePipeCreate_Pipe = pipeName
                }
                if eventType, ok := eventDataMap["EventType"].(string); ok {
                    eventData.EventTypePipeCreate_Pipe = eventType
                }

            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventData.HostIPPipeCreate_Pipe = ip
            }
        }

        eventQuery.DocumentsPipeCreate_Pipe = append(eventQuery.DocumentsPipeCreate_Pipe, eventData)
    }

    if len(documents) == pageSize {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        eventQuery.NextPageKeyPipeCreate_Pipe = lastDoc["sort"].([]interface{})
    }

    return eventQuery, nil
}

func queryRawEventsPipeCreate_Pipe(startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": startTime,
                                "lte": endTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 可以根据需要调整大小
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryPipeCreate_Pipe(&must, "host.ip", hostIP)
    addTermQueryPipeCreate_Pipe(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_id", filters["event_id"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.ProcessGuid", filters["ProcessGuid"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.PipeName", filters["PipeName"])
    addTermQueryPipeCreate_Pipe(&must, "winlog.event_data.EventType", filters["EventType"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" && key != "Image" && key != "ProcessId" && key != "ProcessGuid" && key != "PipeName" && key != "EventType" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }
    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}

func HandleEventQueryPipeCreate_Pipe(c *gin.Context) {
    startTimePipeCreate_Pipe := c.Query("startTime")
    endTimePipeCreate_Pipe := c.Query("endTime")
    hostIPPipeCreate_Pipe := c.Query("hostIP")
    searchAfterStrPipeCreate_Pipe := c.Query("searchAfter")

    userParamPipeCreate_Pipe, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersPipeCreate_Pipe := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamPipeCreate_Pipe,
        "Image":         c.Query("Image"),
        "ProcessId":     c.Query("ProcessId"),
        "ProcessGuid":   c.Query("ProcessGuid"),
        "PipeName":      c.Query("PipeName"),
        "EventType":     c.Query("EventType"),
    }

    if startTimePipeCreate_Pipe == "" || endTimePipeCreate_Pipe == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfterPipeCreate_Pipe []interface{}
    if searchAfterStrPipeCreate_Pipe != "" {
        err := json.Unmarshal([]byte(searchAfterStrPipeCreate_Pipe), &searchAfterPipeCreate_Pipe)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQuery, err := queryEventsPipeCreate_Pipe(startTimePipeCreate_Pipe, endTimePipeCreate_Pipe, hostIPPipeCreate_Pipe, searchAfterPipeCreate_Pipe, filtersPipeCreate_Pipe)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQuery)
}

func HandleEventDownloadPipeCreate_Pipe(c *gin.Context) {
    startTimePipeCreate_Pipe := c.Query("startTime")
    endTimePipeCreate_Pipe := c.Query("endTime")
    hostIPPipeCreate_Pipe := c.Query("hostIP")

    userParamPipeCreate_Pipe, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersPipeCreate_Pipe := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamPipeCreate_Pipe,
        "Image":         c.Query("Image"),
        "ProcessId":     c.Query("ProcessId"),
        "ProcessGuid":   c.Query("ProcessGuid"),
        "PipeName":      c.Query("PipeName"),
        "EventType":     c.Query("EventType"),
    }

    if startTimePipeCreate_Pipe == "" || endTimePipeCreate_Pipe == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawData, err := queryRawEventsPipeCreate_Pipe(startTimePipeCreate_Pipe, endTimePipeCreate_Pipe, hostIPPipeCreate_Pipe, filtersPipeCreate_Pipe)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.Header("Content-Type", "application/json")
    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.JSON(http.StatusOK, rawData)
}
