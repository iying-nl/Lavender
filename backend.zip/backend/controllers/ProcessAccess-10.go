package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



// EventDataProcessAccess 结构体定义了事件数据的字段
type EventDataProcessAccess struct {
    IDProcessAccess                string        `json:"_id"`
    TimestampProcessAccess         string        `json:"winlog.event_data.UtcTime"`
    ComputerNameProcessAccess      string        `json:"winlog.computer_name"`
    EventIDProcessAccess           string        `json:"winlog.event_id"`
    RuleNameProcessAccess          string        `json:"winlog.event_data.RuleName"`
    HostIPProcessAccess            string        `json:"host.ip"`
    SortProcessAccess              []interface{} `json:"sort"`

    // 事件11字段
    UserProcessAccess              string        `json:"winlog.event_data.User"`
    TargetFilenameProcessAccess    string        `json:"winlog.event_data.TargetFilename"`
    ImageProcessAccess             string        `json:"winlog.event_data.Image"`
    ParentImageProcessAccess       string        `json:"winlog.event_data.ParentImage"`
    CommandLineProcessAccess       string        `json:"winlog.event_data.CommandLine"`
    ParentCommandLineProcessAccess string        `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedProcessAccess       string        `json:"winlog.event_data.ImageLoaded"`

    // 事件10字段
    SourceUserProcessAccess        string        `json:"winlog.event_data.SourceUser"`
    TargetUserProcessAccess        string        `json:"winlog.event_data.TargetUser"`
    SourceImageProcessAccess       string        `json:"winlog.event_data.SourceImage"`
    TargetImageProcessAccess       string        `json:"winlog.event_data.TargetImage"`
    SourceProcessIdProcessAccess   string        `json:"winlog.event_data.SourceProcessId"`
    TargetProcessIdProcessAccess   string        `json:"winlog.event_data.TargetProcessId"`
    SourceProcessGUIDProcessAccess string        `json:"winlog.event_data.SourceProcessGUID"`
    TargetProcessGUIDProcessAccess string        `json:"winlog.event_data.TargetProcessGUID"`
    GrantedAccessProcessAccess     string        `json:"winlog.event_data.GrantedAccess"`
    CallTraceProcessAccess         string        `json:"winlog.event_data.CallTrace"`

    // RuleName解析字段
    AttackProcessAccess            string        `json:"attack"`
    TechniqueProcessAccess         string        `json:"technique"`
    TacticProcessAccess            string        `json:"tactic"`
    DSProcessAccess                string        `json:"ds"`
    AlertProcessAccess             string        `json:"alert"`
    DescProcessAccess              string        `json:"desc"`
    ForensicProcessAccess          string        `json:"forensic"`
    LevelProcessAccess             string        `json:"level"`
    RiskProcessAccess              string        `json:"risk"`
}

// EventQueryProcessAccess 结构体定义了查询结果的格式
type EventQueryProcessAccess struct {
    TotalHitsProcessAccess   int64       `json:"totalHits"`
    TotalPagesProcessAccess  int         `json:"totalPages"`
    DocumentsProcessAccess   []EventDataProcessAccess `json:"documents"`
    NextPageKeyProcessAccess []interface{} `json:"nextPageKey,omitempty"`
}

var esProcessAccess *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfgProcessAccess := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    esProcessAccess, err = elasticsearch.NewClient(cfgProcessAccess)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCProcessAccess(beijingTimeProcessAccess string) (string, error) {
    layoutProcessAccess := "2006-01-02T15:04:05Z"
    beijingLocProcessAccess, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layoutProcessAccess, beijingTimeProcessAccess, beijingLocProcessAccess)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layoutProcessAccess), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeProcessAccess(utcTimeProcessAccess string) string {
    layoutProcessAccess := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layoutProcessAccess, utcTimeProcessAccess)
    if err != nil {
        return utcTimeProcessAccess // 如果解析失败，返回原始时间字符串
    }
    beijingLocProcessAccess, _ := time.LoadLocation("Asia/Shanghai")
    beijingTimeProcessAccess := t.In(beijingLocProcessAccess)
    return beijingTimeProcessAccess.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexProcessAccess(inputProcessAccess string) string {
    if inputProcessAccess == "" {
        return ""
    }
    escapedProcessAccess := regexp.QuoteMeta(inputProcessAccess)
    partsProcessAccess := strings.Fields(escapedProcessAccess)
    for i, part := range partsProcessAccess {
        partsProcessAccess[i] = ".*" + part + ".*"
    }
    return strings.Join(partsProcessAccess, "")
}

func addTermQueryProcessAccess(mustProcessAccess *[]map[string]interface{}, fieldProcessAccess, valueProcessAccess string) {
    if valueProcessAccess != "" {
        *mustProcessAccess = append(*mustProcessAccess, map[string]interface{}{
            "term": map[string]interface{}{
                fieldProcessAccess: valueProcessAccess,
            },
        })
    }
}

func queryEventsProcessAccess(startTimeProcessAccess, endTimeProcessAccess, hostIPProcessAccess string, searchAfterProcessAccess []interface{}, filtersProcessAccess map[string]string) (*EventQueryProcessAccess, error) {
    utcStartTimeProcessAccess, err := convertToUTCProcessAccess(startTimeProcessAccess)
    if err != nil {
        return nil, fmt.Errorf("invalid start time: %v", err)
    }
    utcEndTimeProcessAccess, err := convertToUTCProcessAccess(endTimeProcessAccess)
    if err != nil {
        return nil, fmt.Errorf("invalid end time: %v", err)
    }

    var bufProcessAccess bytes.Buffer
    queryProcessAccess := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeProcessAccess,
                                "lte": utcEndTimeProcessAccess,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp", "winlog.computer_name", "winlog.event_data.RuleName",
            "host.ip", "winlog.event_id", "winlog.event_data.UtcTime",
            "winlog.event_data.TargetFilename", "winlog.event_data.Image",
            "winlog.event_data.ParentImage", "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine", "winlog.event_data.ImageLoaded",
            "winlog.event_data.User",
            // 事件10相关字段
            "winlog.event_data.SourceUser", "winlog.event_data.TargetUser",
            "winlog.event_data.SourceImage", "winlog.event_data.TargetImage",
            "winlog.event_data.SourceProcessId", "winlog.event_data.TargetProcessId",
            "winlog.event_data.SourceProcessGUID", "winlog.event_data.TargetProcessGUID",
            "winlog.event_data.GrantedAccess", "winlog.event_data.CallTrace",
        },
    }

    mustProcessAccess := queryProcessAccess["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    if hostIPProcessAccess != "" {
        addTermQueryProcessAccess(&mustProcessAccess, "host.ip", hostIPProcessAccess)
    }

    // 添加过滤条件
    for keyProcessAccess, valueProcessAccess := range filtersProcessAccess {
        if valueProcessAccess != "" {
            switch keyProcessAccess {
            case "computer_name", "event_id", "SourceImage", "TargetImage", "SourceProcessId", "TargetProcessId", "SourceProcessGUID", "TargetProcessGUID", "GrantedAccess":
                addTermQueryProcessAccess(&mustProcessAccess, "winlog."+keyProcessAccess, valueProcessAccess)
            case "imageLoaded", "TargetFilename", "Image", "ParentImage":
                addTermQueryProcessAccess(&mustProcessAccess, "winlog.event_data."+keyProcessAccess, valueProcessAccess)
            case "SourceUser", "TargetUser":
                escapedUserProcessAccess := regexp.QuoteMeta(valueProcessAccess)
                mustProcessAccess = append(mustProcessAccess, map[string]interface{}{
                    "regexp": map[string]interface{}{
                        "winlog.event_data." + keyProcessAccess: ".*" + escapedUserProcessAccess + ".*",
                    },
                })
            default:
                encodedValueProcessAccess, err := json.Marshal(valueProcessAccess)
                if err != nil {
                    return nil, fmt.Errorf("error encoding filter value: %v", err)
                }
                mustProcessAccess = append(mustProcessAccess, map[string]interface{}{
                    "script": map[string]interface{}{
                        "script": map[string]interface{}{
                            "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyProcessAccess, string(encodedValueProcessAccess)),
                            "lang":   "painless",
                        },
                    },
                })
            }
        }
    }

    queryProcessAccess["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = mustProcessAccess

    if len(searchAfterProcessAccess) > 0 {
        queryProcessAccess["search_after"] = searchAfterProcessAccess
    }

    if err := json.NewEncoder(&bufProcessAccess).Encode(queryProcessAccess); err != nil {
        return nil, err
    }

    resProcessAccess, err := esProcessAccess.Search(
        esProcessAccess.Search.WithContext(context.Background()),
        esProcessAccess.Search.WithIndex(indexPattern),
        esProcessAccess.Search.WithBody(&bufProcessAccess),
        esProcessAccess.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer resProcessAccess.Body.Close()

    if resProcessAccess.IsError() {
        return nil, fmt.Errorf("error response: %s", resProcessAccess.String())
    }

    var rProcessAccess map[string]interface{}
    if err := json.NewDecoder(resProcessAccess.Body).Decode(&rProcessAccess); err != nil {
        return nil, err
    }

    hitsProcessAccess := rProcessAccess["hits"].(map[string]interface{})
    totalProcessAccess := int64(hitsProcessAccess["total"].(map[string]interface{})["value"].(float64))
    documentsProcessAccess := hitsProcessAccess["hits"].([]interface{})

    eventQueryProcessAccess := &EventQueryProcessAccess{
        TotalHitsProcessAccess:  totalProcessAccess,
        TotalPagesProcessAccess: int((totalProcessAccess + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsProcessAccess:  make([]EventDataProcessAccess, 0, len(documentsProcessAccess)),
    }

    for _, docProcessAccess := range documentsProcessAccess {
        docMapProcessAccess := docProcessAccess.(map[string]interface{})
        sourceProcessAccess := docMapProcessAccess["_source"].(map[string]interface{})

        eventDataProcessAccess := EventDataProcessAccess{
            IDProcessAccess:   docMapProcessAccess["_id"].(string),
            SortProcessAccess: docMapProcessAccess["sort"].([]interface{}),
        }

        if winlogProcessAccess, ok := sourceProcessAccess["winlog"].(map[string]interface{}); ok {
            if computerNameProcessAccess, ok := winlogProcessAccess["computer_name"].(string); ok {
                eventDataProcessAccess.ComputerNameProcessAccess = computerNameProcessAccess
            }

            if eventIDProcessAccess, ok := winlogProcessAccess["event_id"].(string); ok {
                eventDataProcessAccess.EventIDProcessAccess = eventIDProcessAccess
            }

            if eventDataMapProcessAccess, ok := winlogProcessAccess["event_data"].(map[string]interface{}); ok {
                // 处理事件11字段
                if userProcessAccess, ok := eventDataMapProcessAccess["User"].(string); ok {
                    eventDataProcessAccess.UserProcessAccess = userProcessAccess
                }
                if targetFilenameProcessAccess, ok := eventDataMapProcessAccess["TargetFilename"].(string); ok {
                    eventDataProcessAccess.TargetFilenameProcessAccess = targetFilenameProcessAccess
                }
                if imageProcessAccess, ok := eventDataMapProcessAccess["Image"].(string); ok {
                    eventDataProcessAccess.ImageProcessAccess = imageProcessAccess
                }
                if parentImageProcessAccess, ok := eventDataMapProcessAccess["ParentImage"].(string); ok {
                    eventDataProcessAccess.ParentImageProcessAccess = parentImageProcessAccess
                }
                if commandLineProcessAccess, ok := eventDataMapProcessAccess["CommandLine"].(string); ok {
                    eventDataProcessAccess.CommandLineProcessAccess = commandLineProcessAccess
                }
                if parentCommandLineProcessAccess, ok := eventDataMapProcessAccess["ParentCommandLine"].(string); ok {
                    eventDataProcessAccess.ParentCommandLineProcessAccess = parentCommandLineProcessAccess
                }
                if imageLoadedProcessAccess, ok := eventDataMapProcessAccess["ImageLoaded"].(string); ok {
                    eventDataProcessAccess.ImageLoadedProcessAccess = imageLoadedProcessAccess
                }

                // 处理事件10字段
                if sourceUserProcessAccess, ok := eventDataMapProcessAccess["SourceUser"].(string); ok {
                    eventDataProcessAccess.SourceUserProcessAccess = sourceUserProcessAccess
                }
                if targetUserProcessAccess, ok := eventDataMapProcessAccess["TargetUser"].(string); ok {
                    eventDataProcessAccess.TargetUserProcessAccess = targetUserProcessAccess
                }
                if sourceImageProcessAccess, ok := eventDataMapProcessAccess["SourceImage"].(string); ok {
                    eventDataProcessAccess.SourceImageProcessAccess = sourceImageProcessAccess
                }
                if targetImageProcessAccess, ok := eventDataMapProcessAccess["TargetImage"].(string); ok {
                    eventDataProcessAccess.TargetImageProcessAccess = targetImageProcessAccess
                }
                if sourceProcessIdProcessAccess, ok := eventDataMapProcessAccess["SourceProcessId"].(string); ok {
                    eventDataProcessAccess.SourceProcessIdProcessAccess = sourceProcessIdProcessAccess
                }
                if targetProcessIdProcessAccess, ok := eventDataMapProcessAccess["TargetProcessId"].(string); ok {
                    eventDataProcessAccess.TargetProcessIdProcessAccess = targetProcessIdProcessAccess
                }
                if sourceProcessGUIDProcessAccess, ok := eventDataMapProcessAccess["SourceProcessGUID"].(string); ok {
                    eventDataProcessAccess.SourceProcessGUIDProcessAccess = sourceProcessGUIDProcessAccess
                }
                if targetProcessGUIDProcessAccess, ok := eventDataMapProcessAccess["TargetProcessGUID"].(string); ok {
                    eventDataProcessAccess.TargetProcessGUIDProcessAccess = targetProcessGUIDProcessAccess
                }
                if grantedAccessProcessAccess, ok := eventDataMapProcessAccess["GrantedAccess"].(string); ok {
                    eventDataProcessAccess.GrantedAccessProcessAccess = grantedAccessProcessAccess
                }
                if callTraceProcessAccess, ok := eventDataMapProcessAccess["CallTrace"].(string); ok {
                    eventDataProcessAccess.CallTraceProcessAccess = callTraceProcessAccess
                }

                // 处理 RuleName
                if ruleNameProcessAccess, ok := eventDataMapProcessAccess["RuleName"].(string); ok {
                    eventDataProcessAccess.RuleNameProcessAccess = ruleNameProcessAccess
                    partsProcessAccess := strings.Split(ruleNameProcessAccess, ",")
                    for _, partProcessAccess := range partsProcessAccess {
                        if strings.Contains(partProcessAccess, "=") {
                            kvProcessAccess := strings.SplitN(partProcessAccess, "=", 2)
                            if len(kvProcessAccess) == 2 {
                                keyProcessAccess := strings.TrimSpace(kvProcessAccess[0])
                                valueProcessAccess := strings.TrimSpace(kvProcessAccess[1])
                                switch keyProcessAccess {
                                case "Attack":
                                    eventDataProcessAccess.AttackProcessAccess = valueProcessAccess
                                case "Technique":
                                    eventDataProcessAccess.TechniqueProcessAccess = valueProcessAccess
                                case "Tactic":
                                    eventDataProcessAccess.TacticProcessAccess = valueProcessAccess
                                case "DS":
                                    eventDataProcessAccess.DSProcessAccess = valueProcessAccess
                                case "Alert":
                                    eventDataProcessAccess.AlertProcessAccess = valueProcessAccess
                                case "Level":
                                    eventDataProcessAccess.LevelProcessAccess = valueProcessAccess
                                case "Risk":
                                    eventDataProcessAccess.RiskProcessAccess = valueProcessAccess
                                case "Desc":
                                    eventDataProcessAccess.DescProcessAccess = valueProcessAccess
                                case "Forensic":
                                    eventDataProcessAccess.ForensicProcessAccess = valueProcessAccess
                                }
                            }
                        }
                    }
                }

                if utcTimeProcessAccess, ok := eventDataMapProcessAccess["UtcTime"].(string); ok {
                    eventDataProcessAccess.TimestampProcessAccess = convertToBeijingTimeProcessAccess(utcTimeProcessAccess)
                }
            }
        }

        if hostProcessAccess, ok := sourceProcessAccess["host"].(map[string]interface{}); ok {
            if ipProcessAccess, ok := hostProcessAccess["ip"].(string); ok {
                eventDataProcessAccess.HostIPProcessAccess = ipProcessAccess
            }
        }

        eventQueryProcessAccess.DocumentsProcessAccess = append(eventQueryProcessAccess.DocumentsProcessAccess, eventDataProcessAccess)
    }

    if len(documentsProcessAccess) > 0 {
        lastDocProcessAccess := documentsProcessAccess[len(documentsProcessAccess)-1].(map[string]interface{})
        if sortProcessAccess, ok := lastDocProcessAccess["sort"].([]interface{}); ok {
            eventQueryProcessAccess.NextPageKeyProcessAccess = sortProcessAccess
        }
    }

    return eventQueryProcessAccess, nil
}

func queryRawEventsProcessAccess(startTimeProcessAccess, endTimeProcessAccess, hostIPProcessAccess string, filtersProcessAccess map[string]string) ([]map[string]interface{}, error) {
    utcStartTimeProcessAccess, err := convertToUTCProcessAccess(startTimeProcessAccess)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTimeProcessAccess, err := convertToUTCProcessAccess(endTimeProcessAccess)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var bufProcessAccess bytes.Buffer
    queryProcessAccess := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeProcessAccess,
                                "lte": utcEndTimeProcessAccess,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    mustProcessAccess := queryProcessAccess["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    if hostIPProcessAccess != "" {
        addTermQueryProcessAccess(&mustProcessAccess, "host.ip", hostIPProcessAccess)
    }

    for keyProcessAccess, valueProcessAccess := range filtersProcessAccess {
        if valueProcessAccess != "" {
            switch keyProcessAccess {
            case "computer_name", "event_id", "SourceImage", "TargetImage", "SourceProcessId", "TargetProcessId", "SourceProcessGUID", "TargetProcessGUID", "GrantedAccess":
                addTermQueryProcessAccess(&mustProcessAccess, "winlog."+keyProcessAccess, valueProcessAccess)
            case "imageLoaded", "TargetFilename", "Image", "ParentImage":
                addTermQueryProcessAccess(&mustProcessAccess, "winlog.event_data."+keyProcessAccess, valueProcessAccess)
            case "SourceUser", "TargetUser":
                escapedUserProcessAccess := regexp.QuoteMeta(valueProcessAccess)
                mustProcessAccess = append(mustProcessAccess, map[string]interface{}{
                    "regexp": map[string]interface{}{
                        "winlog.event_data." + keyProcessAccess: ".*" + escapedUserProcessAccess + ".*",
                    },
                })

            case "CommandLine", "ParentCommandLine": // 使用正则表达式匹配 CommandLine 和 ParentCommandLine
                mustProcessAccess = append(mustProcessAccess, map[string]interface{}{
                    "regexp": map[string]interface{}{
                        "winlog.event_data." + keyProcessAccess: valueProcessAccess, // valueProcessAccess 已经是正则表达式字符串
                    },
                })
            default: // RuleName 字段的处理
                encodedValueProcessAccess, err := json.Marshal(valueProcessAccess)
                if err != nil {
                    return nil, fmt.Errorf("编码过滤值时出错: %v", err)
                }
                mustProcessAccess = append(mustProcessAccess, map[string]interface{}{
                    "script": map[string]interface{}{
                        "script": map[string]interface{}{
                            "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", keyProcessAccess, string(encodedValueProcessAccess)),
                            "lang":   "painless",
                        },
                    },
                })
            }
        }
    }

    queryProcessAccess["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = mustProcessAccess

    if err := json.NewEncoder(&bufProcessAccess).Encode(queryProcessAccess); err != nil {
        return nil, err
    }

    resProcessAccess, err := esProcessAccess.Search(
        esProcessAccess.Search.WithContext(context.Background()),
        esProcessAccess.Search.WithIndex(indexPattern),
        esProcessAccess.Search.WithBody(&bufProcessAccess),
        esProcessAccess.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer resProcessAccess.Body.Close()

    if resProcessAccess.IsError() {
        return nil, fmt.Errorf("错误响应: %s", resProcessAccess.String())
    }

    var rProcessAccess map[string]interface{}
    if err := json.NewDecoder(resProcessAccess.Body).Decode(&rProcessAccess); err != nil {
        return nil, err
    }

    hitsProcessAccess := rProcessAccess["hits"].(map[string]interface{})
    documentsProcessAccess := hitsProcessAccess["hits"].([]interface{})

    rawDataProcessAccess := make([]map[string]interface{}, len(documentsProcessAccess))
    for i, docProcessAccess := range documentsProcessAccess {
        rawDataProcessAccess[i] = docProcessAccess.(map[string]interface{})
    }

    return rawDataProcessAccess, nil
}

// 启用 CORS
func enableCORSProcessAccess() gin.HandlerFunc {
    return func(c *gin.Context) {
        c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
        c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")

        if c.Request.Method == "OPTIONS" {
            c.AbortWithStatus(http.StatusNoContent)
            return
        }

        c.Next()
    }
}

// 处理事件查询
func HandleEventQueryProcessAccess(c *gin.Context) {
    startTimeProcessAccess := c.Query("startTime")
    endTimeProcessAccess := c.Query("endTime")
    hostIPProcessAccess := c.Query("hostIP")
    searchAfterStrProcessAccess := c.Query("searchAfter")
    imageLoadedProcessAccess := c.Query("imageLoaded")
    targetFilenameProcessAccess := c.Query("TargetFilename")

    userParamProcessAccess, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.String(http.StatusBadRequest, "Invalid User parameter")
        return
    }

    filtersProcessAccess := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamProcessAccess,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexProcessAccess(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexProcessAccess(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoadedProcessAccess,
        "TargetFilename": targetFilenameProcessAccess,
    }

    if startTimeProcessAccess == "" || endTimeProcessAccess == "" {
        c.String(http.StatusBadRequest, "缺少 startTime 或 endTime")
        return
    }

    var searchAfterProcessAccess []interface{}
    if searchAfterStrProcessAccess != "" {
        err := json.Unmarshal([]byte(searchAfterStrProcessAccess), &searchAfterProcessAccess)
        if err != nil {
            c.String(http.StatusBadRequest, "无效的 searchAfter 参数")
            return
        }
    }

    eventQueryProcessAccess, err := queryEventsProcessAccess(startTimeProcessAccess, endTimeProcessAccess, hostIPProcessAccess, searchAfterProcessAccess, filtersProcessAccess)
    if err != nil {
        c.String(http.StatusInternalServerError, err.Error())
        return
    }

    c.JSON(http.StatusOK, eventQueryProcessAccess)
}

// 处理事件下载
func HandleEventDownloadProcessAccess(c *gin.Context) {
    startTimeProcessAccess := c.Query("startTime")
    endTimeProcessAccess := c.Query("endTime")
    hostIPProcessAccess := c.Query("hostIP")
    imageLoadedProcessAccess := c.Query("imageLoaded")
    targetFilenameProcessAccess := c.Query("TargetFilename")

    userParamProcessAccess, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.String(http.StatusBadRequest, "Invalid User parameter")
        return
    }

    filtersProcessAccess := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamProcessAccess,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexProcessAccess(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexProcessAccess(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoadedProcessAccess,
        "TargetFilename": targetFilenameProcessAccess,
    }

    if startTimeProcessAccess == "" || endTimeProcessAccess == "" {
        c.String(http.StatusBadRequest, "缺少 startTime 或 endTime")
        return
    }

    rawDataProcessAccess, err := queryRawEventsProcessAccess(startTimeProcessAccess, endTimeProcessAccess, hostIPProcessAccess, filtersProcessAccess)
    if err != nil {
        c.String(http.StatusInternalServerError, err.Error())
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")

    encoderProcessAccess := json.NewEncoder(c.Writer)
    encoderProcessAccess.SetIndent("", "  ")

    if err := encoderProcessAccess.Encode(rawDataProcessAccess); err != nil {
        c.String(http.StatusInternalServerError, "Error encoding JSON")
        return
    }
}

