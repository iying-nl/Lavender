package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/gin-gonic/gin"
    "github.com/elastic/go-elasticsearch/v7"
)



type EventDataProcessCreation struct {
    IDProcessCreation                 string `json:"_id"`
    TimestampProcessCreation          string `json:"winlog.event_data.UtcTime"`
    ComputerNameProcessCreation       string `json:"winlog.computer_name"`
    EventIDProcessCreation            string `json:"winlog.event_id"`
    RuleNameProcessCreation           string `json:"winlog.event_data.RuleName"`
    HostIPProcessCreation             string `json:"host.ip"`
    ImageProcessCreation              string `json:"winlog.event_data.Image"`
    ParentImageProcessCreation        string `json:"winlog.event_data.ParentImage"`
    ParentCommandLineProcessCreation  string `json:"winlog.event_data.ParentCommandLine"`
    CommandLineProcessCreation        string `json:"winlog.event_data.CommandLine"`
}

type EventQueryProcessCreation struct {
    TotalHitsProcessCreation   int64                       `json:"totalHits"`
    TotalPagesProcessCreation  int                         `json:"totalPages"`
    DocumentsProcessCreation   []EventDataProcessCreation  `json:"documents"`
    NextPageKeyProcessCreation string                      `json:"nextPageKey,omitempty"`
}

var esProcessCreation *elasticsearch.Client

func init() {
    cfgProcessCreation := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var errProcessCreation error
    esProcessCreation, errProcessCreation = elasticsearch.NewClient(cfgProcessCreation)
    if errProcessCreation != nil {
        log.Fatalf("Error creating the client: %s", errProcessCreation)
    }
}

func convertToRegexProcessCreation(inputProcessCreation string) string {
    escapedProcessCreation := regexp.QuoteMeta(inputProcessCreation)
    partsProcessCreation := strings.Fields(escapedProcessCreation)
    for i := range partsProcessCreation {
        partsProcessCreation[i] = ".*" + partsProcessCreation[i] + ".*"
    }
    regexPatternProcessCreation := strings.Join(partsProcessCreation, "")
    return regexPatternProcessCreation
}

func convertToUTCProcessCreation(timeStrProcessCreation string) (string, error) {
    tProcessCreation, errProcessCreation := time.Parse(time.RFC3339, timeStrProcessCreation)
    if errProcessCreation != nil {
        return "", errProcessCreation
    }
    utcTimeProcessCreation := tProcessCreation.Add(-8 * time.Hour)
    return utcTimeProcessCreation.Format(time.RFC3339), nil
}

func convertToBeijingProcessCreation(utcTimeProcessCreation string) (string, error) {
    tProcessCreation, errProcessCreation := time.Parse("2006-01-02 15:04:05.999", utcTimeProcessCreation)
    if errProcessCreation != nil {
        return "", errProcessCreation
    }
    beijingTimeProcessCreation := tProcessCreation.Add(8 * time.Hour)
    return beijingTimeProcessCreation.Format("2006-01-02 15:04:05.999"), nil
}

func queryEventsProcessCreation(startTimeProcessCreation, endTimeProcessCreation, hostIPProcessCreation, imageProcessCreation, parentImageProcessCreation, parentCommandLineProcessCreation, commandLineProcessCreation, searchAfterProcessCreation string) (*EventQueryProcessCreation, error) {
    utcStartTimeProcessCreation, errProcessCreation := convertToUTCProcessCreation(startTimeProcessCreation)
    if errProcessCreation != nil {
        return nil, fmt.Errorf("invalid start time: %v", errProcessCreation)
    }
    utcEndTimeProcessCreation, errProcessCreation := convertToUTCProcessCreation(endTimeProcessCreation)
    if errProcessCreation != nil {
        return nil, fmt.Errorf("invalid end time: %v", errProcessCreation)
    }

    var bufProcessCreation bytes.Buffer
    queryProcessCreation := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTimeProcessCreation,
                                "lte": utcEndTimeProcessCreation,
                            },
                        },
                    },
                    {
                        "term": map[string]interface{}{
                            "winlog.event_id": "1",
                        },
                    },
                    {
                        "regexp": map[string]interface{}{
                            "winlog.event_data.RuleName": ".*(Level=(3|4)|Risk=([7-9][0-9]|100)).*",
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.CommandLine",
        },
    }

    if hostIPProcessCreation != "" {
        queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIPProcessCreation,
                },
            },
        )
    }

    if imageProcessCreation != "" {
        queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.event_data.Image": imageProcessCreation,
                },
            },
        )
    }

    if parentImageProcessCreation != "" {
        queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.event_data.ParentImage": parentImageProcessCreation,
                },
            },
        )
    }

    if parentCommandLineProcessCreation != "" {
        queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "regexp": map[string]interface{}{
                    "winlog.event_data.ParentCommandLine": parentCommandLineProcessCreation,
                },
            },
        )
    }

    if commandLineProcessCreation != "" {
        queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            queryProcessCreation["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "regexp": map[string]interface{}{
                    "winlog.event_data.CommandLine": commandLineProcessCreation,
                },
            },
        )
    }

    if searchAfterProcessCreation != "" {
        var searchAfterValuesProcessCreation []interface{}
        errProcessCreation := json.Unmarshal([]byte(searchAfterProcessCreation), &searchAfterValuesProcessCreation)
        if errProcessCreation == nil && len(searchAfterValuesProcessCreation) == 2 {
            queryProcessCreation["search_after"] = searchAfterValuesProcessCreation
        }
    }

    if errProcessCreation := json.NewEncoder(&bufProcessCreation).Encode(queryProcessCreation); errProcessCreation != nil {
        return nil, errProcessCreation
    }

    resProcessCreation, errProcessCreation := esProcessCreation.Search(
        esProcessCreation.Search.WithContext(context.Background()),
        esProcessCreation.Search.WithIndex(indexPattern),
        esProcessCreation.Search.WithBody(&bufProcessCreation),
        esProcessCreation.Search.WithTrackTotalHits(true),
    )
    if errProcessCreation != nil {
        return nil, errProcessCreation
    }
    defer resProcessCreation.Body.Close()

    if resProcessCreation.IsError() {
        return nil, fmt.Errorf("error response: %s", resProcessCreation.String())
    }

    var rProcessCreation map[string]interface{}
    if errProcessCreation := json.NewDecoder(resProcessCreation.Body).Decode(&rProcessCreation); errProcessCreation != nil {
        return nil, errProcessCreation
    }

    hitsProcessCreation := rProcessCreation["hits"].(map[string]interface{})
    totalProcessCreation := int64(hitsProcessCreation["total"].(map[string]interface{})["value"].(float64))
    documentsProcessCreation := hitsProcessCreation["hits"].([]interface{})

    eventQueryProcessCreation := &EventQueryProcessCreation{
        TotalHitsProcessCreation:  totalProcessCreation,
        TotalPagesProcessCreation: int((totalProcessCreation + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsProcessCreation:  make([]EventDataProcessCreation, 0, len(documentsProcessCreation)),
    }

    for _, docProcessCreation := range documentsProcessCreation {
        docMapProcessCreation := docProcessCreation.(map[string]interface{})
        sourceProcessCreation := docMapProcessCreation["_source"].(map[string]interface{})

        eventDataProcessCreation := EventDataProcessCreation{
            IDProcessCreation: docMapProcessCreation["_id"].(string),
        }

        if winlogProcessCreation, okProcessCreation := sourceProcessCreation["winlog"].(map[string]interface{}); okProcessCreation {
            if computerNameProcessCreation, okProcessCreation := winlogProcessCreation["computer_name"].(string); okProcessCreation {
                eventDataProcessCreation.ComputerNameProcessCreation = computerNameProcessCreation
            }

            if eventIDProcessCreation, okProcessCreation := winlogProcessCreation["event_id"].(string); okProcessCreation {
                eventDataProcessCreation.EventIDProcessCreation = eventIDProcessCreation
            }

            if eventDataMapProcessCreation, okProcessCreation := winlogProcessCreation["event_data"].(map[string]interface{}); okProcessCreation {
                if ruleNameProcessCreation, okProcessCreation := eventDataMapProcessCreation["RuleName"].(string); okProcessCreation {
                    eventDataProcessCreation.RuleNameProcessCreation = ruleNameProcessCreation
                }

                if utcTimeProcessCreation, okProcessCreation := eventDataMapProcessCreation["UtcTime"].(string); okProcessCreation {
                    beijingTimeProcessCreation, errProcessCreation := convertToBeijingProcessCreation(utcTimeProcessCreation)
                    if errProcessCreation == nil {
                        eventDataProcessCreation.TimestampProcessCreation = beijingTimeProcessCreation
                    } else {
                        log.Printf("Error converting time: %v", errProcessCreation)
                        eventDataProcessCreation.TimestampProcessCreation = utcTimeProcessCreation
                    }
                }

                if imageProcessCreation, okProcessCreation := eventDataMapProcessCreation["Image"].(string); okProcessCreation {
                    eventDataProcessCreation.ImageProcessCreation = imageProcessCreation
                }
                if parentImageProcessCreation, okProcessCreation := eventDataMapProcessCreation["ParentImage"].(string); okProcessCreation {
                    eventDataProcessCreation.ParentImageProcessCreation = parentImageProcessCreation
                }
                if parentCommandLineProcessCreation, okProcessCreation := eventDataMapProcessCreation["ParentCommandLine"].(string); okProcessCreation {
                    eventDataProcessCreation.ParentCommandLineProcessCreation = parentCommandLineProcessCreation
                }
                if commandLineProcessCreation, okProcessCreation := eventDataMapProcessCreation["CommandLine"].(string); okProcessCreation {
                    eventDataProcessCreation.CommandLineProcessCreation = commandLineProcessCreation
                }
            }
        }

        if hostProcessCreation, okProcessCreation := sourceProcessCreation["host"].(map[string]interface{}); okProcessCreation {
            if ipProcessCreation, okProcessCreation := hostProcessCreation["ip"].(string); okProcessCreation {
                eventDataProcessCreation.HostIPProcessCreation = ipProcessCreation
            }
        }

        eventQueryProcessCreation.DocumentsProcessCreation = append(eventQueryProcessCreation.DocumentsProcessCreation, eventDataProcessCreation)
    }

    if len(documentsProcessCreation) > 0 {
        lastDocProcessCreation := documentsProcessCreation[len(documentsProcessCreation)-1].(map[string]interface{})
        if sortProcessCreation, okProcessCreation := lastDocProcessCreation["sort"].([]interface{}); okProcessCreation {
            nextPageKeyProcessCreation, errProcessCreation := json.Marshal(sortProcessCreation)
            if errProcessCreation == nil {
                eventQueryProcessCreation.NextPageKeyProcessCreation = string(nextPageKeyProcessCreation)
            }
        }
    }

    return eventQueryProcessCreation, nil
}



func HandleEventQueryProcessCreation(c *gin.Context) {
    startTimeProcessCreation := c.Query("startTime")
    endTimeProcessCreation := c.Query("endTime")
    hostIPProcessCreation := c.Query("hostIP")
    imageProcessCreation := c.Query("image")
    parentImageProcessCreation := c.Query("parentImage")
    parentCommandLineProcessCreation, _ := url.QueryUnescape(c.Query("parentCommandLine"))
    commandLineProcessCreation, _ := url.QueryUnescape(c.Query("commandLine"))
    searchAfterProcessCreation := c.Query("searchAfter")

    if startTimeProcessCreation == "" || endTimeProcessCreation == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Missing startTime or endTime"})
        return
    }

    if parentCommandLineProcessCreation != "" {
        parentCommandLineProcessCreation = convertToRegexProcessCreation(parentCommandLineProcessCreation)
    }
    if commandLineProcessCreation != "" {
        commandLineProcessCreation = convertToRegexProcessCreation(commandLineProcessCreation)
    }

    eventQueryProcessCreation, errProcessCreation := queryEventsProcessCreation(startTimeProcessCreation, endTimeProcessCreation, hostIPProcessCreation, imageProcessCreation, parentImageProcessCreation, parentCommandLineProcessCreation, commandLineProcessCreation, searchAfterProcessCreation)
    if errProcessCreation != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": errProcessCreation.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQueryProcessCreation)
}


func DownloadEventQueryProcessCreation(c *gin.Context) {
    startTimeProcessCreation := c.Query("startTime")
    endTimeProcessCreation := c.Query("endTime")
    hostIPProcessCreation := c.Query("hostIP")
    imageProcessCreation := c.Query("image")
    parentImageProcessCreation := c.Query("parentImage")
    parentCommandLineProcessCreation, _ := url.QueryUnescape(c.Query("parentCommandLine"))
    commandLineProcessCreation, _ := url.QueryUnescape(c.Query("commandLine"))
    searchAfterProcessCreation := c.Query("searchAfter")

    // 检查是否提供了必要的参数
    if startTimeProcessCreation == "" || endTimeProcessCreation == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Missing startTime or endTime"})
        return
    }

    // 转换正则表达式
    if parentCommandLineProcessCreation != "" {
        parentCommandLineProcessCreation = convertToRegexProcessCreation(parentCommandLineProcessCreation)
    }
    if commandLineProcessCreation != "" {
        commandLineProcessCreation = convertToRegexProcessCreation(commandLineProcessCreation)
    }

    // 查询事件
    eventQueryProcessCreation, errProcessCreation := queryEventsProcessCreation(
        startTimeProcessCreation,
        endTimeProcessCreation,
        hostIPProcessCreation,
        imageProcessCreation,
        parentImageProcessCreation,
        parentCommandLineProcessCreation,
        commandLineProcessCreation,
        searchAfterProcessCreation,
    )
    if errProcessCreation != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": errProcessCreation.Error()})
        return
    }

    // 将结果转换为格式化的 JSON
    resultJSON, errProcessCreation := json.MarshalIndent(eventQueryProcessCreation, "", "  ")
    if errProcessCreation != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to encode JSON"})
        return
    }

    // 设置响应头以触发下载
    c.Header("Content-Disposition", "attachment; filename=event_query_results.json")
    c.Header("Content-Type", "application/json")
    c.Writer.Write(resultJSON)
}
