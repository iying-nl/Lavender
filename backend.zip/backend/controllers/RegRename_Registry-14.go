package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)


// EventDataRegRename_Registry 结构体定义了事件数据的字段
type EventDataRegRename_Registry struct {
    IDRegRename_Registry              string      `json:"_id"`
    TimestampRegRename_Registry       string      `json:"winlog.event_data.UtcTime"`
    ComputerNameRegRename_Registry    string      `json:"winlog.computer_name"`
    EventIDRegRename_Registry         string      `json:"winlog.event_id"`
    RuleNameRegRename_Registry        string      `json:"winlog.event_data.RuleName"`
    HostIPRegRename_Registry          string      `json:"host.ip"`
    UserRegRename_Registry            interface{} `json:"winlog.event_data.User"`
    SortRegRename_Registry            []interface{} `json:"sort"`
    AttackRegRename_Registry          string      `json:"attack"`
    TechniqueRegRename_Registry       string      `json:"technique"`
    TacticRegRename_Registry          string      `json:"tactic"`
    DSRegRename_Registry              string      `json:"ds"`
    AlertRegRename_Registry           string      `json:"alert"`
    DescRegRename_Registry            string      `json:"desc"`
    ForensicRegRename_Registry        string      `json:"forensic"`
    LevelRegRename_Registry           string      `json:"level"`
    RiskRegRename_Registry            string      `json:"risk"`
    ImageRegRename_Registry           string      `json:"winlog.event_data.Image"`
    ParentImageRegRename_Registry     string      `json:"winlog.event_data.ParentImage"`
    CommandLineRegRename_Registry     string      `json:"winlog.event_data.CommandLine"`
    ParentCommandLineRegRename_Registry string      `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedRegRename_Registry     string      `json:"winlog.event_data.ImageLoaded"`
    TargetObjectRegRename_Registry    string      `json:"winlog.event_data.TargetObject"`
    TaskRegRename_Registry            string      `json:"winlog.task"`
    EventTypeRegRename_Registry       string      `json:"winlog.event_data.EventType"`
    ProcessIdRegRename_Registry       string      `json:"winlog.event_data.ProcessId"`
    DetailsRegRename_Registry         []string    `json:"winlog.event_data.Details"` // 新增字段
    NewNameRegRename_Registry         string      `json:"winlog.event_data.NewName"` // 新增字段
}

// EventQueryRegRename_Registry 结构体定义了查询结果的格式
type EventQueryRegRename_Registry struct {
    TotalHitsRegRename_Registry   int64       `json:"totalHits"`
    TotalPagesRegRename_Registry  int         `json:"totalPages"`
    DocumentsRegRename_Registry   []EventDataRegRename_Registry `json:"documents"`
    NextPageKeyRegRename_Registry []interface{} `json:"nextPageKey,omitempty"`
}

var esRegRename_Registry *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCRegRename_Registry(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeRegRename_Registry(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime // 如果解析失败，返回原始时间字符串
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexRegRename_Registry(input string) string {
    if input == "" {
        return ""
    }
    escaped := regexp.QuoteMeta(input)
    parts := strings.Fields(escaped)
    for i, part := range parts {
        parts[i] = ".*" + part + ".*"
    }
    return strings.Join(parts, "")
}

func addTermQueryRegRename_Registry(must *[]map[string]interface{}, field, value string) {
    if value != "" {
        *must = append(*must, map[string]interface{}{
            "term": map[string]interface{}{
                field: value,
            },
        })
    }
}

func queryEventsRegRename_Registry(startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQueryRegRename_Registry, error) {
    utcStartTime, err := convertToUTCRegRename_Registry(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCRegRename_Registry(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.ImageLoaded",
            "winlog.event_data.TargetObject",
            "winlog.task",
            "winlog.event_data.EventType",
            "winlog.event_data.ProcessId",
            "winlog.event_data.Details", // 新增字段
            "winlog.event_data.NewName", // 新增字段
        },
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryRegRename_Registry(&must, "host.ip", hostIP)
    addTermQueryRegRename_Registry(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryRegRename_Registry(&must, "winlog.event_id", filters["event_id"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.TargetObject", filters["TargetObject"])
    addTermQueryRegRename_Registry(&must, "winlog.task", filters["Task"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.EventType", filters["EventType"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.Details", filters["Details"]) // 新增字段
    addTermQueryRegRename_Registry(&must, "winlog.event_data.NewName", filters["NewName"]) // 新增字段

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" &&
            key != "TargetObject" && key != "Task" && key != "EventType" && key != "ProcessId" && key != "Details" && key != "NewName" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQueryRegRename_Registry := &EventQueryRegRename_Registry{
        TotalHitsRegRename_Registry:  total,
        TotalPagesRegRename_Registry: int((total + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsRegRename_Registry:  make([]EventDataRegRename_Registry, 0, len(documents)),
    }

    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventDataRegRename_Registry := EventDataRegRename_Registry{
            IDRegRename_Registry: docMap["_id"].(string),
            SortRegRename_Registry: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventDataRegRename_Registry.ComputerNameRegRename_Registry = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                eventDataRegRename_Registry.EventIDRegRename_Registry = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventDataRegRename_Registry.RuleNameRegRename_Registry = ruleName

                    parts := strings.Split(ruleName, ",") // 使用英文逗号分割
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventDataRegRename_Registry.AttackRegRename_Registry = value
                            case "Technique":
                                eventDataRegRename_Registry.TechniqueRegRename_Registry = value
                            case "Tactic":
                                eventDataRegRename_Registry.TacticRegRename_Registry = value
                            case "DS":
                                eventDataRegRename_Registry.DSRegRename_Registry = value
                            case "Level":
                                eventDataRegRename_Registry.LevelRegRename_Registry = value
                            case "Desc":
                                eventDataRegRename_Registry.DescRegRename_Registry = value
                            case "Forensic":
                                eventDataRegRename_Registry.ForensicRegRename_Registry = value
                            case "Risk":
                                eventDataRegRename_Registry.RiskRegRename_Registry = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventDataRegRename_Registry.UserRegRename_Registry = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTimeRegRename_Registry(utcTime)
                    eventDataRegRename_Registry.TimestampRegRename_Registry = localTime
                }

                if image, ok := eventDataMap["Image"].(string); ok {
                    eventDataRegRename_Registry.ImageRegRename_Registry = image
                }
                if parentImage, ok := eventDataMap["ParentImage"].(string); ok {
                    eventDataRegRename_Registry.ParentImageRegRename_Registry = parentImage
                }
                if commandLine, ok := eventDataMap["CommandLine"].(string); ok {
                    eventDataRegRename_Registry.CommandLineRegRename_Registry = commandLine
                }
                if parentCommandLine, ok := eventDataMap["ParentCommandLine"].(string); ok {
                    eventDataRegRename_Registry.ParentCommandLineRegRename_Registry = parentCommandLine
                }
                if imageLoaded, ok := eventDataMap["ImageLoaded"].(string); ok {
                    eventDataRegRename_Registry.ImageLoadedRegRename_Registry = imageLoaded
                }
                if targetObject, ok := eventDataMap["TargetObject"].(string); ok {
                    eventDataRegRename_Registry.TargetObjectRegRename_Registry = targetObject
                }
                if eventType, ok := eventDataMap["EventType"].(string); ok {
                    eventDataRegRename_Registry.EventTypeRegRename_Registry = eventType
                }
                if processId, ok := eventDataMap["ProcessId"].(string); ok {
                    eventDataRegRename_Registry.ProcessIdRegRename_Registry = processId
                }

                // 提取 Details 字段
                if details, ok := eventDataMap["Details"].([]interface{}); ok {
                    eventDataRegRename_Registry.DetailsRegRename_Registry = make([]string, len(details))
                    for i, detail := range details {
                        eventDataRegRename_Registry.DetailsRegRename_Registry[i] = detail.(string)
                    }
                } else if details, ok := eventDataMap["Details"].(string); ok {
                    // 如果 Details 是字符串类型，转换为数组
                    eventDataRegRename_Registry.DetailsRegRename_Registry = []string{details}
                }

                // 提取 NewName 字段
                if newName, ok := eventDataMap["NewName"].(string); ok {
                    eventDataRegRename_Registry.NewNameRegRename_Registry = newName
                }
            }

            if task, ok := winlog["task"].(string); ok {
                eventDataRegRename_Registry.TaskRegRename_Registry = task
            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventDataRegRename_Registry.HostIPRegRename_Registry = ip
            }
        }

        eventQueryRegRename_Registry.DocumentsRegRename_Registry = append(eventQueryRegRename_Registry.DocumentsRegRename_Registry, eventDataRegRename_Registry)
    }

    if len(documents) > 0 {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        if sort, ok := lastDoc["sort"].([]interface{}); ok {
            eventQueryRegRename_Registry.NextPageKeyRegRename_Registry = sort
        }
    }

    return eventQueryRegRename_Registry, nil
}

func queryRawEventsRegRename_Registry(startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    utcStartTime, err := convertToUTCRegRename_Registry(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCRegRename_Registry(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryRegRename_Registry(&must, "host.ip", hostIP)
    addTermQueryRegRename_Registry(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryRegRename_Registry(&must, "winlog.event_id", filters["event_id"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.TargetObject", filters["TargetObject"])
    addTermQueryRegRename_Registry(&must, "winlog.task", filters["Task"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.EventType", filters["EventType"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryRegRename_Registry(&must, "winlog.event_data.Details", filters["Details"]) // 新增字段
    addTermQueryRegRename_Registry(&must, "winlog.event_data.NewName", filters["NewName"]) // 新增字段

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" &&
            key != "TargetObject" && key != "Task" && key != "EventType" && key != "ProcessId" && key != "Details" && key != "NewName" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}

// 启用 CORS
func enableCORSRegRename_Registry(next http.HandlerFunc) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        w.Header().Set("Access-Control-Allow-Origin", "*")
        w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")

        if r.Method == "OPTIONS" {
            w.WriteHeader(http.StatusNoContent)
            return
        }

        next.ServeHTTP(w, r)
    }
}


// 处理事件查询
func HandleEventQueryRegRename_Registry(c *gin.Context) {
    startTimeRegRename_Registry := c.Query("startTime")
    endTimeRegRename_Registry := c.Query("endTime")
    hostIPRegRename_Registry := c.Query("hostIP")
    searchAfterStrRegRename_Registry := c.Query("searchAfter")
    imageLoadedRegRename_Registry := c.Query("imageLoaded")

    userParamRegRename_Registry, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersRegRename_Registry := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamRegRename_Registry,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexRegRename_Registry(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexRegRename_Registry(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoadedRegRename_Registry,
        "TargetObject":  c.Query("TargetObject"),
        "Task":          c.Query("Task"),
        "EventType":     c.Query("EventType"),
        "ProcessId":     c.Query("ProcessId"),
        "Details":       c.Query("Details"), // 新增过滤参数
        "NewName":       c.Query("NewName"), // 新增过滤参数
    }

    if startTimeRegRename_Registry == "" || endTimeRegRename_Registry == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfterRegRename_Registry []interface{}
    if searchAfterStrRegRename_Registry != "" {
        err := json.Unmarshal([]byte(searchAfterStrRegRename_Registry), &searchAfterRegRename_Registry)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQueryRegRename_Registry, err := queryEventsRegRename_Registry(startTimeRegRename_Registry, endTimeRegRename_Registry, hostIPRegRename_Registry, searchAfterRegRename_Registry, filtersRegRename_Registry)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQueryRegRename_Registry)
}

// 处理事件下载
func HandleEventDownloadRegRename_Registry(c *gin.Context) {
    startTimeRegRename_Registry := c.Query("startTime")
    endTimeRegRename_Registry := c.Query("endTime")
    hostIPRegRename_Registry := c.Query("hostIP")
    imageLoadedRegRename_Registry := c.Query("imageLoaded")

    userParamRegRename_Registry, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filtersRegRename_Registry := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParamRegRename_Registry,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexRegRename_Registry(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexRegRename_Registry(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoadedRegRename_Registry,
        "TargetObject":  c.Query("TargetObject"),
        "Task":          c.Query("Task"),
        "EventType":     c.Query("EventType"),
        "ProcessId":     c.Query("ProcessId"),
        "Details":       c.Query("Details"), // 新增过滤参数
        "NewName":       c.Query("NewName"), // 新增过滤参数
    }

    if startTimeRegRename_Registry == "" || endTimeRegRename_Registry == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawDataRegRename_Registry, err := queryRawEventsRegRename_Registry(startTimeRegRename_Registry, endTimeRegRename_Registry, hostIPRegRename_Registry, filtersRegRename_Registry)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")

    // 创建一个新的 JSON 编码器，设置缩进为两个空格
    encoder := json.NewEncoder(c.Writer)
    encoder.SetIndent("", "  ")

    // 编码并写入格式化的 JSON 数据
    if err := encoder.Encode(rawDataRegRename_Registry); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": "Error encoding JSON"})
        return
    }
}

