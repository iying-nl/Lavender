package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "net/url"
    "regexp"
    "strings"
    "time"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)


// EventDataRegObj_Registry 结构体定义了事件数据的字段
type EventDataRegObj_Registry struct {
    IDRegValueSet_Registry              string      `json:"_id"`
    TimestampRegValueSet_Registry        string      `json:"winlog.event_data.UtcTime"`
    ComputerNameRegValueSet_Registry    string      `json:"winlog.computer_name"`
    EventIDRegValueSet_Registry         string      `json:"winlog.event_id"`
    RuleNameRegValueSet_Registry        string      `json:"winlog.event_data.RuleName"`
    HostIPRegValueSet_Registry          string      `json:"host.ip"`
    UserRegValueSet_Registry            interface{} `json:"winlog.event_data.User"`
    SortRegValueSet_Registry            []interface{} `json:"sort"`
    AttackRegValueSet_Registry          string      `json:"attack"`
    TechniqueRegValueSet_Registry       string      `json:"technique"`
    TacticRegValueSet_Registry          string      `json:"tactic"`
    DSRegValueSet_Registry              string      `json:"ds"`
    AlertRegValueSet_Registry           string      `json:"alert"`
    DescRegValueSet_Registry            string      `json:"desc"`
    ForensicRegValueSet_Registry        string      `json:"forensic"`
    LevelRegValueSet_Registry           string      `json:"level"`
    RiskRegValueSet_Registry            string      `json:"risk"`
    ImageRegValueSet_Registry           string      `json:"winlog.event_data.Image"`
    ParentImageRegValueSet_Registry     string      `json:"winlog.event_data.ParentImage"`
    CommandLineRegValueSet_Registry     string      `json:"winlog.event_data.CommandLine"`
    ParentCommandLineRegValueSet_Registry string      `json:"winlog.event_data.ParentCommandLine"`
    ImageLoadedRegValueSet_Registry     string      `json:"winlog.event_data.ImageLoaded"`
    TargetObjectRegValueSet_Registry    string      `json:"winlog.event_data.TargetObject"`
    TaskRegValueSet_Registry            string      `json:"winlog.task"`
    EventTypeRegValueSet_Registry       string      `json:"winlog.event_data.EventType"`
    ProcessIdRegValueSet_Registry       string      `json:"winlog.event_data.ProcessId"`
    DetailsRegValueSet_Registry         []string    `json:"winlog.event_data.Details"`
}

// EventQueryRegObj_Registry 结构体定义了查询结果的格式
type EventQueryRegObj_Registry struct {
    TotalHitsRegValueSet_Registry   int64       `json:"totalHits"`
    TotalPagesRegValueSet_Registry  int         `json:"totalPages"`
    DocumentsRegValueSet_Registry   []EventDataRegObj_Registry `json:"documents"`
    NextPageKeyRegValueSet_Registry []interface{} `json:"nextPageKey,omitempty"`
}

var esRegObj_Registry *elasticsearch.Client

// 初始化 Elasticsearch 客户端
func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

// 将北京时间转换为 UTC 格式
func convertToUTCRegValueSet_Registry(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

// 将 UTC 时间转换为北京时间格式
func convertToBeijingTimeRegValueSet_Registry(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime // 如果解析失败，返回原始时间字符串
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

// 新增函数：将输入字符串转换为正则表达式格式
func convertToRegexRegValueSet_Registry(input string) string {
    if input == "" {
        return ""
    }
    escaped := regexp.QuoteMeta(input)
    parts := strings.Fields(escaped)
    for i, part := range parts {
        parts[i] = ".*" + part + ".*"
    }
    return strings.Join(parts, "")
}

func addTermQueryRegValueSet_Registry(must *[]map[string]interface{}, field, value string) {
    if value != "" {
        *must = append(*must, map[string]interface{}{
            "term": map[string]interface{}{
                field: value,
            },
        })
    }
}

func queryEventsRegValueSet_Registry(startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQueryRegObj_Registry, error) {
    utcStartTime, err := convertToUTCRegValueSet_Registry(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCRegValueSet_Registry(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
            "winlog.event_data.Image",
            "winlog.event_data.ParentImage",
            "winlog.event_data.CommandLine",
            "winlog.event_data.ParentCommandLine",
            "winlog.event_data.ImageLoaded",
            "winlog.event_data.TargetObject",
            "winlog.task",
            "winlog.event_data.EventType",
            "winlog.event_data.ProcessId",
            "winlog.event_data.Details",
        },
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryRegValueSet_Registry(&must, "host.ip", hostIP)
    addTermQueryRegValueSet_Registry(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_id", filters["event_id"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.TargetObject", filters["TargetObject"])
    addTermQueryRegValueSet_Registry(&must, "winlog.task", filters["Task"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.EventType", filters["EventType"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.Details", filters["Details"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" &&
            key != "TargetObject" && key != "Task" && key != "EventType" && key != "ProcessId" && key != "Details" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQueryRegObj_Registry := &EventQueryRegObj_Registry{
        TotalHitsRegValueSet_Registry: total,
        TotalPagesRegValueSet_Registry: int((total + int64(pageSize) - 1) / int64(pageSize)),
        DocumentsRegValueSet_Registry:  make([]EventDataRegObj_Registry, 0, len(documents)),
    }

    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventDataRegObj_Registry := EventDataRegObj_Registry{
            IDRegValueSet_Registry: docMap["_id"].(string),
            SortRegValueSet_Registry: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventDataRegObj_Registry.ComputerNameRegValueSet_Registry = computerName
            }
            if eventID, ok := winlog["event_id"].(string); ok {
                eventDataRegObj_Registry.EventIDRegValueSet_Registry = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventDataRegObj_Registry.RuleNameRegValueSet_Registry = ruleName

                    parts := strings.Split(ruleName, ",")
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventDataRegObj_Registry.AttackRegValueSet_Registry = value
                            case "Technique":
                                eventDataRegObj_Registry.TechniqueRegValueSet_Registry = value
                            case "Tactic":
                                eventDataRegObj_Registry.TacticRegValueSet_Registry = value
                            case "DS":
                                eventDataRegObj_Registry.DSRegValueSet_Registry = value
                            case "Level":
                                eventDataRegObj_Registry.LevelRegValueSet_Registry = value
                            case "Desc":
                                eventDataRegObj_Registry.DescRegValueSet_Registry = value
                            case "Forensic":
                                eventDataRegObj_Registry.ForensicRegValueSet_Registry = value
                            case "Risk":
                                eventDataRegObj_Registry.RiskRegValueSet_Registry = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventDataRegObj_Registry.UserRegValueSet_Registry = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTimeRegValueSet_Registry(utcTime)
                    eventDataRegObj_Registry.TimestampRegValueSet_Registry = localTime
                }

                if image, ok := eventDataMap["Image"].(string); ok {
                    eventDataRegObj_Registry.ImageRegValueSet_Registry = image
                }
                if parentImage, ok := eventDataMap["ParentImage"].(string); ok {
                    eventDataRegObj_Registry.ParentImageRegValueSet_Registry = parentImage
                }
                if commandLine, ok := eventDataMap["CommandLine"].(string); ok {
                    eventDataRegObj_Registry.CommandLineRegValueSet_Registry = commandLine
                }
                if parentCommandLine, ok := eventDataMap["ParentCommandLine"].(string); ok {
                    eventDataRegObj_Registry.ParentCommandLineRegValueSet_Registry = parentCommandLine
                }
                if imageLoaded, ok := eventDataMap["ImageLoaded"].(string); ok {
                    eventDataRegObj_Registry.ImageLoadedRegValueSet_Registry = imageLoaded
                }
                if targetObject, ok := eventDataMap["TargetObject"].(string); ok {
                    eventDataRegObj_Registry.TargetObjectRegValueSet_Registry = targetObject
                }
                if eventType, ok := eventDataMap["EventType"].(string); ok {
                    eventDataRegObj_Registry.EventTypeRegValueSet_Registry = eventType
                }
                if processId, ok := eventDataMap["ProcessId"].(string); ok {
                    eventDataRegObj_Registry.ProcessIdRegValueSet_Registry = processId
                }

                if details, ok := eventDataMap["Details"].([]interface{}); ok {
                    eventDataRegObj_Registry.DetailsRegValueSet_Registry = make([]string, len(details))
                    for i, detail := range details {
                        eventDataRegObj_Registry.DetailsRegValueSet_Registry[i] = detail.(string)
                    }
                } else if details, ok := eventDataMap["Details"].(string); ok {
                    eventDataRegObj_Registry.DetailsRegValueSet_Registry = []string{details}
                }
            }

            if task, ok := winlog["task"].(string); ok {
                eventDataRegObj_Registry.TaskRegValueSet_Registry = task
            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventDataRegObj_Registry.HostIPRegValueSet_Registry = ip
            }
        }

        eventQueryRegObj_Registry.DocumentsRegValueSet_Registry = append(eventQueryRegObj_Registry.DocumentsRegValueSet_Registry, eventDataRegObj_Registry)
    }

    if len(documents) > 0 {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        if sort, ok := lastDoc["sort"].([]interface{}); ok {
            eventQueryRegObj_Registry.NextPageKeyRegValueSet_Registry = sort
        }
    }

    return eventQueryRegObj_Registry, nil
}

func queryRawEventsRegValueSet_Registry(startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    utcStartTime, err := convertToUTCRegValueSet_Registry(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTCRegValueSet_Registry(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000,
    }

    must := query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{})

    addTermQueryRegValueSet_Registry(&must, "host.ip", hostIP)
    addTermQueryRegValueSet_Registry(&must, "winlog.computer_name", filters["computer_name"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_id", filters["event_id"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.Image", filters["Image"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.ParentImage", filters["ParentImage"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.ImageLoaded", filters["imageLoaded"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.TargetObject", filters["TargetObject"])
    addTermQueryRegValueSet_Registry(&must, "winlog.task", filters["Task"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.EventType", filters["EventType"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.ProcessId", filters["ProcessId"])
    addTermQueryRegValueSet_Registry(&must, "winlog.event_data.Details", filters["Details"])

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.User": ".*" + escapedUser + ".*",
            },
        })
    }

    if commandLine, ok := filters["CommandLine"]; ok && commandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.CommandLine": commandLine,
            },
        })
    }

    if parentCommandLine, ok := filters["ParentCommandLine"]; ok && parentCommandLine != "" {
        must = append(must, map[string]interface{}{
            "regexp": map[string]interface{}{
                "winlog.event_data.ParentCommandLine": parentCommandLine,
            },
        })
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" &&
            key != "Image" && key != "ParentImage" && key != "CommandLine" && key != "ParentCommandLine" && key != "imageLoaded" &&
            key != "TargetObject" && key != "Task" && key != "EventType" && key != "ProcessId" && key != "Details" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            must = append(must, map[string]interface{}{
                "script": map[string]interface{}{
                    "script": map[string]interface{}{
                        "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                        "lang":   "painless",
                    },
                },
            })
        }
    }

    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = must

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}


// 处理事件查询
func HandleEventQueryRegValueSet_Registry(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")
    searchAfterStr := c.Query("searchAfter")
    imageLoaded := c.Query("imageLoaded")

    userParam, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }


    filters := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParam,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexRegValueSet_Registry(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexRegValueSet_Registry(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoaded,
        "TargetObject":  c.Query("TargetObject"),
        "Task":          c.Query("Task"),
        "EventType":     c.Query("EventType"),
        "ProcessId":     c.Query("ProcessId"),
        "Details":       c.Query("Details"),
    }

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfter []interface{}
    if searchAfterStr != "" {
        err := json.Unmarshal([]byte(searchAfterStr), &searchAfter)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQuery, err := queryEventsRegValueSet_Registry(startTime, endTime, hostIP, searchAfter, filters)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQuery)
}

// 处理事件下载
func HandleEventDownloadRegValueSet_Registry(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")
    imageLoaded := c.Query("imageLoaded")

    userParam, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filters := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParam,
        "Image":         c.Query("Image"),
        "ParentImage":   c.Query("ParentImage"),
        "CommandLine":   convertToRegexRegValueSet_Registry(c.Query("CommandLine")),
        "ParentCommandLine": convertToRegexRegValueSet_Registry(c.Query("ParentCommandLine")),
        "imageLoaded":   imageLoaded,
        "TargetObject":  c.Query("TargetObject"),
        "Task":          c.Query("Task"),
        "EventType":     c.Query("EventType"),
        "ProcessId":     c.Query("ProcessId"),
        "Details":       c.Query("Details"),
    }

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawData, err := queryRawEventsRegValueSet_Registry(startTime, endTime, hostIP, filters)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")

    // 使用 gin 的 JSON 编码，它会自动处理 JSON 缩进
    c.JSON(http.StatusOK, rawData)
}

