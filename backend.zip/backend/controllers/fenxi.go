package controllers

import (
    "bytes"
    "context"
    "encoding/json"
    "fmt"
    "log"
    "net/http"
    "regexp"
    "strings"
    "time"
    "net/url"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



type EventData struct {
    ID           string      `json:"_id"`
    Timestamp    string      `json:"winlog.event_data.UtcTime"`
    ComputerName string      `json:"winlog.computer_name"`
    EventID      string      `json:"winlog.event_id"`
    RuleName     string      `json:"winlog.event_data.RuleName"`
    HostIP       string      `json:"host.ip"`
    User         interface{} `json:"winlog.event_data.User"`
    Sort         []interface{} `json:"sort"`
    Attack       string      `json:"attack"`
    Technique    string      `json:"technique"`
    Tactic       string      `json:"tactic"`
    DS           string      `json:"ds"`
    Alert        string      `json:"alert"`
    Desc         string      `json:"desc"`
    Forensic     string      `json:"forensic"`
    Level        string      `json:"level"`
    Risk         string      `json:"risk"`
}

type EventQuery struct {
    TotalHits   int64       `json:"totalHits"`
    TotalPages  int         `json:"totalPages"`
    Documents   []EventData `json:"documents"`
    NextPageKey []interface{} `json:"nextPageKey,omitempty"`
}

var es *elasticsearch.Client

func init() {
    cfg := elasticsearch.Config{
        Addresses: []string{esURL},
    }
    var err error
    es, err = elasticsearch.NewClient(cfg)
    if err != nil {
        log.Fatalf("创建客户端时出错: %s", err)
    }
}

func convertToUTC(beijingTime string) (string, error) {
    layout := "2006-01-02T15:04:05Z"
    beijingLoc, err := time.LoadLocation("Asia/Shanghai")
    if err != nil {
        return "", err
    }
    t, err := time.ParseInLocation(layout, beijingTime, beijingLoc)
    if err != nil {
        return "", err
    }
    return t.UTC().Format(layout), nil
}

func convertToBeijingTime(utcTime string) string {
    layout := "2006-01-02 15:04:05.999"
    t, err := time.Parse(layout, utcTime)
    if err != nil {
        return utcTime
    }
    beijingLoc, _ := time.LoadLocation("Asia/Shanghai")
    beijingTime := t.In(beijingLoc)
    return beijingTime.Format("2006-01-02 15:04:05.999")
}

func queryEvents(c *gin.Context, startTime, endTime, hostIP string, searchAfter []interface{}, filters map[string]string) (*EventQuery, error) {
    utcStartTime, err := convertToUTC(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTC(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": pageSize,
        "_source": []string{
            "@timestamp",
            "winlog.computer_name",
            "winlog.event_data.RuleName",
            "host.ip",
            "winlog.event_data.User",
            "winlog.event_id",
            "winlog.event_data.UtcTime",
        },
    }

    if hostIP != "" {
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIP,
                },
            },
        )
    }

    if computerName, ok := filters["computer_name"]; ok && computerName != "" {
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.computer_name": computerName,
                },
            },
        )
    }

    if eventID, ok := filters["event_id"]; ok && eventID != "" {
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "winlog.event_id": eventID,
                },
            },
        )
    }

    if user, ok := filters["User"]; ok && user != "" {
        escapedUser := regexp.QuoteMeta(user)
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "regexp": map[string]interface{}{
                    "winlog.event_data.User": ".*" + escapedUser + ".*",
                },
            },
        )
    }

    for key, value := range filters {
        if value != "" && key != "computer_name" && key != "event_id" && key != "User" {
            encodedValue, err := json.Marshal(value)
            if err != nil {
                return nil, fmt.Errorf("编码过滤值时出错: %v", err)
            }
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                map[string]interface{}{
                    "script": map[string]interface{}{
                        "script": map[string]interface{}{
                            "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                            "lang":   "painless",
                        },
                    },
                },
            )
        }
    }

    if len(searchAfter) > 0 {
        query["search_after"] = searchAfter
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    total := int64(hits["total"].(map[string]interface{})["value"].(float64))
    documents := hits["hits"].([]interface{})

    eventQuery := &EventQuery{
        TotalHits:  total,
        TotalPages: int((total + int64(pageSize) - 1) / int64(pageSize)),
        Documents:  make([]EventData, 0, len(documents)),
    }

    for _, doc := range documents {
        docMap := doc.(map[string]interface{})
        source := docMap["_source"].(map[string]interface{})

        eventData := EventData{
            ID:   docMap["_id"].(string),
            Sort: docMap["sort"].([]interface{}),
        }

        if winlog, ok := source["winlog"].(map[string]interface{}); ok {
            if computerName, ok := winlog["computer_name"].(string); ok {
                eventData.ComputerName = computerName
            }

            if eventID, ok := winlog["event_id"].(string); ok {
                eventData.EventID = eventID
            }

            if eventDataMap, ok := winlog["event_data"].(map[string]interface{}); ok {
                if ruleName, ok := eventDataMap["RuleName"].(string); ok {
                    eventData.RuleName = ruleName
                    parts := strings.Split(ruleName, ",")
                    for _, part := range parts {
                        kv := strings.SplitN(part, "=", 2)
                        if len(kv) == 2 {
                            key := strings.TrimSpace(kv[0])
                            value := strings.TrimSpace(kv[1])
                            switch key {
                            case "Attack":
                                eventData.Attack = value
                            case "Technique":
                                eventData.Technique = value
                            case "Tactic":
                                eventData.Tactic = value
                            case "DS":
                                eventData.DS = value
                            case "Level":
                                eventData.Level = value
                            case "Desc":
                                eventData.Desc = value
                            case "Forensic":
                                eventData.Forensic = value                            
                            case "Risk":
                                eventData.Risk = value
                            }
                        }
                    }
                }

                if user, ok := eventDataMap["User"]; ok {
                    eventData.User = user
                }

                if utcTime, ok := eventDataMap["UtcTime"].(string); ok {
                    localTime := convertToBeijingTime(utcTime)
                    eventData.Timestamp = localTime
                }
            }
        }

        if host, ok := source["host"].(map[string]interface{}); ok {
            if ip, ok := host["ip"].(string); ok {
                eventData.HostIP = ip
            }
        }

        eventQuery.Documents = append(eventQuery.Documents, eventData)
    }

    if len(documents) > 0 {
        lastDoc := documents[len(documents)-1].(map[string]interface{})
        if sort, ok := lastDoc["sort"].([]interface{}); ok {
            eventQuery.NextPageKey = sort
        }
    }

    return eventQuery, nil


}

func queryRawEvents(c *gin.Context, startTime, endTime, hostIP string, filters map[string]string) ([]map[string]interface{}, error) {
    utcStartTime, err := convertToUTC(startTime)
    if err != nil {
        return nil, fmt.Errorf("无效的开始时间: %v", err)
    }
    utcEndTime, err := convertToUTC(endTime)
    if err != nil {
        return nil, fmt.Errorf("无效的结束时间: %v", err)
    }

    var buf bytes.Buffer
    query := map[string]interface{}{
        "query": map[string]interface{}{
            "bool": map[string]interface{}{
                "must": []map[string]interface{}{
                    {
                        "range": map[string]interface{}{
                            "@timestamp": map[string]interface{}{
                                "gte": utcStartTime,
                                "lte": utcEndTime,
                            },
                        },
                    },
                },
            },
        },
        "sort": []map[string]interface{}{
            {"@timestamp": "asc"},
            {"_id": "asc"},
        },
        "size": 10000, // 增加大小以获取更多数据，可以根据需要调整
    }

    if hostIP != "" {
        query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
            query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
            map[string]interface{}{
                "term": map[string]interface{}{
                    "host.ip": hostIP,
                },
            },
        )
    }

    for key, value := range filters {
        if value != "" {
            if key == "computer_name" || key == "event_id" {
                query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "term": map[string]interface{}{
                            fmt.Sprintf("winlog.%s", key): value,
                        },
                    },
                )
            } else if key == "User" {
                escapedUser := regexp.QuoteMeta(value)
                query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "regexp": map[string]interface{}{
                            "winlog.event_data.User": ".*" + escapedUser + ".*",
                        },
                    },
                )
            } else {
                encodedValue, err := json.Marshal(value)
                if err != nil {
                    return nil, fmt.Errorf("编码过滤值时出错: %v", err)
                }

                query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"] = append(
                    query["query"].(map[string]interface{})["bool"].(map[string]interface{})["must"].([]map[string]interface{}),
                    map[string]interface{}{
                        "script": map[string]interface{}{
                            "script": map[string]interface{}{
                                "source": fmt.Sprintf("doc.containsKey('winlog.event_data.RuleName') && doc['winlog.event_data.RuleName'].size() > 0 && doc['winlog.event_data.RuleName'].value.contains('%s=' + %s)", key, string(encodedValue)),
                                "lang":   "painless",
                            },
                        },
                    },
                )
            }
        }
    }

    if err := json.NewEncoder(&buf).Encode(query); err != nil {
        return nil, err
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(&buf),
        es.Search.WithTrackTotalHits(true),
    )
    if err != nil {
        return nil, err
    }
    defer res.Body.Close()

    if res.IsError() {
        return nil, fmt.Errorf("错误响应: %s", res.String())
    }

    var r map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&r); err != nil {
        return nil, err
    }

    hits := r["hits"].(map[string]interface{})
    documents := hits["hits"].([]interface{})

    rawData := make([]map[string]interface{}, len(documents))
    for i, doc := range documents {
        rawData[i] = doc.(map[string]interface{})
    }

    return rawData, nil
}

func HandleEventQuery(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")
    searchAfterStr := c.Query("searchAfter")

    userParam, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filters := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParam,
    }

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    var searchAfter []interface{}
    if searchAfterStr != "" {
        err := json.Unmarshal([]byte(searchAfterStr), &searchAfter)
        if err != nil {
            c.JSON(http.StatusBadRequest, gin.H{"error": "无效的 searchAfter 参数"})
            return
        }
    }

    eventQuery, err := queryEvents(c, startTime, endTime, hostIP, searchAfter, filters)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.JSON(http.StatusOK, eventQuery)
}

func HandleEventDownload(c *gin.Context) {
    startTime := c.Query("startTime")
    endTime := c.Query("endTime")
    hostIP := c.Query("hostIP")

    userParam, err := url.QueryUnescape(c.Query("User"))
    if err != nil {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid User parameter"})
        return
    }

    filters := map[string]string{
        "Attack":        c.Query("Attack"),
        "Technique":     c.Query("Technique"),
        "Tactic":        c.Query("Tactic"),
        "DS":            c.Query("DS"),
        "Alert":         c.Query("Alert"),
        "Desc":          c.Query("Desc"),
        "Forensic":      c.Query("Forensic"),
        "Level":         c.Query("Level"),
        "Risk":          c.Query("Risk"),
        "computer_name": c.Query("computer_name"),
        "event_id":      c.Query("event_id"),
        "User":          userParam,
    }

    if startTime == "" || endTime == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "缺少 startTime 或 endTime"})
        return
    }

    rawData, err := queryRawEvents(c, startTime, endTime, hostIP, filters)
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    c.Header("Content-Disposition", "attachment; filename=events.json")
    c.Header("Content-Type", "application/json")
    c.JSON(http.StatusOK, rawData)
}
