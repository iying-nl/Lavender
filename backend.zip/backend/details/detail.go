package details

import (
    "context"
    "encoding/json"
    "fmt"
    "io/ioutil"
    "log"
    "net/http"
    "strings"

    "github.com/elastic/go-elasticsearch/v7"
    "github.com/gin-gonic/gin"
)



var es *elasticsearch.Client
var translationDict map[string]string

func init() {
    var err error
    es, err = elasticsearch.NewClient(elasticsearch.Config{
        Addresses: []string{esURL},
    })
    if err != nil {
        log.Fatalf("Error creating the client: %s", err)
    }

    // 加载翻译字典
    translationDict, err = loadTranslationDict("details/event_id/event_id.json")
    if err != nil {
        log.Fatalf("Error loading translation dictionary: %s", err)
    }
}

func loadTranslationDict(filename string) (map[string]string, error) {
    data, err := ioutil.ReadFile(filename)
    if err != nil {
        return nil, err
    }

    var dict map[string]string
    err = json.Unmarshal(data, &dict)
    if err != nil {
        return nil, err
    }

    return dict, nil
}

func findTranslation(key string) string {
    if translated, ok := translationDict[key]; ok {
        return translated
    }
    // 处理下划线开头的字段
    if strings.HasPrefix(key, "_") {
        if translated, ok := translationDict[key]; ok {
            return translated
        }
        if translated, ok := translationDict[key[1:]]; ok {
            return translated
        }
    }
    // 处理 _source. 开头的字段
    if strings.HasPrefix(key, "_source.") {
        if translated, ok := translationDict[key]; ok {
            return translated
        }
    }
    parts := strings.Split(key, ".")
    for i := len(parts); i > 0; i-- {
        partialKey := strings.Join(parts[i-1:], ".")
        if translated, ok := translationDict[partialKey]; ok {
            return translated
        }
    }
    return key
}

func translateKeys(data interface{}, prefix string) interface{} {
    switch v := data.(type) {
    case map[string]interface{}:
        result := make(map[string]interface{})
        for key, value := range v {
            fullKey := prefix + key
            translatedKey := findTranslation(fullKey)
            if translatedKey == fullKey {
                translatedKey = key // 如果没有找到翻译，保留原键名
            }
            result[translatedKey] = translateKeys(value, fullKey+".")
        }
        return result
    case []interface{}:
        result := make([]interface{}, len(v))
        for i, item := range v {
            result[i] = translateKeys(item, prefix)
        }
        return result
    default:
        return v
    }
}

func DetailHandler(c *gin.Context) {
    id := c.Query("_id")
    if id == "" {
        c.JSON(http.StatusBadRequest, gin.H{"error": "Missing _id parameter"})
        return
    }

    res, err := es.Search(
        es.Search.WithContext(context.Background()),
        es.Search.WithIndex(indexPattern),
        es.Search.WithBody(strings.NewReader(fmt.Sprintf(`{
            "query": {
                "ids": {
                    "values": ["%s"]
                }
            }
        }`, id))),
    )
    if err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }
    defer res.Body.Close()

    var result map[string]interface{}
    if err := json.NewDecoder(res.Body).Decode(&result); err != nil {
        c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
        return
    }

    hits := result["hits"].(map[string]interface{})["hits"].([]interface{})
    if len(hits) == 0 {
        c.JSON(http.StatusNotFound, gin.H{"error": "Document not found"})
        return
    }

    doc := hits[0].(map[string]interface{})
    translatedDoc := translateKeys(doc, "")

    c.JSON(http.StatusOK, translatedDoc)
}

