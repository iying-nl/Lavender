package main

import (
    "log"
    "backend/router"
)




func main() {
    r := router.SetupRouter()
    log.Fatal(r.Run(":1100"))
}