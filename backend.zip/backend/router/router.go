package router

import (
    "github.com/gin-gonic/gin"
    "backend/controllers"
    "backend/details"
    "backend/brief"
    "backend/analysis"
    "backend/alert"
)

func SetupRouter() *gin.Engine {
    r := gin.Default()

    r.Use(controllers.CorsMiddleware())

    // 创建一个 /api 路由组
    api := r.Group("/api")
    {
        // download 组
        download := api.Group("/download")
        {
            download.GET("/1", controllers.DownloadEventQueryProcessCreation)
            download.GET("/10", controllers.HandleEventDownloadProcessAccess)
            download.GET("/11", controllers.HandleEventDownloadFileCreate)
            download.GET("/13", controllers.HandleEventDownloadRegValueSet_Registry)
            download.GET("/14", controllers.HandleEventDownloadRegRename_Registry)
            download.GET("/17", controllers.HandleEventDownloadPipeCreate_Pipe)
            download.GET("/18", controllers.HandleEventDownloadPipeConn_Pipe)
            download.GET("/2", controllers.HandleEventDownloadFileCreateTime)
            download.GET("/22", controllers.HandleEventDownloadDnsQuery_Network)
            download.GET("/3", controllers.HandleEventDownloadNetworkConnect)
            download.GET("/4", controllers.HandleEventDownloadSysmonServiceStateChanged)
            download.GET("/7", controllers.HandleEventDownloadImageLoad)
        }

        // id 组
        id := api.Group("id")
        {
            id.GET("/FileCreate-11", controllers.HandleEventQueryFileCreate)
            id.GET("/FileCreateTime", controllers.HandleEventQueryFileCreateTime)
            id.GET("/ImageLoad-7", controllers.HandleEventQueryImageLoad)
            id.GET("/NetworkConnect", controllers.HandleEventQueryNetworkConnect)
            id.GET("/PipeConn_Pipe", controllers.HandleEventQueryPipeConn_Pipe)
            id.GET("/PipeEventObjectCreated-17", controllers.HandleEventQueryPipeCreate_Pipe)
            id.GET("/ProcessAccess", controllers.HandleEventQueryProcessAccess)
            id.GET("/Process-Creation", controllers.HandleEventQueryProcessCreation)
            id.GET("/RegRename_Registry-14", controllers.HandleEventQueryRegRename_Registry)
            id.GET("/RegistryEventValueSet-13", controllers.HandleEventQueryRegValueSet_Registry)
            id.GET("/SysmonState_Service", controllers.HandleEventQuerySysmonServiceStateChanged)
            id.GET("/DnsQuery_Network-22", controllers.HandleEventQueryDnsQuery_Network)
        }

        // 其他分组
        others := api.Group("/others")
        {
            others.GET("/getDetailById", brief.HandleEventDetail)
            others.GET("/detail", details.DetailHandler)
        }

        // events 路由
        events := api.Group("")
        {
            events.GET("/events", controllers.HandleEventQuery)
            events.GET("/eventsrisk", alert.HandleEventQueryAlert)
        }

        // 新增的两个路由
        api.GET("/network_connections", analysis.HandleEventQueryNetworkConnect)
        api.GET("/process_tree", analysis.ProcessTreeHandler)
    }

    return r
}
